function Diri_FaceBasis = DiriBC_projecton(face_nodes, Po  , HHO_face_ind ,dim_face,HHO_NF_face_ind ,dim_NF_face,n_vec,g_D, g_N)


[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);


% data for quadrature
    
 g_val = g_D(Qpoints_faces); grad_val = g_N(Qpoints_faces);  
 
 N_g_val = n_vec(1).* grad_val(:,1) + n_vec(2).* grad_val(:,2);
 
 %% using the collocation projection method  based on inverting the local mass matrix 
 % for the function value g_D
 
 mass = NaN(dim_face,dim_face); F = NaN(dim_face,1);
 
 for j = 1: dim_face
    
     t_F = g_val.* Face_baisis(Qpoints_faces,face_nodes,Po,HHO_face_ind(j,:)); 

     
     F(j) = dot(t_F,weights_faces);
     
     
     for i  =1: dim_face
        
         t =  Face_baisis(Qpoints_faces,face_nodes,Po,HHO_face_ind(i,:)).*...
              Face_baisis(Qpoints_faces,face_nodes,Po,HHO_face_ind(j,:)) ;
          
        mass(j,i) = dot(t,weights_faces);
         
     end
     
          
 end
 
 %% Update the last too conditions for the H1 projections  
 
 C = mass;
 

 
   for j = 1:dim_face
                           
        
        C([dim_face-1,dim_face],j) =  Face_basis_Nodal_value(face_nodes,HHO_face_ind(j,:)); 
        
   end
 
F_D = F; 

F_D([dim_face-1,dim_face]) = g_D(face_nodes); 
 
 
Diri_FaceBasis1 = C\F_D;


%Diri_FaceBasis1 =  mass\F;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

M = NaN(dim_NF_face,dim_NF_face); F_NF = NaN(dim_NF_face,1);

 
 for j = 1: dim_NF_face
    
     NF_F =  N_g_val.* Normal_Face_baisis(Qpoints_faces,face_nodes,Po,HHO_NF_face_ind(j,:)); 

     
     F_NF(j) = dot(NF_F,weights_faces);
     
     
     for i  =1: dim_NF_face
        
         t =  Normal_Face_baisis(Qpoints_faces,face_nodes,Po,HHO_NF_face_ind(i,:)).*...
              Normal_Face_baisis(Qpoints_faces,face_nodes,Po,HHO_NF_face_ind(j,:)) ;
          
        M(j,i) = dot(t,weights_faces);
         
     end
     
          
 end

 
 Diri_NF_FaceBasis = M\F_NF;

 Diri_FaceBasis= [Diri_FaceBasis1;Diri_NF_FaceBasis];
 
end
    