function [ R_L2_part, R_H1_part,L2_part, H1_part,local_R_HHO  ] = Err_elem(submesh ,BDbox, coef,local_Reconstruction, Po ,HHO_elem_ind,RHHO_ind,   u_exact, grad_u, a)

%% First compute the local Reconstruction R_HHO

NT = size(submesh,3);

ind = size(coef,1); % remove the rededuncy 

R_HHO_nc = local_Reconstruction(:,1:ind)*coef;




dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 

dim_elem_inter = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 

%dim_elem_face = size(HHO_face_ind,1); % Dimention for face basis on each individual face 




% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);


[Qpoints_elem,weights_elem]=quad_poly_background(submesh,NT,Po); % get the quadrature points on polygon



%% The element sharing (0,0) is refined for quadratures 

teest = sum(abs(submesh),2);

index  = find(teest==0, 1);


if  isempty(index) ==0

elem = [1,2,3];  node = submesh(:,:,1);  

%% refine the local mesh for quadrature

for k=1:Po % Po=polynomial_degree+3

[node,elem]=uniformrefine(node,elem);

end

%% store the quadrature

new_submesh = NaN(3,2,Po);

for k=1:Po

new_submesh(:,:,k) = node(elem(k,:),:); 

end

[Qpoints_elem,weights_elem]=quad_poly_background(new_submesh,Po,Po); % get the quadrature points on polygon


end





%% Find the missing coefficients on the constant (R(u)-u_K,1)_K=0

R=zeros(dim_elem_R,1);

for k=1:dim_elem_R
    
    v_val= tensor_leg(Qpoints_elem,m,h,RHHO_ind(k,:));
    
    R(k)= dot(v_val,weights_elem);
    
end

U = R(1:dim_elem_inter);


R_HHO_miss_constant = (dot(U,coef(1:dim_elem_inter)) - dot(R(2:end),R_HHO_nc))./R(1);

%% R_HHO solution finally find.....

local_R_HHO =[R_HHO_miss_constant ;R_HHO_nc];


%% computing the error



%%

L2_part=0;  H1_part = 0; R_L2_part=0;  R_H1_part = 0;

     
    % data for quadrature
    
     u_val = u_exact(Qpoints_elem);    a_val_cell = a(Qpoints_elem);
    
     grad_u_val = grad_u(Qpoints_elem);
     
     

%Computing the error for the projection of the u and u_h

% the mass matrix on the element basis T and T between dim_elem_inter * dim_elem_R

M = NaN(dim_elem_inter,dim_elem_inter); 

P1_U = NaN(dim_elem_inter,1); 

for i = 1:dim_elem_inter
   
    %%symetric term
    
    s = u_val.*tensor_leg(Qpoints_elem,m,h,HHO_elem_ind(i,:));
    
    P1_U(i) = dot(s,weights_elem);
    
    for j=1:dim_elem_inter
    
        % first term uv is symetric
            
        
        U = tensor_leg(Qpoints_elem,m,h,HHO_elem_ind(i,:));
        
        V = tensor_leg(Qpoints_elem,m,h,HHO_elem_ind(j,:));
        
        t =  sum(U.*V,2);
        
        M(i,j) = dot(t,weights_elem);
        
    end
end

Proj_p = M\P1_U; % coefficents of L2 projection on element P_p(k)

% split the M into each use for matrix 





         
    
    % construct the matrix for all the local basis function

    
    P = zeros(size(Qpoints_elem,1) ,dim_elem_R );
    
    Px = zeros(size(Qpoints_elem,1) ,dim_elem_R );
    
    Py = zeros(size(Qpoints_elem,1) ,dim_elem_R );
   
   
    
    
    for i =1:dim_elem_R 
        
        P(:,i)= tensor_leg(Qpoints_elem,m,h,RHHO_ind(i,:));
        
        t = gradtensor_leg(Qpoints_elem,m,h,RHHO_ind(i,:));
        
        Px(:,i) = t(:,1); Py(:,i) = t(:,2); 
    end
  
    %% HHO solution;
    
    coe_HHO_cell = coef(1:dim_elem_inter);
    
    u_HHO_val = P(:,1:dim_elem_inter)*coe_HHO_cell;   % HHO solution;
    
    grad_u_HHO = [Px(:,1:dim_elem_inter)*coe_HHO_cell , Py(:,1:dim_elem_inter)*coe_HHO_cell];   % gradient of R_HHO
   
      % L_2 norm error  int_\kappa (u -u_HHO)^2 dx
    
     s1 = (u_val - u_HHO_val).^2;
        
     L2_part = L2_part+dot((s1),weights_elem);
     
      % H1 semi norm error  int_\kappa (grad_u - grad_u_HHO)^2 dx
    
     
     s2 = a_val_cell.*sum((grad_u_HHO - grad_u_val).^2,2);
          
     H1_part = H1_part+ dot((s2),weights_elem);
    
    
    
    %% Recovered HHO solution
  
    u_R_HHO_val = P*local_R_HHO;   % R_HHO solution;
    
    grad_u_R_HHO = [Px*local_R_HHO , Py*local_R_HHO];   % gradient of R_HHO
    
   
        
    
    
      % L_2 norm error  int_\kappa (u - R u_HHO)^2 dx
    
     t1 = (u_val - u_R_HHO_val).^2;
        
     R_L2_part = R_L2_part+dot((t1),weights_elem);
     
      % H1 semi norm error  int_\kappa (grad_u - grad_u_HHO)^2 dx
    
     
     t2 = a_val_cell.*sum((grad_u_R_HHO - grad_u_val).^2,2);
          
     R_H1_part = R_H1_part+ dot((t2),weights_elem);
    
     
     
     


end


