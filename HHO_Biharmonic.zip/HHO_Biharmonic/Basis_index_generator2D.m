function index = Basis_index_generator2D(Polydegree,Dimension)

    if Dimension ==1
            
      Lege_ind = [0:Polydegree]';  
    
      else
    
if Polydegree == 0
    
    Lege_ind = [ 0 0];
else
    
    Lege_ind = [0 0];
    
for i = 1 : Polydegree 

Lege_ind = [Lege_ind ;multiindex( 2 , i +2) - 1] ;

end


end


end



index = Lege_ind;





end