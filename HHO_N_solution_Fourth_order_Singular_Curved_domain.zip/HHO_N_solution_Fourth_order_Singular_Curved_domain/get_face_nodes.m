function face_nodes = get_face_nodes(local_face_index,Node)

face_nodes = NaN(2,2,size(local_face_index,1));

for k=1:size(local_face_index,1)
   
  temp_nodes = Node(local_face_index(k,:)',:);
  
  
  local_edge_nodes = temp_nodes;

  
   face_nodes(:,:,k) = local_edge_nodes;
    
end

end