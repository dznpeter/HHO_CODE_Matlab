%% Plotting the R-HHO_Solution solutions 

clear all;
%% load tht data from 9411 elements


epsilon = 10^(-1);

Number_Elements = 2266; 

No_Marked_cell = 397; 


Polynomial_order = [1];

Po=Polynomial_order+4;    



Mesh_type = 'curved';   %polygonal, rectangle, curved

Dimension =2;



 load([num2str(Number_Elements) ' ' num2str(Mesh_type) ' Elements.mat'])
 
 
 load(['Error ' num2str(Number_Elements) ' curved Elements P' num2str(Polynomial_order) ' basis epsilon ' num2str(epsilon) '.mat'])
 
Polydegree = Polynomial_order ;  % polynomial degree of DGFEM    

Po=Polydegree+4;         % quadrature order 

alpha = (Polydegree+1).*(Polydegree+Dimension);


Polydegree_elem = Polydegree+2; 

Polydegree_face = Polydegree+2; 

Polydegree_NF_face = Polydegree; 

R_Polydegree = Polydegree+2; 


dim_elem = nchoosek(Polydegree_elem+Dimension,Dimension);   

dim_face = nchoosek(Polydegree_face+Dimension-1,Dimension-1); 

dim_NF_face = nchoosek(Polydegree_NF_face+Dimension-1,Dimension-1); 

% the global index is Element index - Faceindex

dim_total_elem = dim_elem.*NT;

%NF = size(Full_edge);  % There is no boundary basis functions

NF_I = size(intEdge,1);  % There is no boundary basis functions

dim_total_face = dim_face.*NF_I;

dim_total_NF_face = dim_NF_face.*NF_I;

dim_FEM = dim_total_elem + dim_total_face + dim_total_NF_face;

RHHO_ind = Basis_index_generator2D(R_Polydegree,Dimension);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Hession_norm_vec = NaN(NT,1);

%figure 

%hold on
parfor t =1:NT
   
    
    [elem, BDbox, Face_index] = Elem{t,:};     elem_nodes =Node(elem,:);
    
    local_face_index = Full_edge(Face_index,:); 
           
    
    %% deal with the normal vector for the edges 
         
    [out_normal_vectors,~,int_BD_ind] = get_normal_vector(t,Face_index,intnorvec,bdnorvec,int_edge2elem);
       
     NO_intface = sum(int_BD_ind);  % int_BD_ind is the indicator for interior faces
                      
     local_dim_elem = dim_elem + NO_intface*dim_face+ NO_intface*dim_NF_face; 
                
    face_nodes = get_face_nodes(local_face_index,Node);
       
    Global_basis_index = findGlobalindex_int(t,Face_index,int_BD_ind,dim_elem,dim_face,dim_NF_face,dim_total_elem,dim_total_face);
   
    coef = U(Global_basis_index); % c is coefficeint
            
    %% Taking into account of the lifting 
    local_Reconstruction = Reconstruction(:,:,t)+Lifting(:,:,t);
   
     [~, ~,Hessian_u_R_HHO_nodal_value] = Plotting_solution(elem_nodes,BDbox, coef,local_Reconstruction, RHHO_ind,epsilon);

      
       norm_Hessian = mean((max(abs(Hessian_u_R_HHO_nodal_value)'))');  
       
%{       
%       fill3(elem_nodes(:,1),elem_nodes(:,2),norm_Hessian,norm_Hessian);      
%       
%       
%             
%}
       
      %Hessian_u_R_HHO_norm = Plotting_Hessian_norm(elem_nodes,BDbox,Po, coef,local_Reconstruction, RHHO_ind);
      
      %Hession_norm_vec(t) = Hessian_u_R_HHO_norm;
      
      
      Hession_norm_vec(t) = mean(norm_Hessian); % Maximum value for Hessian on each cell
      
end

[~,index ]= sort(Hession_norm_vec);


index_marked_cells = index(NT+1-No_Marked_cell:NT);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



figure 

hold on


for t =1:NT
   
    
    [elem, BDbox, Face_index] = Elem{t,:};     elem_nodes =Node(elem,:);
    
    
   ind = find(index_marked_cells-t==0);
   
    if  isempty(ind) == 0
        
        value = 0.*elem_nodes(:,1);
        
    else
       
         value = elem_nodes(:,1).^0;
        
    end
   
    
    fill3(elem_nodes(:,1),elem_nodes(:,2),value,value,'LineStyle','none'); 
    
end

edge = bdEdge;

%edge = intEdge;

for t = 1:size(edge,1) 

 t1 = [Node(edge(t,1),:); Node(edge(t,2),:)];

plot(t1(:,1), t1(:,2),'k-','LineWidth',4)
 
%xlim([-1 ,1]); ylim([-1 ,1]);

end

hold off;view(2);axis off;

%colorbar;

set(gca,'FontSize',18);