% symbolic 

clear all;

syms x y z s;

u = sin(2*pi*x)^2*sin(2*pi*y)^2;

%latex(u)

ux = diff(u,x,1);  uy = diff(u,y,1); 

uxx = diff(u,x,2);  uyy = diff(u,y,2);

uxxxx = diff(u,x,4);  uyyyy = diff(u,y,4);  uxxyy = diff(uxx,y,2);

f = [ux, uy] ; 

latex(uxxyy)