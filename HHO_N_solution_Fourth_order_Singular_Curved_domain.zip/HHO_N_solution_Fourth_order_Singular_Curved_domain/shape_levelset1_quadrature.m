function [curved_quad_nodes, curved_normal_vec,curved_weight] = shape_levelset1_quadrature(bd_node,no_quadrature)

%% equal weight quadrature for the curve 

%% Change to the curved edges  euqation angle 

r = 1; %sqrt(sum(bd_node(1,:).^2)); % r may differ from 1



BD_theta = atan2(bd_node(:,2),bd_node(:,1));

if abs(BD_theta(1)-BD_theta(2))>pi
 
    id = find(BD_theta - min(BD_theta)==0);
    
    BD_end = BD_theta(id) +2*pi; 
    
    BD_start = BD_theta;  BD_start(id)=[];
    
    BD_theta =[BD_start;BD_end];
    
end    


Theta = linspace(BD_theta(1),BD_theta(2),no_quadrature+1)';

x = r.*cos(Theta);  y = r.*sin(Theta);

curved_quad_nodes = [x,y];

% normial vector for a unit circle is the itself

curved_normal_vec = [r.*cos(Theta), r.*sin(Theta)];

curved_normal_vec = curved_normal_vec./r;

% The length of the arc = r\theta

arclength = r*abs(BD_theta(1)-BD_theta(2)); 


curved_weight = arclength/(no_quadrature+1).*ones(no_quadrature+1,1);



end