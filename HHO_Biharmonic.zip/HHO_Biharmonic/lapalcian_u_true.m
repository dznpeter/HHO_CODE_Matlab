function z = lapalcian_u_true(X)


if size(X,2)~= 2
    
   error('input should be 2 dimensional points')
    
end

x = X(:,1); y = X(:,2);

z = 2.*pi.^2.*cos(pi.*x).^2.*sin(pi.*y).^2 - 4.*pi.^2.*sin(pi.*x).^2.*sin(pi.*y).^2 + 2.*pi.^2.*cos(pi.*y).^2.*sin(pi.*x).^2;

end