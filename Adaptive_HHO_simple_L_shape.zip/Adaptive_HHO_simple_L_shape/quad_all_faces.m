function [Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po)


No_faces = size(face_nodes,3);


[weights,P_Qpoints] = quad_edge(face_nodes(:,:,1),Po);

weights_faces = NaN(size(weights,1),No_faces);  weights_faces(:,1)=weights;

Qpoints_faces = NaN(size(P_Qpoints,1),size(P_Qpoints,2),size(face_nodes,3));

Qpoints_faces(:,:,1) = P_Qpoints;



if No_faces>=2

for k=2:No_faces

    [weights,P_Qpoints] = quad_edge(face_nodes(:,:,k),Po);
    
    weights_faces(:,k)=weights;
    
    Qpoints_faces(:,:,k) = P_Qpoints;

    
end

end

end