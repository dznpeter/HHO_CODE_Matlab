
function [Elem,elem_tri,Node,bdEdge,bd_edge2elem,intEdge,int_edge2elem,intnorvec,bdnorvec,Full_edge,maximum_No_edge_elem] = Refine_poly_Background(refine_marked_elem,Elem,elem_tri,Node)
 
 %% computing the aggolomeration level
 
 NT = size(Elem,1);
 
 %Plotting_marked_polyelements(refine_marked_elem,Elem,Node,elem_tri);
  
 %% Find the auxilary vectors indicating the link between the 
 %% background mesh to polygons
 
 tri2poly = NaN(size(elem_tri,1),1);
 
 for k = 1: NT 
     
     tri_index = Elem{k,1};
     
     tri2poly(tri_index) = k;
     
 end
 

 markedElem_refine_tri = NaN;
 
 %% Find all the elements whose background mesh needs to be refined 
 
 % also update the tri2poly
 
 a_ind = NT;
 
 for k = 1:size(refine_marked_elem,1)
    
     r_ind = refine_marked_elem(k);
     
     local_tri =  Elem{r_ind}; n_tri = size(local_tri,1);
     
     if n_tri == 1 % We only refine triangular elements
     
     markedElem_refine_tri =[markedElem_refine_tri; local_tri];
     
     end
     
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %%%% split the polygons into two polygons made by triangles
     
     BDbox = Elem{r_ind,2};
     
     xlength = BDbox(2,1) - BDbox(1,1); ylength = BDbox(2,2) - BDbox(1,2);
     
     %xmid = (BDbox(2,1) + BDbox(1,1))./2;   ymid = (BDbox(2,2) + BDbox(1,2))./2;
     
     triangle_mesh = elem_tri(local_tri,:); 
     
     centers_tri_mesh = (Node(triangle_mesh(:,1),:) + Node(triangle_mesh(:,2),:)+ Node(triangle_mesh(:,3),:))./3;
     
     xmid = mean(centers_tri_mesh(:,1));  ymid = mean(centers_tri_mesh(:,2));
      
     if xlength>=ylength
    
         sub_poly_tri_index  =  find(centers_tri_mesh(:,1)>=xmid);                  
         
         if size(sub_poly_tri_index,1) == size( triangle_mesh,1)
            
            sub_poly_tri_index = sub_poly_tri_index(1:end-1);
             
         end
         
          new_poly1 = local_tri(sub_poly_tri_index);
        
        new_poly2 = local_tri;  new_poly2(sub_poly_tri_index)=[];
         
     else
         
        sub_poly_tri_index  =  find(centers_tri_mesh(:,2)>=ymid);
        
          if size(sub_poly_tri_index,1) == size(triangle_mesh,1)
            
            sub_poly_tri_index = sub_poly_tri_index(1:end-1);
             
         end
         
         
        new_poly1 = local_tri(sub_poly_tri_index);
        
        new_poly2 = local_tri;  new_poly2(sub_poly_tri_index)=[];
         
     end
     
     
     tri2poly(new_poly1) = r_ind;
     
     % Give new polygal elements
     
     if  n_tri >= 2
        
         tri2poly(new_poly2) =  a_ind + 1 ;
         
         a_ind = a_ind +1;
     end
          
 end
 
markedElem_refine_tri(1,:) =[];

if isempty(markedElem_refine_tri)==1 %% no triagular elements need to bisect

    new_tri2poly = tri2poly;
    
else % adding more resolution for background meshes
    
    
%% The tree structure in back ground meshes is most important 
 

[Node,elem_tri,~,~,tree] = bisect(Node,elem_tri,markedElem_refine_tri);

%% Background mesh has been updated now

new_tri2poly = NaN(size(elem_tri,1),1);
     

new_tri2poly(1:size(tri2poly,1),1) = tri2poly;

%% Tree of bisection may be more than 1 level! Find the level

Tree_level_index = find(tree(:,1)> size(tri2poly,1));

if isempty(Tree_level_index)==1 %% only one level
            
     
%% classify which element are refined and which are due to the conforminty
[~,~,ib] = intersect(sort(markedElem_refine_tri),tree(:,1),'rows');


%% update the new triangles

refine_tree = tree(ib,:); 

new_tri2poly(refine_tree(:,3)) = a_ind+1:a_ind+size(refine_tree,1);

% Refined background meshes and conformite tree


con_tree = tree;   con_tree(ib,:)=[];

% Update the background meshes

new_tri2poly(con_tree(:,3)) = new_tri2poly(con_tree(:,1));

    
else
    
    
    
    Tree_level_index = [0;Tree_level_index-1;size(tree,1)];

for k = 1 :size(Tree_level_index,1)-1

s_level = Tree_level_index(k)+1;   e_level =  Tree_level_index(k+1);
    
if k ==1

%% classify which element are refined and which are due to the conforminty
[~,~,ib] = intersect(sort(markedElem_refine_tri),tree(s_level:e_level,1),'rows');


%% update the new triangles

refine_tree = tree(ib,:); 

new_tri2poly(refine_tree(:,3)) = a_ind+1:a_ind+size(refine_tree,1);

% Refined background meshes and conformite tree


con_tree = tree;   con_tree(ib,:)=[];

% Update the background meshes

new_tri2poly(con_tree(:,3)) = new_tri2poly(con_tree(:,1));

else
    
    con_tree = tree(s_level:e_level,:); 
    
    
    % Update the background meshes

new_tri2poly(con_tree(:,3)) = new_tri2poly(con_tree(:,1));
    
end

end


end

end
%%%%%%%%%%%%%%%

 
 %% Generate all the data structure for aggolomerated meshes
 
 NT = max(new_tri2poly);
 
Elem = cell(NT,3);
 

totalEdge = NaN(1,2);  elemperedge = NaN(NT,1);
 

for i =1: NT
    
    % calculate all the bounding box
    
    Elem{i,1}= find(new_tri2poly == i);
   
    tri = elem_tri(Elem{i,1},:);
    
    bdbox_x = sort(Node(tri(:),1));
    
    bdbox_y = sort(Node(tri(:),2));
    
    Elem{i,2} = [bdbox_x([1,end]) ,  bdbox_y([1,end])]; %bounding box is [x_min y_min
                                                        %                 x_max y_max]  
                                                        
    % take out all the edges  
    
    
    [~,polyEdge] = findboundary(tri);
    
    totalEdge = [totalEdge; polyEdge] ;                                                       
                    
    % label edges per element
    
    elemperedge(i) = size(polyEdge,1);
end

maximum_No_edge_elem = max(elemperedge);

elemtotaledge = cumsum(elemperedge);

totalEdge(1,:)=[]; 
 
totalEdge = sort(totalEdge, 2); 

[i , j ,s ] = find(sparse(totalEdge(:,2),totalEdge(:,1),1));

bdEdge = [j(s==1), i(s==1)]; intEdge = [j(s==2), i(s==2)];

int_edge2elem = NaN(size(intEdge,1),2); bd_edge2elem = NaN(size(bdEdge,1),1);


parfor i = 1: size(intEdge,1)
   
    edge2elem = elem_share_edge(intEdge(i,:),totalEdge,elemtotaledge);
    
    int_edge2elem(i,:) =   edge2elem';
    
end

parfor i = 1: size(bdEdge,1)
   
    edge2elem = elem_share_edge(bdEdge(i,:),totalEdge,elemtotaledge);
    
    bd_edge2elem(i,1) =   edge2elem; 
    
end

%% get the correct normal vector

 intnorvec =  NaN(size(intEdge,1),2);  bdnorvec =  NaN(size(bdEdge,1),2);  

parfor i = 1: size(intEdge,1)
   
    %% find this edge without using backgroung meshes
    
    localEdge = intEdge(i,:);
    
    local_elem = int_edge2elem(i,1); %% find the element 1
    
    tri1 = elem_tri(Elem{local_elem,1},:);  
    
    %% find the triangles sharing this edge
    
    I1 = abs(prod(tri1 - localEdge(1),2));  I2 = abs(prod(tri1 - localEdge(2),2));
    
    % K_tri is the triangles sharing this edge inside the polygons
    
    index = find(I1+I2==0);       K_tri = tri1(index,:)';
    
    t_vec = Node(localEdge(1),:)-Node(localEdge(2),:);
    
    n = [t_vec(2), -t_vec(1)]./norm(t_vec);
        
    P = sum(Node(K_tri,:))./3; % P is the barycentre of tri
        
    test_vec = Node(localEdge(1),:)-P;
    
    test = dot(test_vec,n);
                
    if  test > 0
        
        intnorvec(i,:) = n;
        
    else
        
        intnorvec(i,:) = -n;
        
    end
        
    
end



parfor i = 1: size(bdEdge,1)
   
    %% find this edge from backgroung meshes
    
    localEdge = bdEdge(i,:);
    
    local_elem = bd_edge2elem(i,1);
    
    tri1 = elem_tri(Elem{local_elem,1},:);
    %% find the triangles sharing this edge
    
    I1 = abs(prod(tri1 - localEdge(1),2));  I2 = abs(prod(tri1 - localEdge(2),2));
    
    % K_tri is the triangles sharing this edge inside the polygons
    
    index = find(I1+I2==0);       K_tri = tri1(index,:)';
           
    t_vec = Node(localEdge(1),:)-Node(localEdge(2),:);
    
    n = [t_vec(2), -t_vec(1)]./norm(t_vec);
    
    P = sum(Node(K_tri,:))./3    
    
    test_vec = Node(localEdge(1),:)-P;
    
    test = dot(test_vec,n);
    
    
    if  test > 0
        
        bdnorvec(i,:) = n;
        
    else
        
        bdnorvec(i,:) = -n;
        
    end
                         
end


%%%%%%%%%%%%%%%finding all the information about the element edges%%%%%%%%%%%


 
%% find each element contains which edge
% the global index of edge is based as inter_edge, BD_edge
  
parfor i = 1: NT
    
 index_int1 = find(int_edge2elem(:,1) == i);
 
 index_int2 = find(int_edge2elem(:,2) == i);
 
 index_bd =  find(bd_edge2elem(:) == i);
 
    
    Elem{i,3}= [index_int1; index_int2; index_bd+size(intEdge,1)];
       
end


Full_edge = [intEdge;bdEdge];


  