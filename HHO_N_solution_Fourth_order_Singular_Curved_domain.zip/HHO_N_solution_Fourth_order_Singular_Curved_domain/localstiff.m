function [local_stiff,local_reconstruction,local_lifting, local_R_time, local_S_time] = localstiff(elem_nodes,face_nodes,BDbox,alpha, out_normal_vectors,wrap_N,int_BD_ind,local_dim_elem,Po,HHO_elem_ind,HHO_face_ind, HHO_NF_face_ind,RHHO_ind,assume_dim_elem,epsilon)

                                    

NF = size(face_nodes,3); % number of total edges

NO_intface = sum(int_BD_ind); % number of total edges

interior_face_ind= find(int_BD_ind~=0);

% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);


[Qpoints_elem,weights_elem]=quad_poly(elem_nodes,Po); % get the quadrature points on polygon

%% find the quadtrature points on each edge

[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);



% 
tic;
initime = cputime;
% 
% 
% fintime = cputime;
% elapsed = toc;
% 
% 
% 


%%%%%%%%%%%%%%%%%%%%%%%%Local reconstruction%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Get the information for the interior faces 
int_face_nodes= face_nodes(:,:,interior_face_ind);

int_Qpoints_faces= Qpoints_faces(:,:,interior_face_ind);

int_weights_faces = weights_faces(:,interior_face_ind);

int_out_normal_vectors = out_normal_vectors(interior_face_ind,:);


 
    
dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 

dim_elem_cell = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 

dim_elem_face = size(HHO_face_ind,1); % Dimention for face basis on each individual face 

dim_elem_NF_face = size(HHO_NF_face_ind,1); % Dimention for face basis of normal flux variables on each individual face 

%% Remove the constant polynomials 

S = zeros(dim_elem_R-1,dim_elem_R-1); 

for i = 1:dim_elem_R-1
   
    %%symetric term
    
    for j=i:dim_elem_R-1
    
        % first term epsilon*{ \Delat(u)  \Delta(v)} + ({ \nabla(u)  \nabla (v)}) is symetric
            
        grad1 = gradtensor_leg(Qpoints_elem,m,h,RHHO_ind(i+1,:));
        
        grad2 = gradtensor_leg(Qpoints_elem,m,h,RHHO_ind(j+1,:));
        
        
        Hessian1 = Hessian_leg(Qpoints_elem,m,h,RHHO_ind(i+1,:));
        
        Hessian2 = Hessian_leg(Qpoints_elem,m,h,RHHO_ind(j+1,:));
        
        s = sum(grad1.*grad2,2);
        
        t =  epsilon.*sum(Hessian1.*Hessian2,2);
        
        
        
        S(i,j) = dot(t+s,weights_elem);
        
    end
end

%%symetric term

S = S + (triu(S,1))';


%Condition_NO_local = condest(S)

%% the rectangular matrix V1 contains the information of v_K on cell and face
% The index for i and j is the other way around compare to the previous 

V1 = zeros(dim_elem_R-1,local_dim_elem); 



for i = 1:dim_elem_R-1
   
    
    for j = 1:dim_elem_cell
    
        % element intergral stiffness
                        
        
        Laplacian_W = Laplacian_leg(Qpoints_elem,m,h,RHHO_ind(i+1,:));
        
        Biharmonic_W = biLaplacian_leg(Qpoints_elem,m,h,RHHO_ind(i+1,:));
        
        VK = tensor_leg(Qpoints_elem,m,h,HHO_elem_ind(j,:));
        
        
        s1 =  - VK.*Laplacian_W;
        
        t1 =  epsilon.*VK.*Biharmonic_W;
        
        val1 =  dot(t1+s1,weights_elem);          
        
        V1(i,j) = val1;
        
    end
end




BD_Lifting = zeros(dim_elem_R-1,local_dim_elem,NF-NO_intface); 



for i = 1:dim_elem_R-1
   
    
    for j=1:dim_elem_cell
             
        
        for k= NO_intface+1:NF
                        
            
            % For the HHO-N all the faces are used for V_K
            
            local_edges_nodes = face_nodes(:,:,k);
            
            n_vec = out_normal_vectors(k,:);
            
            temp_vec = (local_edges_nodes(2,:)-local_edges_nodes(1,:));                       
             
            t_vec = temp_vec./norm(temp_vec);
           
            VK_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
            
            grad_VK_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
             
             
            grad_W_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+1,:));
             
            Hessian_W_trace = Hessian_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+1,:));
                        
            gradLaplacian_W_trace = gradLaplacian_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+1,:));
                                    
            %% adding the normal tangential vectors
            
            NGrad_W = (grad_W_trace(:,1).*n_vec(1)+grad_W_trace(:,2).*n_vec(2));
            
            
            NGradLaplacian_W = (gradLaplacian_W_trace(:,1).*n_vec(1)+gradLaplacian_W_trace(:,2).*n_vec(2));
            
            NFL_VK_trace = (grad_VK_trace(:,1).*n_vec(1)+grad_VK_trace(:,2).*n_vec(2));
            
            TFL_VK_trace = (grad_VK_trace(:,1).*t_vec(1)+grad_VK_trace(:,2).*t_vec(2));
                       
            Partial_NN_W =  n_vec(1).*n_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*n_vec(2).*Hessian_W_trace(:,2)...
                            +n_vec(2).*n_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*n_vec(2).*Hessian_W_trace(:,4);
                        
            Partial_NT_W =  n_vec(1).*t_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*t_vec(2).*Hessian_W_trace(:,2)...
                            +n_vec(2).*t_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*t_vec(2).*Hessian_W_trace(:,4);
          
                        
            
           s = - VK_trace.*NGrad_W;           
                        
                        
            % (v_K, \partial_n \Delta w_K)
            
           temp1 = VK_trace.*NGradLaplacian_W;                        
            
            % (\partial_n v_K, \partial_{nn} w_K) +  (\partial_t v_K, \partial_{nt} w_K)
                          
           temp2 = NFL_VK_trace.* Partial_NN_W;
            
           temp3 = TFL_VK_trace.* Partial_NT_W;
            
            
           t =  epsilon.*(temp1  -  temp2 - temp3);
           
           

            Temp = s + t;
            
            trace = dot(Temp,weights_faces(:,k));
            
           
            BD_Lifting(i,j,k-NO_intface) = trace;
            
          
            
        end
                     
        
       
    end
end

%% we only need the boundary liftings

 BD_Lifting =  sum(BD_Lifting,3);

%%  Assembling for the trace variable v_{\parital K} on the interior faces


V2 = zeros(dim_elem_R-1,local_dim_elem); 


for i = 1:dim_elem_R-1
   
    
    for j= dim_elem_cell+1:dim_elem_cell+NO_intface*dim_elem_face
           
        
        % the trace term on each interior faces
        
        val = 0; 
        
         % face k, use different face basis, quadratures
         
           k = floor((j-dim_elem_cell-0.5)./dim_elem_face)+1;
            
             
            local_edges_nodes = int_face_nodes(:,:,k);
            
            n_vec = int_out_normal_vectors(k,:);
            
            temp_vec = (local_edges_nodes(2,:)-local_edges_nodes(1,:));                       
             
            t_vec = temp_vec./norm(temp_vec);
            
            
            j_face = j-dim_elem_cell-(k-1)*dim_elem_face;
           
            %% Othrognoal basis  for the face basis
                         
             V_PK_trace = Face_baisis(int_Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j_face,:));  
             
             Tangential_V_PK_trace = Tangent_Face_baisis(int_Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j_face,:));                            
             
             %grad1_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+3,:));            
             
             grad_W_trace = gradtensor_leg(int_Qpoints_faces(:,:,k),m,h,RHHO_ind(i+1,:));                         
             
             Hessian_W_trace = Hessian_leg(int_Qpoints_faces(:,:,k),m,h,RHHO_ind(i+1,:));
                        
             gradLaplacian_W_trace = gradLaplacian_leg(int_Qpoints_faces(:,:,k),m,h,RHHO_ind(i+1,:));
                   
            %%  Adding the normal and tangential vector
             
            NGrad_W = (grad_W_trace(:,1).*n_vec(1)+grad_W_trace(:,2).*n_vec(2));
             
            NGradLaplacian_W = (gradLaplacian_W_trace(:,1).*n_vec(1)+gradLaplacian_W_trace(:,2).*n_vec(2));
            
           % NFL_VK_trace = (grad_VK_trace(:,1).*n_vec(1)+grad_VK_trace(:,2).*n_vec(2));
            
           % TFL_VK_trace = (grad_VK_trace(:,1).*t_vec(1)+grad_VK_trace(:,2).*t_vec(2));
                       
           % Partial_NN_W =  n_vec(1).*n_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*n_vec(2).*Hessian_W_trace(:,2)...
           %                 +n_vec(2).*n_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*n_vec(2).*Hessian_W_trace(:,4);
                        
            Partial_NT_W =  n_vec(1).*t_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*t_vec(2).*Hessian_W_trace(:,2)...
                            +n_vec(2).*t_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*t_vec(2).*Hessian_W_trace(:,4);
          
                        
            
            s = V_PK_trace.*NGrad_W;                   
                        
             
           % (v_{\partial K}, \partial_n \Delta w_K)
            
            temp1 = V_PK_trace.*NGradLaplacian_W;
            
           %  (\patial_t v_{\partial K}, \partial_{nt} w_K)
            
            temp3 = Tangential_V_PK_trace.* Partial_NT_W;
            
            
            t = epsilon.*(-temp1 + temp3);
            
            
            Temp = t+s;
            
            trace = dot(Temp ,int_weights_faces(:,k));
            
            val = val+trace;            
                     
        
        V2(i,j) = val;
        
    end
end



%%  Assembling for the normal flux trace variable v_{N \parital K}


V3 = zeros(dim_elem_R-1,local_dim_elem); 


for i = 1:dim_elem_R-1
   
    
    for j= dim_elem_cell+NO_intface*dim_elem_face+1:local_dim_elem
           
        
        % the trace term on each face
        
        val = 0;  
        
         % face k, use different interiori face basis, quadratures
         
        k = floor((j-dim_elem_cell-NO_intface*dim_elem_face-0.5)./dim_elem_NF_face)+1;
            
            local_edges_nodes =int_face_nodes(:,:,k);
                        
            n_vec = int_out_normal_vectors(k,:);  local_wrap = wrap_N(k);
            
            indicator = (-1)^local_wrap; % To see if the normal vector is take in a correct way
            
            j_face = j-dim_elem_cell-NO_intface*dim_elem_face-(k-1)*dim_elem_NF_face;
           
            %% Othrognoal basis  for the face basis
                         
                         
             V_NF_PK_trace =  Normal_Face_baisis(int_Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(j_face,:));  
                           
             
             Hessian_W_trace = Hessian_leg(int_Qpoints_faces(:,:,k),m,h,RHHO_ind(i+1,:));
                                           
             
             
           % NGradLaplacian = (gradLaplacian_W_trace(:,1).*n_vec(1)+gradLaplacian_W_trace(:,2).*n_vec(2));
            
           % NFL_VK_trace = (grad_VK_trace(:,1).*n_vec(1)+grad_VK_trace(:,2).*n_vec(2));
            
           % TFL_VK_trace = (grad_VK_trace(:,1).*t_vec(1)+grad_VK_trace(:,2).*t_vec(2));
                       
            Partial_NN_W =  n_vec(1).*n_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*n_vec(2).*Hessian_W_trace(:,2)...
                            +n_vec(2).*n_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*n_vec(2).*Hessian_W_trace(:,4);
                        
           % Partial_NT_W =  n_vec(1).*t_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*t_vec(2).*Hessian_W_trace(:,2)...
           %                 +n_vec(2).*t_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*t_vec(2).*Hessian_W_trace(:,4);
          
                        
                                     
           %  (\patial_t v_{\partial K}, \partial_{nt} w_K)
            
            temp3 = epsilon.*indicator.*V_NF_PK_trace.* Partial_NN_W;
            
            
            Temp = temp3;
            
            trace = dot(Temp ,int_weights_faces(:,k));
            
            val = val+trace;            
                     
        
        V3(i,j) = val;
        
    end
end



%% The RHS of the reconstrction operator is done

V = V1+V2+V3;

%% The reconstruction operator is defined as R = S^{-1}*V

S_inv = inv(S);

R = S_inv*V;

A1 = V'*S_inv*V;

Lifting = -S_inv*BD_Lifting;





fintime = cputime;
elapsed = toc;


local_R_time = fintime - initime;





%%%%%%%%%%%%%%%%%%%%%%%%Stabilisation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% We start with computing the mass matrces and the difference matrices 
%% Lehrenfeld-schoberl stabilisation

%% Next is the face element matrix and face face matrix. The matrix depends on the number of faces.

% there is totally NF faces, stabilisation is done on each face

%% After computing the Difference matrix, we can compute the stabilisation term on each edge

% penalty parameter is from trace inverse inequality, we can use h_k

h_k = norm(BDbox(2,:)-BDbox(1,:));  % it should not be h_f

alpha = alpha/h_k; % from the stability estimates  

%% The indicator for the singular pertubed parameter \epsilon

sigma = max(1,epsilon.*alpha^2);


%% Computing the stabilisation for the face variable term
% the difficulty is to compute the H1 Proejctions




tic;
initime = cputime;




A_stab_int_Face = zeros(local_dim_elem,local_dim_elem,NO_intface);


%%  we need to seperate the cases of iclc
%interior and boundary face


for k=1:NO_intface
    
    
    local_edges_nodes = face_nodes(:,:,k);
    
    % compute the MFF matrix, this matrix is diagonal but not identity
    
M_FF = zeros(dim_elem_face,dim_elem_face);    

% compute the H1 projection, first compute the Mass marix

for i = 1:dim_elem_face
   
    %%symetric term      
    
    
    for j=1:dim_elem_face
        
        
    
        % first term uv is symetric                
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        V_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j,:)); 
        
        t =  sum(U_trace.*V_trace,2);
        
        M_FF(i,j) = dot(t,weights_faces(:,k)); %  for the trace variables
                        
    end                       
                    
end


%{
H_FF = M_FF; 


    %% Change the Mass matrix to H1 by modifying the last two lines  
            
      
       for j = 1:dim_elem_face
                           
        
        H_FF([dim_elem_face-1,dim_elem_face],j) =  Face_basis_Nodal_value(local_edges_nodes,HHO_face_ind(j,:));
        
       end
    
   

 H_FF_inv = inv(H_FF);   

%}
 
 M_FF_inv = inv(M_FF);     
    
 %% computing the matrix M_FT
 
 
 M_FT_all = zeros(dim_elem_face,dim_elem_cell);  
    
 
for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_cell
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        R_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
        
        t =  sum(U_trace.*R_trace,2);
        
         M_FT_all(i,j) = dot(t,weights_faces(:,k));
        
    end
end

% M_FT_p is the first p part

M_FT_p = M_FT_all(1:dim_elem_face,1:dim_elem_cell);


%{
H_FT_p = M_FT_p ;



 %% Change the Mass matrix to H1 by modifying the last two lines  
            
       for j = 1:dim_elem_cell
                           
        
        H_FT_p([dim_elem_face-1,dim_elem_face],j) =  tensor_leg(local_edges_nodes,m,h,HHO_elem_ind(j,:));
        
       end
    


%Define the difference operator on each face

H1_Proj_TF = H_FF_inv*H_FT_p; 

%}

 
Proj_TF = M_FF_inv*M_FT_p; 

% D_TF is dim_elem_face * local_dim_elem

D_TF=  zeros(dim_elem_face,local_dim_elem);

%D_TF(1:dim_elem_face,1:dim_elem_cell) = H1_Proj_TF;

D_TF(1:dim_elem_face,1:dim_elem_cell) = Proj_TF;


% Find the index of the face basis 

index_face_local = dim_elem_cell+((k-1)*dim_elem_face+1:k*dim_elem_face);



D_TF(:,index_face_local) = - eye(dim_elem_face);


%% After computing the Difference matrix, we can compute the stabilisation term on each edge


% the stabilisation operator

T = D_TF;



A_stab_int_Face(:,:,k) = alpha.*sigma.*T'*M_FF*T;

 
end


% sum all each stabiulisation on each face 

A_int_stab = sum(A_stab_int_Face,3);







%% Computing the stabilisation for the normal flux face variable term

A_NF_stab_int_Face = zeros(local_dim_elem,local_dim_elem,NO_intface);



for k=1:NO_intface
    
    
    local_edges_nodes =face_nodes(:,:,k);
    
    % compute the MFF matrix, this matrix is diagonal but not identity
    
M_FF_NF = zeros(dim_elem_NF_face,dim_elem_NF_face);    
    




for i = 1:dim_elem_NF_face
   
    %%symetric term
    
    for j=1:dim_elem_NF_face
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(i,:)); 
        
        V_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(j,:)); 
        
        t =  sum(U_trace.*V_trace,2);
        
        M_FF_NF(i,j) = dot(t,weights_faces(:,k)); %  for the trace variables
        
    end
end

    
 M_FF_NF_inv = inv(M_FF_NF);   
    
    
 %% computing the matrix M_FT
 
 
M_FT_NF = zeros(dim_elem_NF_face,dim_elem_cell);  
    

n_vec = out_normal_vectors(k,:); local_wrap = wrap_N(k);

 indicator = (-1)^local_wrap; % To see if the normal vector is take in a correct way
           
 
for i = 1:dim_elem_NF_face
   
    %%symetric term
    
    for j=1:dim_elem_cell
    
        % first term uv is symetric
                    
        U_trace =  Normal_Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(i,:)); 
        
        %U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(i,:));         
        
        grad_R_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
        
        NF_R_trace = n_vec(1).*grad_R_trace(:,1)+ n_vec(2).*grad_R_trace(:,2);
        
        t =  indicator.*U_trace.*NF_R_trace;
        
        M_FT_NF(i,j) = dot(t,weights_faces(:,k));
        
    end
end



%Define the difference operator on each face

Proj_TF_NF =  M_FF_NF_inv*M_FT_NF; 

% D_TF is dim_elem_face * local_dim_elem

D_TF_NF=  zeros(dim_elem_NF_face,local_dim_elem);

D_TF_NF(1:dim_elem_NF_face,1:dim_elem_cell) = Proj_TF_NF;



% Find the index of the face basis for normal flux 

index_NF_face_local = dim_elem_cell+NO_intface*dim_elem_face+((k-1)*dim_elem_NF_face+1:k*dim_elem_NF_face);

%% if the different direction of the normal flux variables are given, we need to be carefull

    
D_TF_NF(:,index_NF_face_local) = - eye(dim_elem_NF_face);

%% After computing the Difference matrix, we can compute the stabilisation term on each edge


% the stabilisation operator

T_NF = D_TF_NF;


A_NF_stab_int_Face(:,:,k) = alpha^(-1).*sigma.*T_NF'*M_FF_NF*T_NF;

 
end

%% sum all each stabiulisation on each face 

A_NF_int_stab = sum(A_NF_stab_int_Face,3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Adding the Nischel boundary term!!!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



A_N_Bd_Face = zeros(local_dim_elem,local_dim_elem,NF-NO_intface);

if NF ~= NO_intface
    
    
%%  we need to seperate the cases of interior and boundary face


for k=1+NO_intface:NF
    
    
    local_edges_nodes = face_nodes(:,:,k);
    
    % compute the MFF matrix, this matrix is diagonal but not identity
    
M_S_FF = zeros(dim_elem_cell,dim_elem_cell);    

% compute the H1 projection, first compute the Mass marix

for i = 1:dim_elem_cell
   
    %%symetric term      
    
    
    for j=1:dim_elem_cell
        
        
    
        % first term uv is symetric     
        
        VK_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
            
        grad_VK_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
        
        
        WK_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(i,:));
            
        grad_WK_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(i,:));
       
                                      
        t = sigma.*alpha.*VK_trace.*WK_trace;
        
        s = epsilon.*alpha.*sum(grad_VK_trace.*grad_WK_trace,2);
            

        
        M_S_FF(i,j) = dot(t+s,weights_faces(:,k)); %  for the trace variables
                        
    end                       
                    
end




A_N_Bd_Face(1:dim_elem_cell,1:dim_elem_cell,k-NO_intface) = M_S_FF;

 
end

end
% sum all each stabiulisation on each face 

A_N_Bd_Face = sum(A_N_Bd_Face,3);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% get the final local stiffness matrix 

local_stiff = A1+A_int_stab+ A_NF_int_stab+A_N_Bd_Face;





fintime = cputime;
elapsed = toc;


local_S_time = fintime - initime;





%% Put the local reconstruction operator 

local_reconstruction = zeros(size(R,1),assume_dim_elem);


local_reconstruction(:,1:size(R,2))= R;

local_lifting = zeros(size(Lifting,1),assume_dim_elem);

local_lifting(:,1:size(Lifting,2))= Lifting;


end

