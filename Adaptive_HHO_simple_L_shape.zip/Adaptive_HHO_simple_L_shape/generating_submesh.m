function submesh = generating_submesh(elem,Node)

Ntri = size(elem,1);

submesh = NaN(3,2,Ntri);

for i = 1:Ntri
   
    
    submesh(:,:,i) = Node(elem(i,:)',:);
    
end


end
