% plotting edge


figure; hold on;


%edge = inflowBDEdge


edge = bdEdge;

%edge = intEdge;

for t = 1:size(edge,1) 

 t1 = [Node(edge(t,1),:); Node(edge(t,2),:)];

plot(t1(:,1), t1(:,2),'b-','LineWidth',1,'MarkerSize',5)
 
%xlim([-1 ,1]); ylim([-1 ,1]);

end




edge = intEdge;

for t = 1:size(edge,1) 

 t1 = [Node(edge(t,1),:); Node(edge(t,2),:)];

plot(t1(:,1), t1(:,2),'r-.','LineWidth',1,'MarkerSize',5)
 
xlim([-1 ,1]); ylim([-1 ,1]);

end

%%%%%%%%%%%%%plot the boundary edge flux%%%%%%%%%%%%%
% 
% bi_mid_vec = 0.5*(Node(bdEdge(:,1),:)+Node(bdEdge(:,2),:));
% 
% plot(bi_mid_vec(:,1), bi_mid_vec(:,2),'*k','LineWidth',1,'MarkerSize',5);
% 
% 
% for t=1:size(bi_mid_vec,1)
% 
% quiver(bi_mid_vec(t,1),bi_mid_vec(t,2),bdnorvec(t,1)./5,bdnorvec(t,2)./5,0,'LineWidth',1,'AutoScaleFactor',0.1);
% 
% end
% 


