function [curved_quad_nodes, curved_normal_vec,curved_weight] = shape_levelset2_quadrature(bd_node,no_quadrature)

  
%% Change to the curved edges  euqation angle 


r = 0.4; %sqrt(sum((bd_node(1,:)-0.25).^2)); % r may differ from 0.4



BD_theta = atan2(bd_node(:,2)-0.25,bd_node(:,1)-0.25);




if abs(BD_theta(1)-BD_theta(2))>pi
 
    id = find(BD_theta - min(BD_theta)==0);
    
    BD_end = BD_theta(id) +2*pi; 
    
    BD_start = BD_theta;  BD_start(id)=[];
    
    BD_theta =[BD_start;BD_end];
    
end    


Theta = linspace(BD_theta(1),BD_theta(2),no_quadrature+1)';


        
%% Change to the curved edges 

x = 0.25+r.*cos(Theta);  y = 0.25+r.*sin(Theta);

curved_quad_nodes = [x,y];

% normial vector for a unit circle is the itself

curved_normal_vec = -[r.*cos(Theta), r.*sin(Theta)];

curved_normal_vec = curved_normal_vec./r;

arclength = r*abs(BD_theta(1)-BD_theta(2)); 

curved_weight = arclength/(no_quadrature+1).*ones(no_quadrature+1,1);



end