%% data for compute

syms x y 

%%%%%%%%%%%%%


u = sin(pi*x)^2*sin(pi*y)^2+exp(-(x-0.5)^2-(y-0.5)^2)

%u = (x^2 - 4)^2.*(y^2 - 4)^2;

%u =r^(4/3)*(x*(1-x^2)*y*(1-y^2))^2

ux = diff(u, x);  uy = diff(u, y);

ux

uy

%grad_u = [ux, uy]

uxx = diff(u, x,2);  uyy = diff(u, y,2);  uxy = diff(ux, y);

%laplace_u = uxx+uyy

uxx

uxy

uyy


%grad_laplace_ux = diff(laplace_u,x)  

%grad_laplace_uy = diff(laplace_u,y)


%%



uxxxx = diff(uxx, x,2);

uxxyy = diff(uxx, y,2);

uyyyy = diff(uyy, y,2);

f= uxxxx + 2*uxxyy + uyyyy


%%

%triharmonic_u = diff(u, x,6) + diff(u, y ,6) ...
%               + 3* diff(diff(u, x,4) , y,2) + 3* diff(diff(u, y,4) , x,2)

