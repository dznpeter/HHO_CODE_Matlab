%close all;
%% different elements we use different order of basis

NO_Elements = [65,109,527,2266,9411]; 


%color = {'b','r','g','k','y'};

Marker = {'s','p','^','o','*','>'};

L2=figure;

slope_Poly = NaN(1,5);

order= 3;  

Mesh_type = 'curved';  % rectangle, polygonal, curved

Norm_type = 'R_E';  %'R_L2', 'R_E'

epsilon = 10^(0)*0;



for k = 0:order


%% plotting errors for the L2 norm for p refinement

%%P basis


Polynomial_degree = k;   

NO_elem = NO_Elements;   

err_P = NaN(length(NO_elem),1); dof_P = NaN(length(NO_elem),1);


for i=1 :length(NO_elem)
       
load(['Error ' num2str(NO_elem(i)) ' ' Mesh_type ' Elements P'  num2str(Polynomial_degree) ' basis epsilon ' num2str(epsilon) '.mat'])

switch  Norm_type
    
    case 'R_L2' 

err_P(i,1)=R_L2_err;    

    case 'R_E'
        
err_P(i,1)=R_E_err; 


    case 'CL2' 

err_P(i,1)=CL2_err; 
 

 case 'Sta' 

err_P(i,1)=Stabilisation_err;
       
end

dof_P(i) = dim_linear_system;
end

%slope for poly

logerr_P1 = abs(log(err_P(:,1))); 

slope_P1 = abs((logerr_P1(2:end)-logerr_P1(1:end-1))./(log(dof_P(2:end).^(1./2))-log(dof_P(1:end-1).^(1./2))));


%slope_Poly(k+1) = max(mean(slope_P1(end-1:end)), max(slope_P1));


slope_Poly(k+1) = max(slope_P1(end-1:end));

%slope_Poly(k+1) = slope_P1(end);


switch Mesh_type 
    
    case 'curved'

loglog(dof_P.^(1./2),err_P(:,1),['r-' num2str(Marker{k+1})],'LineWidth',2,'MarkerSize',10);

    case 'polygonal'
        
loglog(dof_P.^(1./2),err_P(:,1),['k:' num2str(Marker{k+1})],'LineWidth',2,'MarkerSize',10);
        
end
hold on;

end


switch Mesh_type 
    
    case 'curved'

legend(['curve k0 slope ' num2str(slope_Poly(1))]...
      ,['curve k1 slope ' num2str(slope_Poly(2))]...
      ,['curve k2 slope ' num2str(slope_Poly(3))]...
      ,['curve k3 slope ' num2str(slope_Poly(4))]...
      ,['curve k4 slope ' num2str(slope_Poly(5))]...
      ,'Location','SouthWest')

  
    case 'polygonal'
%         
% legend('HHO k0'...
%       ,'HHO k1'...
%       ,'HHO k2'...
%       ,'HHO k3'...
%       ,'Location','SouthWest')

% legend('poly k0'...
%       ,'poly k1'...
%       ,'poly k2'...
%       ,'poly k3'...
%       ,'poly k4'...
%       ,'Location','SouthWest')
 
legend(['HHO (2) poly k0 slope ' num2str(slope_Poly(1))]...
      ,['HHO (2) poly k1 slope ' num2str(slope_Poly(2))]...
      ,['HHO (2) poly k2 slope ' num2str(slope_Poly(3))]...
      ,['HHO (2) poly k3 slope ' num2str(slope_Poly(4))]...
      ,['HHO (2) poly k4 slope ' num2str(slope_Poly(5))]...
      ,'Location','SouthWest')

 

  
end


xlabel('$\sqrt{DoFs}$','FontSize',20,'Interpreter','latex');

switch  Norm_type
    
    case 'R_L2' 

ylabel('$||u-R(u_h)||_{L_2(\Omega)}$','FontSize',20,'Interpreter','latex');


    case 'R_E'

ylabel('$|u-R(u_h)|_{E,\varepsilon}$','FontSize',20,'Interpreter','latex');

 
 case 'CL2' 

ylabel('||\Pi_p u-u_h||_{L_2(\Omega)}','FontSize',20);


case 'Sta' 

ylabel('S(u_h,u_h)','FontSize',20);

       
end


set(gca,'FontSize',18)

%title(['L2 norm error under h-refinement penalty ' num2str(penalty) ],'FontSize',20)

%saveas(L2,['Poisson_L2_norm_error_h_refine_penalty_' num2str(penalty) ],'fig');

%print(L2,'-depsc',['Poisson_L2_norm_error_h_refine_penalty_' num2str(penalty) '.eps']);





