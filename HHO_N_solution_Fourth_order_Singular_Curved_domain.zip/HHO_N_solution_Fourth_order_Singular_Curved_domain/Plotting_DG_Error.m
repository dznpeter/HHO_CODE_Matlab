
%% plotting errors for the DG for p refinement

Polynomial_degree = 0:4;    penalty=10;

NO_elem = [4,16,64,256,1024,4096];

errL_2 =NaN(length(Polynomial_degree),1); dof = NaN(length(Polynomial_degree),1);

Mesh_type = 'polygonal';  % rectangle, polygonal

Norm_type = 'L2';  %'L2', 'H1' , 'DG'  

figure;

for i=1 :length(Polynomial_degree)
    
    
%load(['Error ' num2str(NO_elem(i)) ' ' Mesh_type ' Elements penalty ' num2str(penalty) ' P'  num2str(Polynomial_degree) ' basis.mat'])

load(['Error ' num2str(NO_elem) ' ' Mesh_type ' Elements P' num2str(Polynomial_degree(i)) ' basis.mat'])


%load(['Error ' num2str(NO_elem) ' polygonal Elements penalty ' num2str(penalty) ' P' num2str(Polynomial_degree(i)) ' basis.mat'])

switch  Norm_type
    
    case 'L2' 

errL_2(i)=L2_err; 

    case 'H1'
        
errL_2(i)=H1_err; 
 
       
end
dof(i) = dim_FEM;

end

switch Mesh_type
    
    case 'rectangle'

semilogy(dof.^0.5,errL_2,'r-s','LineWidth',2,'MarkerSize',10);

legend([num2str(NO_elem) ' rect DG(P)'])

    case 'polygonal'
        
%semilogy(dof.^0.5,errL_2,'k:s','LineWidth',2,'MarkerSize',10);

semilogy(Polynomial_degree,errL_2,'k:s','LineWidth',2,'MarkerSize',10);


legend([num2str(NO_elem) ' poly DG(P)'])

end 


%xlabel('Dof^{1/2}','FontSize',18);

xlabel('$p$','FontSize',18);

switch  Norm_type
    
    case 'L2' 

ylabel('||u-u_h ||_{L_2(\Omega)}','FontSize',20);


    case 'H1'

ylabel('|u-u_h |_{H^1(\Omega)}','FontSize',20);


 
       
end

set(gca,'FontSize',20)

%title('P refinement','FontSize',20)




