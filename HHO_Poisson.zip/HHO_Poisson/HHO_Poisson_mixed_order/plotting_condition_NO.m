
%% plotting errors for the DG for p refinement

Polynomial_degree = 0:1;    penalty=10;

NO_elem = [16,64,256,1024,4096];

errL_2 =NaN(length(Polynomial_degree),1); dof = NaN(length(Polynomial_degree),1);

Mesh_type = 'polygonal';  % rectangle, polygonal


figure;

for i=1 :length(Polynomial_degree)
    
    
%load(['Error ' num2str(NO_elem(i)) ' ' Mesh_type ' Elements P'  num2str(Polynomial_degree(i)) ' basis.mat'])

load(['Error ' num2str(NO_elem(i)) ' ' Mesh_type ' Elements P' num2str(Polynomial_degree(i)) ' basis.mat'])


%load(['Error ' num2str(NO_elem) ' polygonal Elements penalty ' num2str(penalty) ' P' num2str(Polynomial_degree(i)) ' basis.mat'])


errL_2(i)=Condition_NO; 


dof(i) = dim_FEM;

end

switch Mesh_type
    
    case 'rectangle'

loglog(dof.^0.5,errL_2,'r-s','LineWidth',2,'MarkerSize',10);

legend([num2str(NO_elem) ' rect DG(P)'])

    case 'polygonal'
        
loglog(dof.^0.5,errL_2,'r-s','LineWidth',2,'MarkerSize',10);


legend([num2str(NO_elem) ' poly DG(P)'])

end 


xlabel('Dof^{1/2}','FontSize',18);

%xlabel('$p$','FontSize',18);


ylabel('Cond NO','FontSize',20);

 
set(gca,'FontSize',20)

%title('P refinement','FontSize',20)




