function z = u_true(X)


if size(X,2)~= 2
    
   error('input should be 2 dimensional points')
    
end


x = X(:,1); y = X(:,2);



z = x-x; 

end