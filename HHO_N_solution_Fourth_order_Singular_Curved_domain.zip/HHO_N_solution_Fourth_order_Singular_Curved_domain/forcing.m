function z= forcing(X)


if size(X,2)~= 2
    
   error('input should be 2 dimensional points')
    
end

x = X(:,1); y = X(:,2);


z = 10.*x.^0;

end