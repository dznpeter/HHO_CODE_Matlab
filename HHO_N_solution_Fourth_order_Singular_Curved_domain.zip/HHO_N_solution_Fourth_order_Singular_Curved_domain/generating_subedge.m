function [subedge_nodes,BDbox,index_level_set] = generating_subedge(elem,BDbox,Node,no_subtriangles_curve)

%%%%%%%%%Test if it is an element with curved boundary
  %% There are boundary edges
    
    %no_subtriangles_curve = 20;
    
    node_tri = Node(elem,:);
    
    h = norm(node_tri(1,:)-node_tri(2,:));
    
    d1 = levelset1(node_tri);  
    
    % number of points on Level set 1
    
    [index_points_level1 ,~ ,~] = find(abs(d1)<=0.1*h); 
    
    if length(index_points_level1) ==2  % one edge on the level set one
        
        index_level_set = '1';
    
        c_ind = 1:3;  c_ind(index_points_level1)=[]; 
        
        cnodes = node_tri(c_ind,:);
        
         bd_node = node_tri(index_points_level1,:); 
        
     curved_nodes = shape_levelset1(bd_node,no_subtriangles_curve);
    
     
    
    else %% one edge on the level set 2
        
        index_level_set = '2';
        
          d2 = levelset2(node_tri);  
        
        [c_ind ,~ ,~] = find(abs(d2)>0.1*h); 
                        
        
        cnodes = node_tri(c_ind,:);
        
        bd_node = node_tri;  bd_node(c_ind ,:)=[];
        
       curved_nodes = shape_levelset2(bd_node,no_subtriangles_curve);
       
       

    end

    


subedge_nodes = curved_nodes; 


max_x = max([curved_nodes(:,1);BDbox(:,1)]); min_x = min([curved_nodes(:,1);BDbox(:,1)]);

max_y = max([curved_nodes(:,2);BDbox(:,2)]); min_y = min([curved_nodes(:,2);BDbox(:,2)]);

BDbox = [[min_x, min_y];[max_x, max_y]];

    
end


