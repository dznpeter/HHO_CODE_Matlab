% clear all; 

%load('Error Mesh level 2 for HHO(P2) basis nonconforming.mat') % Level 2 is 128 cells

% load('Error Mesh level 3 for HHO(P2) basis nonconforming.mat') % Level 3 is 512 cells

% load('Error Mesh level 4 for HHO(P2) basis nonconforming.mat') % Level 4 is 2048 cells

% load('Error Mesh level 5 for HHO(P2) basis nonconforming.mat') % Level 5 is 8192 cells

total_eta = sum_elem_residual^2 + Stabilisation_err^2 + sum_normal_flux_residual^2 + sum_tangential_flux_residual^2;


eta_C = sum_elem_residual^2/total_eta; 

eta_S = Stabilisation_err^2/total_eta;

eta_N = sum_normal_flux_residual^2/total_eta;

eta_T = sum_tangential_flux_residual^2/total_eta;


[eta_C, eta_S, eta_N, eta_T]