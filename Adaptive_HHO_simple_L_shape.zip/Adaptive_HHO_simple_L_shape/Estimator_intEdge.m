function [intEdge_residual_conforming,intEdge_residual_nonconforming,int_edge_flux_Mass] = Estimator_intEdge(face_nodes, vertice,BDbox1,BDbox2,local_R_HHO_coef1,local_R_HHO_coef2,coef1,coef2,local_edge_index1,local_edge_index2,sigma, n_F,Po ,RHHO_ind,HHO_elem_ind,HHO_face_ind,Polydegree,a)



R_Polydegree = Polydegree +1 ; 

h1 = (BDbox1(2,:)-BDbox1(1,:))./2;  h2 = (BDbox2(2,:)-BDbox2(1,:))./2;

m1 =  0.5.*sum(BDbox1);     m2 =  0.5.*sum(BDbox2); 


dim_elem_R = size(RHHO_ind,1); % number of basis for each element.

dim_elem_inter = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 

dim_elem_face = size(HHO_face_ind,1); % Dimention for face basis on each individual face 


%% find the quadtrature points on each edge

[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);

%% data


a_val_face = a(Qpoints_faces(:,:,1));

coe_HHO_cell1 = coef1(1:dim_elem_inter);  coe_HHO_cell2 = coef2(1:dim_elem_inter); 

%correct measure

h_p = max(abs(sum((vertice-kron(face_nodes(1,:),ones(size(vertice,1),1))).*kron(n_F,ones(size(vertice,1),1)),2)));

    % construct the matrix for all the local basis function

    
        
    P1x = zeros(size(Qpoints_faces,1) ,dim_elem_R);
    
    P1y = zeros(size(Qpoints_faces,1) ,dim_elem_R);
    
    for i =1:dim_elem_R
                        
        t = gradtensor_leg(Qpoints_faces,m1,h1,RHHO_ind(i,:));   
        
        P1x(:,i) = t(:,1); P1y(:,i) = t(:,2);  
        
    end
    
  
    grad_u_R_HHO_1 = [P1x*local_R_HHO_coef1 , P1y*local_R_HHO_coef1];   %gradient of R_HHO
    
    grad_u_HHO_1 = [P1x*coe_HHO_cell1 , P1y*coe_HHO_cell1];   %gradient of HHO

    
    
    %% Second elements
              
    % construct the matrix for all the local basis function

        
    P2x = zeros(size(Qpoints_faces,1) ,dim_elem_R);
    
    P2y = zeros(size(Qpoints_faces,1) ,dim_elem_R);
    
    for i =1:dim_elem_R
                        
        t = gradtensor_leg(Qpoints_faces,m2,h2,RHHO_ind(i,:));   
        
        P2x(:,i) = t(:,1); P2y(:,i) = t(:,2);  
        
    end
  
    grad_u_R_HHO_2 = [P2x*local_R_HHO_coef2 , P2y*local_R_HHO_coef2];   %gradient of DG

    grad_u_HHO_2 = [P2x*coe_HHO_cell2 , P2y*coe_HHO_cell2];   %gradient of HHO

     %% Jump of tangential jump HHO solution
      
     jump_u_x_HHO_val = grad_u_HHO_1(:,1) - grad_u_HHO_2(:,1);
     
     jump_u_y_HHO_val = grad_u_HHO_1(:,2) - grad_u_HHO_2(:,2);
     
     jump_grad_HHO_val = [jump_u_x_HHO_val, jump_u_y_HHO_val];   
    
               
     % tangential verctor is t = [n(2),-n(1)]     
     
     tangential_jump = n_F(2).*jump_grad_HHO_val(:,1) - n_F(1).*jump_grad_HHO_val(:,2);
     
     q = (h_p/R_Polydegree).*a_val_face.*tangential_jump.^2;
     
     %% case 1 without normal flux jump
   
     intEdge_residual_nonconforming = dot((q),weights_faces);
                    
     
     %% Jump of normal flux R_HHO solution
     
     jump_u_x_R_HHO_val = grad_u_R_HHO_1(:,1) - grad_u_R_HHO_2(:,1);
     
     jump_u_y_R_HHO_val = grad_u_R_HHO_1(:,2) - grad_u_R_HHO_2(:,2);
     
     jump_grad_R_HHO_val = [jump_u_x_R_HHO_val, jump_u_y_R_HHO_val];   
          
     %% case 2 with normal flux jump

     normal_jump = n_F(1).*jump_grad_R_HHO_val(:,1) + n_F(2).*jump_grad_R_HHO_val(:,2);
     

     
     s = (h_p/R_Polydegree).*a_val_face.*normal_jump.^2;
     
     
     intEdge_residual_conforming = dot((q+s),weights_faces);
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Compute the local equalibrated flux jump to make sure the mass conservation

normal_jump = a_val_face.*(n_F(1).*jump_grad_R_HHO_val(:,1) + n_F(2).*jump_grad_R_HHO_val(:,2));

      
[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);

h_p1 = norm(BDbox1(2,:)-BDbox1(1,:));  % it should not be h_f

sigma1 = a_val_face.*sigma/h_p1; % from the stability estimates 

h_p2 = norm(BDbox2(2,:)-BDbox2(1,:));  % it should not be h_f

sigma2 = a_val_face.*sigma/h_p2; % from the stability estimates 


local_edges_nodes =face_nodes;
  
M_FF = zeros(dim_elem_face,dim_elem_face);    
    

for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_face
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces,local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        V_trace = Face_baisis(Qpoints_faces,local_edges_nodes,Po,HHO_face_ind(j,:)); 
        
        t =  sum(U_trace.*V_trace,2);
        
        M_FF(i,j) = dot(t,weights_faces);
        
    end
end

    
 M_FF_inv = inv(M_FF);  
 
 
 %% computing the matrix M_FT1
 
 
 M_FT_all1 = zeros(dim_elem_face,dim_elem_inter);  
    
 
for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_inter
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces,local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        R_trace = tensor_leg(Qpoints_faces,m1,h1,HHO_elem_ind(j,:));
        
        t =  sum(U_trace.*R_trace,2);
        
         M_FT_all1(i,j) = dot(t,weights_faces);
        
    end
end


% M_FT_p is the first p part

M_FT_p1 = M_FT_all1(1:dim_elem_face,1:dim_elem_inter);


%Define the difference operator on each face

Proj_TF1 = M_FF_inv*M_FT_p1; 

% Find the index of the cell basis 

index_cell_local1 = 1: dim_elem_inter;

Coe_u_k1 = coef1(index_cell_local1);

%% Coefficients of face projection with k of the cell polynomial u_k

Coe_proj_face1 = Proj_TF1*Coe_u_k1;     

%% Coefficients of face polynomial u_f

% Find the index of the face basis 

index_face_local1 = dim_elem_inter+((local_edge_index1-1)*dim_elem_face+1:local_edge_index1*dim_elem_face);

Coe_u_F1 = coef1(index_face_local1);


diff_coe1 = Coe_proj_face1 - Coe_u_F1;

   
    P1 = zeros(size(Qpoints_faces,1) ,dim_elem_face);
    
    
    for i =1:dim_elem_face
                        
        P1(:,i) =  Face_baisis(Qpoints_faces,local_edges_nodes,Po,HHO_face_ind(i,:));               
        
    end
    
 stab_u1 = sigma1.*P1*diff_coe1;
 
 
 
 %% computing the matrix M_FT2
 
 
 M_FT_all2 = zeros(dim_elem_face,dim_elem_inter);  
    
 
for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_inter
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces,local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        R_trace = tensor_leg(Qpoints_faces,m2,h2,HHO_elem_ind(j,:));
        
        t =  sum(U_trace.*R_trace,2);
        
         M_FT_all2(i,j) = dot(t,weights_faces);
        
    end
end


% M_FT_p is the first p part

M_FT_p2 = M_FT_all2(1:dim_elem_face,1:dim_elem_inter);


%Define the difference operator on each face

Proj_TF2 = M_FF_inv*M_FT_p2; 

% Find the index of the cell basis 

index_cell_local2 = 1: dim_elem_inter;

Coe_u_k2 = coef2(index_cell_local2);

%% Coefficients of face projection with k of the cell polynomial u_k

Coe_proj_face2 = Proj_TF2*Coe_u_k2;     

%% Coefficients of face polynomial u_f

% Find the index of the face basis 

index_face_local2 = dim_elem_inter+((local_edge_index2-1)*dim_elem_face+1:local_edge_index2*dim_elem_face);

Coe_u_F2 = coef2(index_face_local2);


diff_coe2 = Coe_proj_face2 - Coe_u_F2;

   
    P2 = zeros(size(Qpoints_faces,1) ,dim_elem_face);
    
    
    for i =1:dim_elem_face
                        
        P2(:,i) =  Face_baisis(Qpoints_faces,local_edges_nodes,Po,HHO_face_ind(i,:));               
        
    end
    
 stab_u2 = sigma2.*P2*diff_coe2;
 
 
 
Flux_diff =  stab_u1+ stab_u2 -normal_jump;
 

int_edge_flux_Mass = sqrt(dot(Flux_diff.^2,weights_faces));

end