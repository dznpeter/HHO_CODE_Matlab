         
function Global_basis_index = findGlobalindex(t,Face_index,dim_elem,dim_face,dim_NF_face,dim_total_elem,dim_total_face)


%% for t_th element 

global_elem_index = ((t-1)*dim_elem+1  : t*dim_elem)';

%% for different faces of face basis for trace variable and flux variable

global_face_index = NaN(dim_face,size(Face_index,1));

global_NF_face_index = NaN(dim_NF_face,size(Face_index,1));

for k=1:size(Face_index,1)
    
   global_face_index(:,k) = ((Face_index(k)-1)*dim_face+1 : Face_index(k)*dim_face)'; 
   
   
   global_NF_face_index(:,k) = ((Face_index(k)-1)*dim_NF_face+1 : Face_index(k)*dim_NF_face)'; 
    
end

global_face_index = global_face_index(:)+dim_total_elem;

global_NF_face_index = global_NF_face_index(:)+dim_total_elem + dim_total_face;


Global_basis_index =[global_elem_index;global_face_index;global_NF_face_index];

end