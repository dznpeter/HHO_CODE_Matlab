function NeighbourElem = find_neighbour(local_elem_tri,elem_tri,allEdge_no_frac_edges, all_edge2elem_no_frac_pairs) 

%local_elem_tri,elem_tri,allEdge_no_frac_edges, all_edge2elem_no_frac_pairs


local_tri = elem_tri(local_elem_tri,:);

[~,polyEdge] = findboundary(local_tri);

% combine all the edges

[~,ia,~] = intersect(allEdge_no_frac_edges,polyEdge,'rows');

NeighbourElem = all_edge2elem_no_frac_pairs(ia,:);


NeighbourElem = unique(NeighbourElem(:));


   
end