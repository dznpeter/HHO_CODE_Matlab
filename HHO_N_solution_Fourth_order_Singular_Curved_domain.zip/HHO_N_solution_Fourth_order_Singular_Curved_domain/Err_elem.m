function [ R_L2part, R_E_part,local_R_HHO  ] = Err_elem(elem_nodes,BDbox, coef,local_Reconstruction, Po ,HHO_elem_ind,RHHO_ind, u_true, grad_u_true, Hessian_u_true,epsilon)

%% First compute the local Reconstruction R_HHO

ind = size(coef,1); % remove the rededuncy 

R_HHO_nc = local_Reconstruction(:,1:ind)*coef;




dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 

dim_elem_cell = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 

%dim_elem_face = size(HHO_face_ind,1); % Dimention for face basis on each individual face 




% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);

[Qpoints_elem,weights_elem]=quad_poly_special(elem_nodes,Po); % get the quadrature points on polygon


R_HHO_miss = coef(1);

%% R_HHO solution finally find.....

local_R_HHO =[R_HHO_miss ;R_HHO_nc];


%% computing the error



%%

R_L2part=0;   R_H1_part = 0; R_H2_part = 0;% CL2part=0;

     
    % data for quadrature
    
     u_val = u_true(Qpoints_elem);    %a_val = a(P_Qpoints);
     
     grad_u_val = grad_u_true(Qpoints_elem);
    
     Hessian_u_val = Hessian_u_true(Qpoints_elem);
     
     

%Computing the error for the projection of the u and u_h

% the mass matrix on the element basis T and T between dim_elem_inter * dim_elem_R

%{

M = NaN(dim_elem_cell,dim_elem_cell); 

P1_U = NaN(dim_elem_cell,1); 

for i = 1:dim_elem_cell
   
    %%symetric term
    
    s = u_val.*tensor_leg(Qpoints_elem,m,h,HHO_elem_ind(i,:));
    
    P1_U(i) = dot(s,weights_elem);
    
    for j=1:dim_elem_cell
    
        % first term uv is symetric
            
        
        U = tensor_leg(Qpoints_elem,m,h,HHO_elem_ind(i,:));
        
        V = tensor_leg(Qpoints_elem,m,h,HHO_elem_ind(j,:));
        
        t =  sum(U.*V,2);
        
        M(i,j) = dot(t,weights_elem);
        
    end
end

Proj_p = M\P1_U; % coefficents of L2 projection on element P_p(k)

% split the M into each use for matrix 


%}


         
    
    % construct the matrix for all the local basis function

    
      P = zeros(size(Qpoints_elem,1) ,dim_elem_R );
      
     Px = zeros(size(Qpoints_elem,1) ,dim_elem_R );
      
     Py = zeros(size(Qpoints_elem,1) ,dim_elem_R );
    
    Pxx = zeros(size(Qpoints_elem,1) ,dim_elem_R );
    
    Pxy = zeros(size(Qpoints_elem,1) ,dim_elem_R );
    
    Pyx = zeros(size(Qpoints_elem,1) ,dim_elem_R );
    
    Pyy = zeros(size(Qpoints_elem,1) ,dim_elem_R );
   
   
    
    
    for i =1:dim_elem_R 
        
        P(:,i)= tensor_leg(Qpoints_elem,m,h,RHHO_ind(i,:));
        
        s =  gradtensor_leg(Qpoints_elem,m,h,RHHO_ind(i,:));
        
        Px(:,i) = s(:,1); Py(:,i) = s(:,2);
        
        t =  Hessian_leg(Qpoints_elem,m,h,RHHO_ind(i,:));
        
        Pxx(:,i) = t(:,1); Pxy(:,i) = t(:,2); Pyx(:,i) = t(:,3); Pyy(:,i) = t(:,4); 
    end
  
    u_HHO_val = P(:,1:dim_elem_cell)*coef(1:dim_elem_cell);   % HHO solution;
    
    %Proj_p_u_val = P(:,1:dim_elem_inter)*Proj_p;   % L2 projection of u on element P_p(k);
    
    % Recovered HHO solution
  
    u_R_HHO_val = P*local_R_HHO;   % R_HHO solution;
    
    grad_u_R_HHO_val = [Px*local_R_HHO,Py*local_R_HHO];   % R_HHO solution;
    
    Hessian_u_R_HHO = [Pxx*local_R_HHO, Pyx*local_R_HHO, Pxy*local_R_HHO , Pyy*local_R_HHO];   % gradient of R_HHO
    
   
        
    
    
      % L_2 norm error  int_\kappa (u - R u_HHO)^2 dx
    
     t0 = (u_val - u_R_HHO_val).^2;
        
     R_L2part = R_L2part+dot((t0),weights_elem);
     
      % H1 semi norm error  int_\kappa (grad_u - grad_u_HHO)^2 dx
    
     t1 = sum((grad_u_R_HHO_val - grad_u_val).^2,2);
          
     R_H1_part = R_H1_part+ dot((t1),weights_elem);
    
     
      % H2 semi norm error  int_\kappa (grad_u - grad_u_HHO)^2 dx
       
       
     t2 = sum((Hessian_u_R_HHO - Hessian_u_val).^2,2);
          
     R_H2_part = R_H2_part+ dot((t2),weights_elem);
    
     
     R_E_part = R_H1_part + epsilon.*R_H2_part;
     
     
       % L_2 norm error  int_\kappa (Proj_p u - u_HHO)^2 dx
    
%      t3 = (u_HHO_val - Proj_p_u_val).^2;
%         
%      CL2part = CL2part+dot((t3),weights_elem);


end


