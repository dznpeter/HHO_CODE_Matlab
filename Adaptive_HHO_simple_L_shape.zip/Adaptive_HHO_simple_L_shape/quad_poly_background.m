function [P_Qpoints,weights]=quad_poly_background(submesh,NT,Po)

%%%% Quadtrature on the triangles from the backgroud meshes!!!!

for k = 1:NT
       
[tri_P_Qpoints, tri_weights] = quad_tri(submesh(:,:,k),Po);

NO_points = size(tri_P_Qpoints,1);

if k==1

P_Qpoints = NaN(NT*NO_points,size(tri_P_Qpoints,2));

weights = NaN(NT*NO_points,size(tri_weights,2));

end

P_Qpoints((k-1)*NO_points+1:1: k*NO_points,:) = tri_P_Qpoints;

weights((k-1)*NO_points+1:1: k*NO_points,:) = tri_weights;

end
  