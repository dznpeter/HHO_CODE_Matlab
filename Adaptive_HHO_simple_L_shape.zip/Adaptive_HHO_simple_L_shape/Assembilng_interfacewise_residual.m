function [element_interface_estimator,element_interface_interface] = Assembilng_interfacewise_residual(int_eta_edge,elem_err_est,int_edge2elem)

%% find all the element interfaces 
new_int_edge2elem = sort(int_edge2elem,2);

[element_interface_interface]=unique(new_int_edge2elem,'rows');

N_IF = size(element_interface_interface,1);


element_interface_estimator = NaN(N_IF,1);

parfor i =1 :N_IF
   
   local_interface = element_interface_interface(i,:);
   
   test_index = abs(new_int_edge2elem(:,1) - local_interface(:,1)) +abs(new_int_edge2elem(:,2) - local_interface(:,2));
   
   interface_ind = find(test_index==0); %% find the edge residual belong to the elementwise      
   
   element_interface_estimator(i) = sum(int_eta_edge(interface_ind))+ sum(elem_err_est(local_interface'));
  
  
  %% only consider the interface
  
 % element_interface_estimator(i) = sum(int_eta_edge(interface_ind));
  
   
end



element_interface_estimator = sqrt(element_interface_estimator);


