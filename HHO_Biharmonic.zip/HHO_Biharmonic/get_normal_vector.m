function [out_normal_vectors,wrap_N] = get_normal_vector(t,Face_index,intnorvec,bdnorvec,int_edge2elem)

No_inter_edge = size(intnorvec,1);

out_normal_vectors = NaN(size(Face_index,1),2);

% wrap stands for if the normal vector changes the directions in each
% element

wrap_N = zeros(size(Face_index,1),1); 

for k=1:size(Face_index,1)
    
    if Face_index(k)<=No_inter_edge 
        % Interior edge
        
         out_normal_vectors(k,:) = intnorvec(Face_index(k),:);
                
         
         % pointing to a wrong direction
         
         if int_edge2elem(Face_index(k),1)~=t
             
             out_normal_vectors(k,:) = -out_normal_vectors(k,:);
             
             wrap_N(k) = 1;
         end
        
        
    
    else  % boundary edge, normal vector is always outward 
        
        out_normal_vectors(k,:) = bdnorvec(Face_index(k)-No_inter_edge ,:);
        
        
    end
    
end





end