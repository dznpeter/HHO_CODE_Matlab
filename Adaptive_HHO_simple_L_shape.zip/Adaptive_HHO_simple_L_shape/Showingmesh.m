


figure; 

hold on;


%%%% Different version


NT = size(Elem,1);
 
 for i = 1: NT
    
     local_poly = Elem{i,1};
     
     Plotting_polyelements(local_poly,Node,elem_tri)
     
     tri = elem_tri(local_poly,:);
          
     aux_nodes = Node(tri(:),:);
     
     barycenter = sum(aux_nodes)./size(aux_nodes,1);
     
    % text(barycenter(1),barycenter(2),num2str(i)); 
     
 end

