function curved_nodes = shape_levelset1(bd_node,no_subtriangles_curve)

        
%% Change to the curved edges  euqation angle 

r = 1; %sqrt(sum(bd_node(1,:).^2)); % r may differ from 1



BD_theta = atan2(bd_node(:,2),bd_node(:,1));

if abs(BD_theta(1)-BD_theta(2))>pi
 
    id = find(BD_theta - min(BD_theta)==0);
    
    BD_end = BD_theta(id) +2*pi; 
    
    BD_start = BD_theta;  BD_start(id)=[];
    
    BD_theta =[BD_start;BD_end];
    
end    


Theta = linspace(BD_theta(1),BD_theta(2),no_subtriangles_curve+1)';

x = r.*cos(Theta);  y = r.*sin(Theta);

%% tangent is periodic for pi

%if x(1)*bd_node(1,1) + x(2)*bd_node(2,1)<0
    
%    x = -x; y = - y;
    
%end


curved_nodes = [x,y];

end