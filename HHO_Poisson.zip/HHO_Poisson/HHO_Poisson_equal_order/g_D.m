function z =g_D(x)

if size(x,2)~= 2
    
   error('input should be 2 dimensional points')
    
end



z = sin(pi.*x(:,1)).*sin(pi.*x(:,2));

end