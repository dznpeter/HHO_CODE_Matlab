function z = vect_BDface(node, vertice,BDbox ,n ,Po ,Lege_ind, alpha, beta , g_D ,g_N)

%information for two bounding box , n is the normal vector from k1 to k2

h =  (BDbox(2,:)-BDbox(1,:))./2 ;

m = 0.5.*sum(BDbox);

dim_elem =size(Lege_ind,1); % number of basis for each element.

z = zeros(dim_elem,1);  % initialize the local vector

% generating quadrature points and weights

%[weights,ref_Qpoints] = Golub_Welsch(ceil(Po/2));

[weights,ref_Qpoints] = quad_GL(Po);

%change the quadrature nodes from reference domain to physical domain.

mid= sum(node)./2;   tanvec = 0.5* (node(2,:)-node(1,:));

C = kron(mid,ones(size(ref_Qpoints,1),1));

P_Qpoints = kron(ref_Qpoints,tanvec) + C;   De = norm((node(2,:)-node(1,:))).*0.5;

% penalty term

%a_center = a(mid);

%lamda = eigs(reshape(a_center,2,2),1);


%temp = [n(1).^2,n(1).*n(2),n(1).*n(2),n(2).^2 ];

%lamda = dot(a_center,temp);

%correct measure

measure_B = De*max(abs(sum((vertice-kron(node(1,:),ones(size(vertice,1),1))).*kron(n,ones(size(vertice,1),1)),2)));


alpha = alpha.*(2.*De/measure_B)^3; % \alpha = penalty * p^6/h^3;


beta = beta.*(2.*De/measure_B);   % \beta = penalty * p^2/h;

 % data for quadrature
    
 g_D_val = g_D(P_Qpoints);    g_N_val = g_N(P_Qpoints);  
 
 n_vec =kron(n,ones(size(ref_Qpoints,1),1));
 
 
 %a_val = a(P_Qpoints);
 
 
 
first = zeros(dim_elem,1);


% i is row which is basis of u and j is v. 

   
    for j = 1:dim_elem
    
      % first term g_D(grad{laplace(v)} \cdot n + alpha v)
      %           +g_N(beta * grad{v} \cdot n   - laplace {v})
      
       %coe = [(a_val(:,1).*n_vec(:,1)+a_val(:,2).*n_vec(:,2)) , (a_val(:,3).*n_vec(:,1)+a_val(:,4).*n_vec(:,2))]; 
      
       gradLaplacianv1 =   gradLaplacian_leg(P_Qpoints,m,h,Lege_ind(j,:));
       
       LaplacianV1 = Laplacian_leg(P_Qpoints,m,h,Lege_ind(j,:));
        
       
       gradv1 =  gradtensor_leg(P_Qpoints,m,h,Lege_ind(j,:));
       
      
       
      
      
       
       V1 = tensor_leg(P_Qpoints,m,h,Lege_ind(j,:));
      
         
       
   
         
       % Dirichelte
       
       t1 =  g_D_val.* (sum(gradLaplacianv1.*n_vec ,2) + alpha.*V1 );
       
       % Neumann
       
       t2 = sum(g_N_val.*n_vec ,2).* ( beta.*sum(gradv1.*n_vec ,2) - LaplacianV1 );
       
       
       t = t1+t2;
        
        first(j) = De.*dot((t),weights);
         
        
    end



z = z + first;


end
    