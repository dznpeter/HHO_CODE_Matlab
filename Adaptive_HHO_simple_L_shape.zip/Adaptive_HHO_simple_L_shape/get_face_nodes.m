function face_nodes = get_face_nodes(local_face_index,Node)

face_nodes = NaN(2,2,size(local_face_index,1));

for k=1:size(local_face_index,1)
   
   face_nodes(:,:,k) = Node(local_face_index(k,:)',:);
    
end

end