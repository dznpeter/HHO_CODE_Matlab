
function [Elem,elem_tri,Node,bdEdge,bd_edge2elem,intEdge,int_edge2elem,intnorvec,bdnorvec,Full_edge,maximum_No_edge_elem]= New_Coarsen_poly(coarsen_marked_interface,element_interface_interface,Elem,elem_tri,Node)
 
 %% computing the aggolomeration level
 
 NT = size(Elem,1);
 
 %Plotting_marked_polyelements(marked_elem,Elem,Node,elem_tri);
 
 level = zeros(NT,1); % the initial level are zeros 
 
 New_Elem = cell(NT,1);
 
 poly_index = 0;  % Index for creating the new poly meshes
 
 fine2corsen = NaN(NT,1); % fine to coasen mapping      
    
 Waitting_refine_interfaces = element_interface_interface(coarsen_marked_interface,:);
 
 
 
 %% Aggolomorete based on the interfaces
 
 for i = 1:size(coarsen_marked_interface,1)
    
     
     elem_coarsen = Waitting_refine_interfaces(i,:);
          
     
     if sum(level(elem_coarsen))==0 %% both element has not been used
        
          poly_index = poly_index+1;
         
          New_Elem{poly_index}=[Elem{elem_coarsen(1),1}; Elem{elem_coarsen(2),1}];
         
          level(elem_coarsen) = 1;
          
          fine2corsen(elem_coarsen) = poly_index;
     end
         
         
     if sum(level(elem_coarsen))==1 %% one element has been used                                 
         
        unused_index =  find(level(elem_coarsen) == 0);
        
        unused_elem = elem_coarsen(unused_index);
        
        %% find the next possible agglomoration
         
             Nei_ind1 = find(Waitting_refine_interfaces(:,1)==unused_elem);
             
             Nei_ind2 = find(Waitting_refine_interfaces(:,2)==unused_elem);
             
             Nei1 = Waitting_refine_interfaces(Nei_ind1,2);
             
             Nei2 = Waitting_refine_interfaces(Nei_ind2,1);
             
             Nei = [Nei1;Nei2];
             
             %% find the uncoarsend ed neigh
             
             Un_Nei_index = find(level(Nei)==0);
             
             if isempty(Un_Nei_index)==0  %% there is uncoarsened neigh
                 
                 Un_Nei = Nei(Un_Nei_index(1));
                 
                 poly_index = poly_index+1;
                 
                 New_Elem{poly_index}=[Elem{unused_elem,1}; Elem{Un_Nei,1}];
                 
                 level([unused_elem,Un_Nei]) = 1;
          
                 fine2corsen([unused_elem,Un_Nei]) = poly_index;
                 
             else %% there is no uncoarsened neigh
                 
                 poly_index = poly_index+1;
                 
                  New_Elem{poly_index}=Elem{unused_elem,1};
                  
                  
                  level(unused_elem) = 1;
          
                 fine2corsen(unused_elem) = poly_index;
                 
             end
             
             
                                       
     end
     
     %% both of the elem has been used we do nothing 
     
     
 end
 
 %% The coarsening step is finished, Update all the unused element
 
 
 
 un_ind = find(level ==0); 
 
 if isempty(un_ind)==0
 
 for i = 1:size(un_ind,1)
     
     poly_index = poly_index+1;
     
     New_Elem{poly_index} = Elem{un_ind(i),1};
     
     
 end
 
 end
 %{
 for i = 1 :NT
     
      local_elem_tri = Elem{i,1};    
 
      local_level = level(i);
      
 % first check the level, 
 % if the level is 1 which means the mesh has been corsened  
 % if the level is 0 which means the mesh has not been corsened
 
 if local_level == 1
     
     % if the triangle is coarsened into a polygon, then we do nothing
     
 else   
     
    
      marking_ind = find(coarsen_marked_elem==i);
     
    if  isempty(marking_ind)== 0  %% Marked element
        
         
        NeighbourElem =  find_neighbour(local_elem_tri,elem_tri,bdEdge,bd_edge2elem,intEdge,int_edge2elem) ; 
     
        index = find(NeighbourElem~=i);  NeighbourElem = NeighbourElem(index); 
        
        %% Checking if the triangular neighbour has been used
   
   Coarse_index = level(NeighbourElem);
   
   
    if prod(Coarse_index) == 1  % All neighbors has been used in coasenning
       
       %% if all of the neighbour element has been used, then you will also be 
       
      closeElem = NeighbourElem(1);
      
      tem_poly_index  =  fine2corsen(closeElem);
      
      New_Elem{tem_poly_index,1} = [New_Elem{tem_poly_index,1};Elem{i,1}];
      
      level(i) = 1;  % update the used triangles
       
      
      fine2corsen(i) = tem_poly_index;
      
    else
        
          poly_index = poly_index+1;
          
        
       
       
       ind = find(Coarse_index==0);
       
       %% At most coarsen take 2 neighbour into one elements 
       
       No_uncorased_mesh = min(size(ind,1),1); % this can be defined               
                     
       %%%%%%% Finding the neightbour with smallest element residual              
       
       uncorsenedElem = NeighbourElem(ind); % polygonal meshes
         %%      
         
       fine2corsen_index = [i;uncorsenedElem(1:No_uncorased_mesh)];
       
       %%
       
       %{
        [~,index]=sort(total_estimator(uncorsenedElem));
        
        coasen_neigh = uncorsenedElem(index); %% neighbour with smallest residual
       
        fine2corsen_index = [i;coasen_neigh(1:No_uncorased_mesh)];
        
        %}
       
       % triangle into the polygons
       
       fine2corsen_index_tri = Elem{i,1};
       
       for k = 1:No_uncorased_mesh
       
           fine2corsen_index_tri = [fine2corsen_index_tri;Elem{uncorsenedElem(k),1}];
           
       end
              
       
       New_Elem{poly_index,1} = fine2corsen_index_tri; % new polygons by using tris
       
       
       level(fine2corsen_index) = 1;  % update all the used old polygons
       
      
        fine2corsen(fine2corsen_index) = poly_index;
        
          
    end
   
   
     
    else  %%unmarked elem
        
        poly_index = poly_index+1;
        
        New_Elem{poly_index,1} = Elem{i,1};
        
        level(i) = 1;  % update all the used old polygons
       
      
        fine2corsen(i) = poly_index;
        
    end
    
    
 end
     
 end
 
 %}
 
 
 New_Elem = New_Elem(1:poly_index);   NT = poly_index; % number of polygons

 
 %% Generate all the data structure for aggolomerated meshes
 
Elem = cell(NT,2);
 

totalEdge = NaN(1,2);  elemperedge = NaN(NT,1);
 

for i =1: NT
    
    % calculate all the bounding box
    
    Elem{i,1}= New_Elem{i};
   
    tri = elem_tri(Elem{i,1},:);
    
    bdbox_x = sort(Node(tri(:),1));
    
    bdbox_y = sort(Node(tri(:),2));
    
    Elem{i,2} = [bdbox_x([1,end]) ,  bdbox_y([1,end])]; %bounding box is [x_min y_min
                                                        %                 x_max y_max]  
                                                        
    % take out all the edges  
    
    
    [~,polyEdge] = findboundary(tri);
    
    totalEdge = [totalEdge; polyEdge] ;                                                       
                    
    % label edges per element
    
    elemperedge(i) = size(polyEdge,1);
end

elemtotaledge = cumsum(elemperedge);

maximum_No_edge_elem = max(elemperedge);

totalEdge(1,:)=[]; 
 
totalEdge = sort(totalEdge, 2); 

[i , j ,s ] = find(sparse(totalEdge(:,2),totalEdge(:,1),1));

bdEdge = [j(s==1), i(s==1)]; intEdge = [j(s==2), i(s==2)];

int_edge2elem = NaN(size(intEdge,1),2); bd_edge2elem = NaN(size(bdEdge,1),1);


parfor i = 1: size(intEdge,1)
   
    edge2elem = elem_share_edge(intEdge(i,:),totalEdge,elemtotaledge);
    
    int_edge2elem(i,:) =   edge2elem';
    
end

parfor i = 1: size(bdEdge,1)
   
    edge2elem = elem_share_edge(bdEdge(i,:),totalEdge,elemtotaledge);
    
    bd_edge2elem(i,1) =   edge2elem; 
    
end

%% get the correct normal vector

 intnorvec =  NaN(size(intEdge,1),2);  bdnorvec =  NaN(size(bdEdge,1),2);  

parfor i = 1: size(intEdge,1)
   
    %% find this edge without using backgroung meshes
    
    localEdge = intEdge(i,:);
    
    local_elem = int_edge2elem(i,1); %% find the element 1
    
    tri1 = elem_tri(Elem{local_elem,1},:);  
    
    %% find the triangles sharing this edge
    
    I1 = abs(prod(tri1 - localEdge(1),2));  I2 = abs(prod(tri1 - localEdge(2),2));
    
    % K_tri is the triangles sharing this edge inside the polygons
    
    index = find(I1+I2==0);       K_tri = tri1(index,:)';
    
    t_vec = Node(localEdge(1),:)-Node(localEdge(2),:);
    
    n = [t_vec(2), -t_vec(1)]./norm(t_vec);
    
    
    P = sum(Node(K_tri,:))./3; % P is the barycentre of tri
    
    
    test_vec = Node(localEdge(1),:)-P;
    
    test = dot(test_vec,n);
    
        
    
    if  test > 0
        
        intnorvec(i,:) = n;
        
    else
        
        intnorvec(i,:) = -n;
        
    end
        
    
end



parfor i = 1: size(bdEdge,1)
   
    %% find this edge from backgroung meshes
    
    localEdge = bdEdge(i,:);
    
    local_elem = bd_edge2elem(i,1);
    
    tri1 = elem_tri(Elem{local_elem,1},:);
    %% find the triangles sharing this edge
    
    I1 = abs(prod(tri1 - localEdge(1),2));  I2 = abs(prod(tri1 - localEdge(2),2));
    
    % K_tri is the triangles sharing this edge inside the polygons
    
    index = find(I1+I2==0);       K_tri = tri1(index,:)';
       
    
    t_vec = Node(localEdge(1),:)-Node(localEdge(2),:);
    
    n = [t_vec(2), -t_vec(1)]./norm(t_vec);
    
    P = sum(Node(K_tri,:))./3
    
    
    test_vec = Node(localEdge(1),:)-P;
    
    test = dot(test_vec,n);
    
    
    if  test > 0
        
        bdnorvec(i,:) = n;
        
    else
        
         bdnorvec(i,:) = -n;
        
    end
    
           
        
    
end



%%%%%%%%%%%%%%%finding all the information about the element edges%%%%%%%%%%%


 
%% find each element contains which edge
% the global index of edge is based as inter_edge, BD_edge
  
parfor i = 1: NT
    
 index_int1 = find(int_edge2elem(:,1) == i);
 
 index_int2 = find(int_edge2elem(:,2) == i);
 
 index_bd =  find(bd_edge2elem(:) == i);
 
    
    Elem{i,3}= [index_int1; index_int2; index_bd+size(intEdge,1)];
       
end


Full_edge = [intEdge;bdEdge];


  