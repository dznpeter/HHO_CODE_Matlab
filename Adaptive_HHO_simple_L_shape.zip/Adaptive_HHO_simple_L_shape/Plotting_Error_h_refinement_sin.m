%close all;
%% different elements we use different order of basis

NO_Elements = [16,64,256,1024,4096,16384];


%color = {'b','r','g','k','y'};

Marker = {'s','p','^','o','*','>'};

L2=figure;

slope_Poly = NaN(1,5);

order= 4;  

Mesh_type = 'polygonal';  % rectangle, polygonal

Norm_type = 'R_H1';  %'R_L2', 'R_H1'   ,'Sta', 'Est', 'Est_st'



for k = 0:order


%% plotting errors for the L2 norm for p refinement

%%P basis


Polynomial_degree = k;   

NO_elem = NO_Elements;   

err_P = NaN(length(NO_elem),1); dof_P = NaN(length(NO_elem),1);


for i=1 :length(NO_elem)
       
load(['Error ' num2str(NO_elem(i)) ' ' Mesh_type ' Elements P'  num2str(Polynomial_degree) ' basis.mat'])

switch  Norm_type
    
    case 'R_L2' 

err_P(i,1)=R_L2_err;    

    case 'R_H1'
        
err_P(i,1)=R_H1_err; 


  

 case 'Sta' 

err_P(i,1)=Stabilisation_err;



case 'Est' 


err_P(i,1)= norm(total_estimator,2);
 

case 'Est_st' 


err_P(i,1)= norm(total_estimator_Stabilisation,2);

end

dof_P(i) = dim_linear_system;
end

%slope for poly

logerr_P1 = abs(log(err_P(:,1))); 

slope_P1 = abs((logerr_P1(2:end)-logerr_P1(1:end-1))./(log(dof_P(2:end).^(1./2))-log(dof_P(1:end-1).^(1./2))));


%slope_Poly(k) = max(mean(slope_P1(end-1:end)), max(slope_P1));


%slope_Poly(k+1) = mean(slope_P1(1));

slope_Poly(k+1) = max(slope_P1);


switch Mesh_type 
    
    case 'rectangle'

loglog(dof_P.^(1./2),err_P(:,1),['r-' num2str(Marker{k+1})],'LineWidth',2,'MarkerSize',10);

    case 'polygonal'
        
loglog(dof_P.^(1./2),err_P(:,1),['k:' num2str(Marker{k+1})],'LineWidth',2,'MarkerSize',10);
        
end
hold on;

end


switch Mesh_type 
    
    case 'rectangle'

legend(['Rect P0 slope ' num2str(slope_Poly(1))]...
      ,['Rect P1 slope ' num2str(slope_Poly(2))]...
      ,['Rect P2 slope ' num2str(slope_Poly(3))]...
      ,['Rect P3 slope ' num2str(slope_Poly(4))]...
      ,['Rect P4 slope ' num2str(slope_Poly(5))]...
      ,'Location','SouthWest')
  
    case 'polygonal'
        
legend(['Poly P0 slope ' num2str(slope_Poly(1))]...
      ,['Poly P1 slope ' num2str(slope_Poly(2))]...
      ,['Poly P2 slope ' num2str(slope_Poly(3))]...
      ,['Poly P3 slope ' num2str(slope_Poly(4))]...
      ,['Poly P4 slope ' num2str(slope_Poly(5))]...
      ,'Location','SouthWest')       
end


xlabel('$\sqrt{\rm DoFs}$','FontSize',20,'Interpreter','latex');


switch  Norm_type
    
    case 'R_L2' 

%ylabel('||u-R(u_h)||_{L_2(\Omega)}','FontSize',20);

ylabel('$L_2$ norm error','FontSize',20,'Interpreter','latex');


    case 'R_H1'

%ylabel('|u-R(u_h)|_{H^1(\Omega)}','FontSize',20);

ylabel('$H^1$ seminorm error','FontSize',20,'Interpreter','latex');
 

case 'Sta' 

%ylabel('S(u_h,u_h)','FontSize',20);

ylabel('Stabilisation error','FontSize',20,'Interpreter','latex');


case 'Est' 
    
ylabel('Estimator','FontSize',20,'Interpreter','latex');

 

case 'Est_st' 

ylabel('Estimator + stabilisation','FontSize',20,'Interpreter','latex');

 
       
end





set(gca,'FontSize',18)

%title(['L2 norm error under h-refinement penalty ' num2str(penalty) ],'FontSize',20)

%saveas(L2,['Poisson_L2_norm_error_h_refine_penalty_' num2str(penalty) ],'fig');

%print(L2,'-depsc',['Poisson_L2_norm_error_h_refine_penalty_' num2str(penalty) '.eps']);



