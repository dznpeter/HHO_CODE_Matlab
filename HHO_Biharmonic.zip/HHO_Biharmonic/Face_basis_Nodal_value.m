function val = Face_basis_Nodal_value(local_edges_nodes,order)




L = norm(local_edges_nodes(2,:)-local_edges_nodes(1,:),2)*0.5;



   
    val=shift_leg_derivative([-1;1],0,1,order(1),0)./L^(0.0);


end