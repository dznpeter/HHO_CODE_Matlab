function z = u_true(x)


if size(x,2)~= 2
    
   error('input should be 2 dimensional points')
    
end


r = sqrt(sum(x.^2,2));
theta = atan2(x(:,2),x(:,1));
theta = (theta>=0).*theta + (theta<0).*(theta+2*pi);

z1 = r.^(2/3).*sin(2*theta/3);


%z2 = exp(- 1000.*(x(:,1) - 1/2).^2 - 1000.*(x(:,2) - 1/4).^2) + exp(- 1000.*(x(:,1) - 1/2).^2 - 1000.*(x(:,2) - 3/4).^2);

z = z1;

%z = z1 + z2;


end