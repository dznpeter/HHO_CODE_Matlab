function bdEdge_residual = Estimator_bdEdge(face_nodes, vertice, BDbox,coef,n_F,Po ,HHO_elem_ind, grad_u, Polydegree,a)

                                           
h =  (BDbox(2,:)-BDbox(1,:))./2 ;

m = 0.5.*sum(BDbox);

dim_elem_inter = size(HHO_elem_ind,1); % number of basis for each element.

R_Polydegree = Polydegree + 1;

%% find the quadtrature points on each edge

[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);



%% data

a_val_face = a(Qpoints_faces(:,:,1));


%correct measure

coe_HHO_cell = coef(1:dim_elem_inter);

h_p = max(abs(sum((vertice-kron(face_nodes(1,:),ones(size(vertice,1),1))).*kron(n_F,ones(size(vertice,1),1)),2)));

    % construct the matrix for all the local basis function
     
grad_u_val = grad_u(Qpoints_faces); 
 
    % construct the matrix for all the local basis function

    
    P1x = zeros(size(Qpoints_faces,1) ,dim_elem_inter);
    
    P1y = zeros(size(Qpoints_faces,1) ,dim_elem_inter);
    
    for i =1:dim_elem_inter
                        
        t = gradtensor_leg(Qpoints_faces,m,h,HHO_elem_ind(i,:));   
        
        P1x(:,i) = t(:,1); P1y(:,i) = t(:,2);  
        
    end
  
    grad_u_HHO = [P1x*coe_HHO_cell , P1y*coe_HHO_cell];   %gradient of HHO solution

    

     
     
%% tangential jump on the Dirichelt boundary. For the test case with fixed structure    
     
      
     jump_grad_DG_val = grad_u_val - grad_u_HHO;
               
     % tangential verctor is t = [n(2),-n(1)]     
     
     tangential_jump = n_F(2).*jump_grad_DG_val(:,1) - n_F(1).*jump_grad_DG_val(:,2);
     
     q = (h_p/R_Polydegree).*a_val_face.*tangential_jump.^2;
     


     bdEdge_residual =dot((q),weights_faces);

end