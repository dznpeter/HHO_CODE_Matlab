%plot the functions

clear all;

x=0:0.01:1;

[xx, yy]=meshgrid(x,x);

zz=forcing([xx(:),yy(:)]);

surf(xx,yy,reshape(zz, size(xx,1),[]))
