function z = vect_BDface(face_nodes,BDbox, Po,local_Reconstruction, local_dim_elem,HHO_elem_ind, RHHO_ind, n_vec,alpha, g_D,g_grad,epsilon)
                         
%% The loiclal reconstration

R = local_Reconstruction(:,1:local_dim_elem);

dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 

dim_elem_cell = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 



[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

h =  (BDbox(2,:)-BDbox(1,:))./2 ;

m = 0.5.*sum(BDbox);


h_k = norm(BDbox(2,:)-BDbox(1,:));  % it should not be h_f

alpha = alpha/h_k; % from the stability estimates  

%% The indicator for the singular pertubed parameter \epsilon

sigma = max(1,epsilon.*alpha^2);




 % data for quadrature
    
 g_D_val = g_D(Qpoints_faces); 
 
 grad_val = g_grad(Qpoints_faces);  

 
first = zeros(local_dim_elem,1);


% i is row which is basis of u and j is v. 

   
    for j = 1:dim_elem_cell
    
      % Stabilisation
      
      WK_trace = tensor_leg(Qpoints_faces(:,:,1),m,h,HHO_elem_ind(j,:));
      
      
      grad_WK_trace = gradtensor_leg(Qpoints_faces(:,:,1),m,h,HHO_elem_ind(j,:));
     
      
      
       % Dirichelte
       
       t1 =  sigma.*alpha.*g_D_val.* WK_trace;
       
       % Neumann
       
       t2 = epsilon.*alpha.*sum(grad_val.*grad_WK_trace ,2);
              
       t = t1+t2;
        
        first(j) = dot((t),weights_faces);
         
        
    end

    
    
    temp = zeros(dim_elem_R-1,1);


% i is row which is basis of u and j is v. 

   
    for j = 1:dim_elem_R-1
    
      % Stabilisation
      
      grad_R_W_trace = gradtensor_leg(Qpoints_faces(:,:,1),m,h,RHHO_ind(j+1,:));
     
            
      Hessian_R_W_trace = Hessian_leg(Qpoints_faces(:,:,1),m,h,RHHO_ind(j+1,:));
                        
      gradLaplacian_R_W_trace = gradLaplacian_leg(Qpoints_faces(:,:,1),m,h,RHHO_ind(j+1,:));
           
      %% Adding the normal and tangential vectos
      
      NGrad_R_W = (grad_R_W_trace(:,1).*n_vec(1)+grad_R_W_trace(:,2).*n_vec(2));
      
     
      NG_Hessian_R_W_trace = [Hessian_R_W_trace(:,1).*n_vec(1)+Hessian_R_W_trace(:,2).*n_vec(2),...
                              Hessian_R_W_trace(:,3).*n_vec(1)+Hessian_R_W_trace(:,4).*n_vec(2)];
      
      NGradLaplacian_R_W = (gradLaplacian_R_W_trace(:,1).*n_vec(1)+gradLaplacian_R_W_trace(:,2).*n_vec(2));
                   
      
       %% For second order operator
       
       s = -g_D_val.* NGrad_R_W;
      
      %% For fourth order operator
      
       % Dirichelte
       
       t1 = epsilon.*g_D_val.* NGradLaplacian_R_W;
       
       % Neumann
       
       t2 = -epsilon.*sum(grad_val.*NG_Hessian_R_W_trace ,2);
       
       
       t = t1+t2;
        
        temp(j) = dot(t+s,weights_faces);
                 
    end

    
    second = R'*temp;
    
    
z = first + second;


end
    