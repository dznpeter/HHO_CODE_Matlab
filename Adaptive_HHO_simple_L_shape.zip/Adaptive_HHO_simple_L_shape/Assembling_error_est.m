function total_estimator = Assembling_error_est(elem_err_est,int_eta_edge,bd_eta_edge,int_edge2elem,bd_edge2elem)

NT = size(elem_err_est,1);

total_residual = NaN(NT,1);

total_elem_residual = elem_err_est; 

total_edge_residual = [0.5.*bd_eta_edge; 0.5.*int_eta_edge];  

total_edge_residual = [total_edge_residual;total_edge_residual];

TotalEdge_edge2elem = [[bd_edge2elem;int_edge2elem(:,1)], [bd_edge2elem;int_edge2elem(:,2)]];

TotalEdge_edge2elem = TotalEdge_edge2elem(:);

parfor t =1:NT
   
    %% find all the edges to local elements 
         
     edge_ind = find(TotalEdge_edge2elem==t);     
     
     total_residual(t) =  total_elem_residual(t) + sum(total_edge_residual(edge_ind));
   
end
    



total_estimator = sqrt(total_residual);



