function Diri_edgeBasis = DiriBC_projecton(face_nodes, Po, HHO_face_ind,dim_face ,g_D)


[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);


% data for quadrature
    
 g_val = g_D(Qpoints_faces); 
 
 
 %% using the collocation projection method  based on inverting the local mass matrix 
 
 mass = NaN(dim_face,dim_face); F = NaN(dim_face,1);
 
 for j = 1: dim_face
    
     t_F = g_val.* Face_baisis(Qpoints_faces,face_nodes,Po,HHO_face_ind(j,:)); 

     
     F(j) = dot(t_F,weights_faces);
     
     
     for i  =1: dim_face
        
         t =  Face_baisis(Qpoints_faces,face_nodes,Po,HHO_face_ind(i,:)).*...
              Face_baisis(Qpoints_faces,face_nodes,Po,HHO_face_ind(j,:)) ;
          
        mass(j,i) = dot(t,weights_faces);
         
     end
     
          
 end
 
Diri_edgeBasis = mass\F;

end
    