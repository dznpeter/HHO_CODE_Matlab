function [ S_error ] = Err_stabilisation(face_nodes,BDbox, coef, local_dim_elem, Po,alpha, beta,out_normal_vectors,wrap_N ,HHO_elem_ind,HHO_face_ind,HHO_NF_face_ind,RHHO_ind)

%% First compute the local Reconstruction R_HHO


NF = size(face_nodes,3);


%dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 

dim_elem_cell = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 

dim_elem_face = size(HHO_face_ind,1); % Dimention for face basis on each individual face 

dim_elem_NF_face = size(HHO_NF_face_ind,1); % Dimention for face basis of normal flux variables on each individual face 




% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);

[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);


% penalty parameter is from trace inverse inequality, we can use h_k

h_k = norm(BDbox(2,:)-BDbox(1,:));  % it should not be h_f

alpha = alpha/h_k; % from the stability estimates  

beta = beta/h_k^3; % from the stability estimates 

%% computing the error



S_F_error=0;

   
%% Next is the face element matrix and face face matrix. The matrix depends on the number of faces.
%% Lehrenfeld-schoberl stabilisation


% there is totally NF faces, stabilisation is done on each face

%A_stab_Face = zeros(local_dim_elem,local_dim_elem,NF);



for k=1:NF
    
    
    local_edges_nodes =face_nodes(:,:,k);
    
    % compute the MFF matrix, this matrix is diagonal but not identity
    
M_FF = zeros(dim_elem_face,dim_elem_face);    
    

for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_face
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        V_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j,:)); 
        
        t =  sum(U_trace.*V_trace,2);
        
        M_FF(i,j) = dot(t,weights_faces(:,k));
        
    end
end


H_FF = M_FF; 



    
    %% Change the Mass matrix to H1 by modifying the last two lines  
            
      
       for j = 1:dim_elem_face
                           
        
        H_FF([dim_elem_face-1,dim_elem_face],j) =  Face_basis_Nodal_value(local_edges_nodes,HHO_face_ind(j,:));
        
       end
    
   

 H_FF_inv = inv(H_FF);   
 
 M_FF_inv = inv(M_FF); 
 

    
 %% computing the matrix M_FT
 
  %% computing the matrix M_FT
 
 
 M_FT_all = zeros(dim_elem_face,dim_elem_cell);  
    
 
for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_cell
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        R_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
        
        t =  sum(U_trace.*R_trace,2);
        
         M_FT_all(i,j) = dot(t,weights_faces(:,k));
        
    end
end

% M_FT_p is the first p part

M_FT_p = M_FT_all(1:dim_elem_face,1:dim_elem_cell);

H_FT_p = M_FT_p ;


 %% Change the Mass matrix to H1 by modifying the last two lines  
            
       for j = 1:dim_elem_cell
                           
        
        H_FT_p([dim_elem_face-1,dim_elem_face],j) =  tensor_leg(local_edges_nodes,m,h,HHO_elem_ind(j,:));
        
       end
    

       
       
%Define the difference operator on each face

H1_Proj_TF = H_FF_inv*H_FT_p; 

%Proj_TF = M_FF_inv*M_FT_p; 

% D_TF is dim_elem_face * local_dim_elem

D_TF=  zeros(dim_elem_face,local_dim_elem);

D_TF(1:dim_elem_face,1:dim_elem_cell) = H1_Proj_TF;

%D_TF(1:dim_elem_face,1:dim_elem_cell) = Proj_TF;


% Find the index of the face basis 

index_face_local = dim_elem_cell+((k-1)*dim_elem_face+1:k*dim_elem_face);



D_TF(:,index_face_local) = - eye(dim_elem_face);


%% After computing the Difference matrix, we can compute the stabilisation term on each edge



% the stabilisation operator



T = D_TF;


S_matrix = (T'*M_FF*T);

S_F_error = S_F_error+abs(beta.*coef'*S_matrix*coef);
 
end








S_NF_error=0;

   
%% Next is the face element matrix and face face matrix. The matrix depends on the number of faces.
%% Lehrenfeld-schoberl stabilisation


% there is totally NF faces, stabilisation is done on each face

%A_stab_Face = zeros(local_dim_elem,local_dim_elem,NF);



for k=1:NF
    
    
    local_edges_nodes =face_nodes(:,:,k);
    
    % compute the MFF matrix, this matrix is diagonal but not identity
    
M_FF_NF = zeros(dim_elem_NF_face,dim_elem_NF_face);    
    

for i = 1:dim_elem_NF_face
   
    %%symetric term
    
    for j=1:dim_elem_NF_face
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(i,:)); 
        
        V_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(j,:)); 
        
        t =  sum(U_trace.*V_trace,2);
        
        M_FF_NF(i,j) = dot(t,weights_faces(:,k)); %  for the trace variables
        
    end
end

    
 M_FF_NF_inv = inv(M_FF_NF);   
 

   
 %% computing the matrix M_FT
 
 
M_FT_NF = zeros(dim_elem_NF_face,dim_elem_cell);  
    

n_vec = out_normal_vectors(k,:); local_wrap = wrap_N(k);

 indicator = (-1)^local_wrap; % To see if the normal vector is take in a correct way
           
 
for i = 1:dim_elem_NF_face
   
    %%symetric term
    
    for j=1:dim_elem_cell
    
        % first term uv is symetric
                    
        U_trace =  Normal_Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(i,:)); 
        
        %U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(i,:));         
        
        grad_R_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
        
        NF_R_trace = n_vec(1).*grad_R_trace(:,1)+ n_vec(2).*grad_R_trace(:,2);
        
        t =  indicator.*U_trace.*NF_R_trace;
        
        M_FT_NF(i,j) = dot(t,weights_faces(:,k));
        
    end
end




%Define the difference operator on each face

Proj_TF_NF =  M_FF_NF_inv*M_FT_NF; 

% D_TF is dim_elem_face * local_dim_elem

D_TF_NF=  zeros(dim_elem_NF_face,local_dim_elem);

D_TF_NF(1:dim_elem_NF_face,1:dim_elem_cell) = Proj_TF_NF;



% Find the index of the face basis for normal flux 

index_NF_face_local = dim_elem_cell+NF*dim_elem_face+((k-1)*dim_elem_NF_face+1:k*dim_elem_NF_face);

%% if the different direction of the normal flux variables are given, we need to be carefull

    
D_TF_NF(:,index_NF_face_local) = - eye(dim_elem_NF_face);

%% After computing the Difference matrix, we can compute the stabilisation term on each edge


% the stabilisation operator

T_NF = D_TF_NF;



S_matrix = (T_NF'*M_FF_NF*T_NF);

S_NF_error = S_NF_error+abs(alpha.*coef'*S_matrix*coef);
 
end




S_error = S_F_error+ S_NF_error;
end


