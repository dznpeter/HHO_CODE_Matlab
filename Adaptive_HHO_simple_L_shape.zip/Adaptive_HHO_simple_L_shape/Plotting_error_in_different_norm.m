%clear all; close all;

%% different elements we use different order of basis

Total_level = 22;    start_level = 1;

Polynomial_degree = 1;   
 

Norm_type = 'DG'; % H2, H1, L2

err_P = NaN(Total_level,1); 

dof_P = NaN(Total_level,1);


for i=1 :Total_level
    
    
            
     load(['Error Mesh level ' num2str(i) ' for DG(P' num2str(Polynomial_degree) ') basis.mat'])
      
         
      switch Norm_type
          
          case 'DG'

        err_P(i,1)= DG_err; 
        
           case 'H1'

        err_P(i,1)= H1_err; 
        
        case 'L2'

        err_P(i,1)= L2_err; 
        
      end

     
dof_P(i) = dim_FEM;

       

end


%slope for poly

Pind = start_level:Total_level;


logerr_P1 = abs(log(err_P(:,1))); 

slope_P1 = abs((logerr_P1(2:end)-logerr_P1(1:end-1))./(log(dof_P(2:end).^(1./2))-log(dof_P(1:end-1).^(1./2))));

slope_Poly = mean(slope_P1(end-4:end-1));

%slope_Poly = max(slope_P1);

figure

switch Norm_type
          
          case 'DG'

       loglog(dof_P(Pind).^(1./2),err_P(Pind,1),'bs-.','LineWidth',2,'MarkerSize',10);
        
        
           case 'H1'

        loglog(dof_P(Pind).^(1./2),err_P(Pind,1),'ks-.','LineWidth',2,'MarkerSize',10);
        
        
        case 'L2'

       loglog(dof_P(Pind).^(1./2),err_P(Pind,1),'rs-.','LineWidth',2,'MarkerSize',10);
        
        
end
      

        
       

      

legend(['DG(P' num2str(Polynomial_degree) ') error slope ' num2str(slope_Poly)])


xlabel('Dof^{1/2}','FontSize',20);

switch Norm_type
    
    case 'DG'

ylabel('|||u-u_h|||','FontSize',20);
        
    case 'H1'

ylabel('|u-u_h|_{H^1{(\Omega)}}','FontSize',20);
    
    case 'L2'

ylabel('||u-u_h||_{L^2{(\Omega)}}','FontSize',20);
    

end

set(gca,'FontSize',20)

hold off;
