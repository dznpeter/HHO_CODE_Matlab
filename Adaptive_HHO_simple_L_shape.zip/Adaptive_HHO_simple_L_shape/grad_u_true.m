function z = grad_u_true(x)


if size(x,2)~= 2
    
   error('input should be 2 dimensional points')
    
end



r = sqrt(sum(x.^2,2));
theta = atan2(x(:,2),x(:,1));
theta = (theta>=0).*theta + (theta<0).*(theta+2*pi);

gx = (2/3).*r.^(-4/3).*(sin(2*theta/3).*x(:,1)-cos(2*theta/3).*x(:,2));

gy = (2/3).*r.^(-4/3).*(sin(2*theta/3).*x(:,2)+cos(2*theta/3).*x(:,1));

z1 = [gx,gy];



z = z1;

end