function d1 = levelset1(x)

% d1>=0 means inside

r = sqrt((x(:,1).^2+x(:,2).^2));

d1 = (1- r.^2 );

end