function [P_Qpoints,weights]=quad_poly_special(elem_nodes,Po)

%%%% Quadtrature is not based on the dulaunay!!!!

%elem = delaunay(elem_nodes);  

Nn = size(elem_nodes,1);

elem = [[1:Nn-2]',[2:Nn-1]',Nn.*ones(Nn-2,1)];

NTri = size(elem,1);

for k = 1:NTri
       
[tri_P_Qpoints, tri_weights] = quad_tri(elem_nodes(elem(k,:),:),Po);

NO_points = size(tri_P_Qpoints,1);

if k==1

P_Qpoints = NaN(NTri*NO_points,size(tri_P_Qpoints,2));

weights = NaN(NTri*NO_points,size(tri_weights,2));

end

P_Qpoints((k-1)*NO_points+1:1: k*NO_points,:) = tri_P_Qpoints;

weights((k-1)*NO_points+1:1: k*NO_points,:) = tri_weights;

end
  