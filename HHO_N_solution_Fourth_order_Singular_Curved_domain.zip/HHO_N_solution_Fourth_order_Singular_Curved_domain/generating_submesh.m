function [submesh,BDbox] = generating_submesh(tindex, elem,BDbox,Node,bd_edge2elem,no_subtriangles_curve)

%%%%%%%%%Test if it is an element with curved boundary

[test_ind ,~ ,~] = find((bd_edge2elem-tindex)==0); 


if isempty(test_ind) ==1  % This element does not contain boundary edges

%%%%%%%%%%%%%%%%%%%%%%%%

Ntri = size(elem,1);

submesh = NaN(3,2,Ntri);

for i = 1:Ntri
   
    
    submesh(:,:,i) = Node(elem(i,:)',:);
    
end

else  %% There are boundary edges
    
    %no_subtriangles_curve = 20;
    
    node_tri = Node(elem,:);
    
    h = norm(node_tri(1,:)-node_tri(2,:));
    
    d1 = levelset1(node_tri);  
    
    % number of points on Level set 1
    
    [index_points_level1 ,~ ,~] = find(abs(d1)<=0.001*h); 
    
    if length(index_points_level1) ==2  % one edge on the level set one
    
        c_ind = 1:3;  c_ind(index_points_level1)=[]; 
        
        cnodes = node_tri(c_ind,:);
        
         bd_node = node_tri(index_points_level1,:); 
        
     curved_nodes = shape_levelset1(bd_node,no_subtriangles_curve);
    
    
    else %% one edge on the level set 2
        
          d2 = levelset2(node_tri);  
        
        [c_ind ,~ ,~] = find(abs(d2)>0.001*h); 
                        
        
        cnodes = node_tri(c_ind,:);
        
        bd_node = node_tri;  bd_node(c_ind ,:)=[];
        
       curved_nodes = shape_levelset2(bd_node,no_subtriangles_curve);
       
       

    end

    
    Ntri = no_subtriangles_curve;

submesh = NaN(3,2,Ntri);



%%%%%%%%%%%%%put all the curved edges into the submeshes


for i = 1:Ntri
   
    local_node = [ cnodes; curved_nodes(i,:);curved_nodes(i+1,:)];
    
    submesh(:,:,i) = local_node;
               
end
    
max_x = max([curved_nodes(:,1);BDbox(:,1)]); min_x = min([curved_nodes(:,1);BDbox(:,1)]);

max_y = max([curved_nodes(:,2);BDbox(:,2)]); min_y = min([curved_nodes(:,2);BDbox(:,2)]);

BDbox = [[min_x, min_y];[max_x, max_y]];

end




end
