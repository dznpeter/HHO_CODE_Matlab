function z = vect_forcing(elem_nodes,BDbox,  Po, HHO_elem_ind, f)

% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);

[Qpoints_elem,weights_elem]=quad_poly(elem_nodes,Po); % get the quadrature points on polygon

dim_elem_inter = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 


   
    % data for quadrature
    
    f_val = f(Qpoints_elem); 

first = zeros(dim_elem_inter,1);
    
for j = 1:dim_elem_inter
   
   
    
        % first term {fv} 
        
        v_val = tensor_leg(Qpoints_elem,m,h,HHO_elem_ind(j,:));
         
        t = f_val.*v_val;
        
        first(j) = dot(t,weights_elem);
      
    
end

z = first;







end