function [ S_error ] = Err_stabilisation(face_nodes,BDbox, coef, local_dim_elem, Po,sigma ,HHO_elem_ind,HHO_face_ind,RHHO_ind)

%% First compute the local Reconstruction R_HHO


NF = size(face_nodes,3);


dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 

dim_elem_inter = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 

dim_elem_face = size(HHO_face_ind,1); % Dimention for face basis on each individual face 




% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);

[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);


% penalty parameter is from trace inverse inequality, we can use h_k

h_k = norm(BDbox(2,:)-BDbox(1,:));  % it should not be h_f

 
sigma = sigma/h_k; % from the stability estimates 


%% computing the error



S_error=0;

   
%% Next is the face element matrix and face face matrix. The matrix depends on the number of faces.
%% Lehrenfeld-schoberl stabilisation


% there is totally NF faces, stabilisation is done on each face

%A_stab_Face = zeros(local_dim_elem,local_dim_elem,NF);



for k=1:NF
    
    
    local_edges_nodes =face_nodes(:,:,k);
    
    % compute the MFF matrix, this matrix is diagonal but not identity
    
M_FF = zeros(dim_elem_face,dim_elem_face);    
    

for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_face
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        V_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j,:)); 
        
        t =  sum(U_trace.*V_trace,2);
        
        M_FF(i,j) = dot(t,weights_faces(:,k));
        
    end
end

    
 M_FF_inv = inv(M_FF);   
    
    
 %% computing the matrix M_FT
 
 
 M_FT_all = zeros(dim_elem_face,dim_elem_R);  
    
 
for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_R
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        R_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(j,:));
        
        t =  sum(U_trace.*R_trace,2);
        
         M_FT_all(i,j) = dot(t,weights_faces(:,k));
        
    end
end


% M_FT_p is the first p part

M_FT_p = M_FT_all(1:dim_elem_face,1:dim_elem_inter);


%Define the difference operator on each face

Proj_TF = M_FF_inv*M_FT_p; 

% D_TF is dim_elem_face * local_dim_elem

D_TF=  zeros(dim_elem_face,local_dim_elem);

D_TF(1:dim_elem_face,1:dim_elem_inter) = Proj_TF;


% Find the index of the face basis 

index_face_local = dim_elem_inter+((k-1)*dim_elem_face+1:k*dim_elem_face);



D_TF(:,index_face_local) = D_TF(:,index_face_local) - eye(dim_elem_face);


%% After computing the Difference matrix, we can compute the stabilisation term on each edge



% the stabilisation operator

T = D_TF;


S_matrix = (T'*M_FF*T);

S_error = S_error+abs(sigma.*coef'*S_matrix*coef);
 
end



end


