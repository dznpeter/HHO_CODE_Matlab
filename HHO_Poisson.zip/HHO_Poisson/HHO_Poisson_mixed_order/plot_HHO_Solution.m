%%plot HHO solution 

clear all;

Polydegree = 2;

Dimension =2; 

NT = 256;

Mesh_type = 'rectangle'; % polygonal, rectangle

Solution_type = 'RHHO'; % HHO, RHHO


load([num2str(NT) ' ' num2str(Mesh_type) ' Elements.mat'])

%{

% true solution 
U_true = u_true(Node);

figure 

hold on;


for i=1:NT
   
    elem = Elem{i};
    
    node = Node(elem,:);
        
    z = u_true(node); 
    
    c = (z-min(U_true))./max(U_true);
    
    fill3(node(:,1),node(:,2),z,c)    
end

hold off ; view(3);

%}


%% HHO Solution 

load(['Error ' num2str(NT) ' ' num2str(Mesh_type) ' Elements P' num2str(Polydegree) ' basis.mat'])


Polydegree_elem = Polydegree+1; 

Polydegree_face = Polydegree; 

R_Polydegree = Polydegree+1; 


%% polynomial index for the HHO solution in P_p space on element

HHO_elem_ind = Basis_index_generator2D(Polydegree_elem,Dimension);


%% polynomial index for the HHO solution in P_p space on face

HHO_face_ind = Basis_index_generator2D(Polydegree_face,Dimension-1);



%% polynomial order for the Reconstrcution HHO in P_(p+1) space on element

   
RHHO_ind = Basis_index_generator2D(R_Polydegree,Dimension);



dim_elem = nchoosek(Polydegree_elem+Dimension,Dimension);   

dim_face = nchoosek(Polydegree_face+Dimension-1,Dimension-1); 

dim_elem_R = size(RHHO_ind,1); 


dim_total_elem = dim_elem.*NT;

NF = size(Full_edge,1);

dim_total_face = dim_face.*NF;

dim_FEM = dim_total_elem + dim_total_face;


figure 

hold on

for t =1:NT
   
   [elem, BDbox, Face_index] = Elem{t,:};     elem_nodes =Node(elem,:);
    
    local_face_index = Full_edge(Face_index,:); 
    
    face_nodes = get_face_nodes(local_face_index,Node);
    
    %% deal with the normal vector for the edges 
    
    out_normal_vectors = get_normal_vector(t,Face_index,intnorvec,bdnorvec,int_edge2elem);
   
   Global_basis_index = findGlobalindex(t,Face_index,dim_elem,dim_face,dim_total_elem);
            
    % calculating nodal values 
    
    coef = U(Global_basis_index );  % c is coefficeint
       
    % information about the bounding box

    h = (BDbox(2,:)-BDbox(1,:))./2;  

    m = 0.5.*sum(BDbox);

    P = zeros(size(elem_nodes,1) ,dim_elem_R);  
    
    for i =1:dim_elem_R
        
        P(:,i)= tensor_leg(elem_nodes,m,h,RHHO_ind(i,:));    
                                 
    end
    
    switch Solution_type
        
        case 'HHO'
    
    dim_elem_inter = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 
  
    u_HHO_val = P(:,1:dim_elem_inter)*coef(1:dim_elem_inter);   % HHO solution;
  
    
    fill3(elem_nodes(:,1),elem_nodes(:,2),u_HHO_val,u_HHO_val) ; 
    
    title('HHO solution $u_h$','Interpreter','latex');
    
    
        case 'RHHO'
            
    R_coef =  R_HHO(:,t);
            
  
    u_R_HHO_val = P*R_coef;   % HHO solution;
  
    
    fill3(elem_nodes(:,1),elem_nodes(:,2),u_R_HHO_val,u_R_HHO_val) ; 
    
    title('Reconstruction HHO solution $R(\hat{u}_h)$','Interpreter','latex');
            
    end
    
    set(gca,'FontSize',20);
end



hold off;view(3);