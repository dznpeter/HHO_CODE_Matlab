function z = Hessian_u_true(X)


if size(X,2)~= 2
    
   error('input should be 2 dimensional points')
    
end

x = X(:,1); y = X(:,2);




z = [ 2.*pi.*cos(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 2.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) + 4.*x.^2.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 4.*x.^2.*pi.^2.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 8.*pi.*x.^2.*cos(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2), 4.*x.*y.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 4.*x.*y.*pi.^2.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 8.*pi.*x.*y.*cos(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2), 4.*x.*y.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 4.*x.*y.*pi.^2.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 8.*pi.*x.*y.*cos(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2), 2.*pi.*cos(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 2.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) + 4.*y.^2.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 4.*y.^2.*pi.^2.*sin(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2) - 8.*pi.*y.^2.*cos(pi.*(x.^2 + y.^2 - 1)).*exp(- x.^2 - y.^2)];


end