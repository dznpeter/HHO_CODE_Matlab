function [weights,P_Qpoints] = quad_edge(node,Po)

[weights,ref_Qpoints] = quad_GL(ceil((Po+1)*0.5));

%change the quadrature nodes from reference domain to physical domain.

mid= sum(node)./2;   tanvec = 0.5* (node(2,:)-node(1,:));

C = kron(mid,ones(size(ref_Qpoints,1),1));

P_Qpoints = kron(ref_Qpoints,tanvec) + C;  De = norm((node(2,:)-node(1,:))).*0.5;

weights= weights*De;