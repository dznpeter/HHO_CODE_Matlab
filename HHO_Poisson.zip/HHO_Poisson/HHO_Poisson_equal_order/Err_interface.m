function DGPart_2 = Err_interface(node,vertice,BDbox1,BDbox2,  coef1,coef2,n ,Po ,Lege_ind,alpha, beta)



h1 = (BDbox1(2,:)-BDbox1(1,:))./2;  h2 = (BDbox2(2,:)-BDbox2(1,:))./2;


m1 =  0.5.*sum(BDbox1);     m2 =  0.5.*sum(BDbox2); 

dim_elem =size(Lege_ind,1); % number of basis for each element.


DGPart_2=0;

% generating quadrature points and weights

%[weights,ref_Qpoints] = Golub_Welsch(ceil(Po/2));

[weights,ref_Qpoints] = quad_GL(ceil((Po+1)*0.5));

%change the quadrature nodes from reference domain to physical domain.

mid= sum(node)./2;   tanvec = 0.5* (node(2,:)-node(1,:));

C = kron(mid,ones(size(ref_Qpoints,1),1));

P_Qpoints = kron(ref_Qpoints,tanvec) + C;  De = norm((node(2,:)-node(1,:))).*0.5;

% penalty term

%a_center = a(mid);

%lamda = eigs(reshape(a_center,2,2),1);


%temp = [n(1).^2,n(1).*n(2),n(1).*n(2),n(2).^2 ];

%lamda = dot(a_center,temp);

%correct measure

measure_B = De*max(abs(sum((vertice-kron(node(1,:),ones(size(vertice,1),1))).*kron(n,ones(size(vertice,1),1)),2)));


alpha = alpha.*(2.*De/measure_B)^3; % \alpha = penalty * p^6/h^3;


beta = beta.*(2.*De/measure_B);   % \beta = penalty * p^2/h; 

n_vec =kron(n,ones(size(ref_Qpoints,1),1));

 
    % construct the matrix for all the local basis function

    
    P1 = zeros(size(P_Qpoints,1) ,dim_elem);
    
    P1x = zeros(size(P_Qpoints,1) ,dim_elem);
    
    P1y = zeros(size(P_Qpoints,1) ,dim_elem);
    
    
    for i =1:dim_elem
        
        P1(:,i)= tensor_leg(P_Qpoints,m1,h1,Lege_ind(i,:));
        
        t = gradtensor_leg(P_Qpoints,m1,h1,Lege_ind(i,:));
        
        P1x(:,i) = t(:,1); P1y(:,i) = t(:,2); 
        
    end
  
    u_DG_val1 = P1*coef1;   %DG solution on Kappa1;
    
    grad_u_DG1 = [P1x*coef1 , P1y*coef1];   %gradient of DG on Kappa1;
    
    
    
     P2 = zeros(size(P_Qpoints,1) ,dim_elem);
     
     P2x = zeros(size(P_Qpoints,1) ,dim_elem);
    
     P2y = zeros(size(P_Qpoints,1) ,dim_elem);
     
    
    for i =1:dim_elem
        
        P2(:,i)= tensor_leg(P_Qpoints,m2,h2,Lege_ind(i,:));
        
        t = gradtensor_leg(P_Qpoints,m2,h2,Lege_ind(i,:));
        
        P2x(:,i) = t(:,1); P2y(:,i) = t(:,2); 
        
    end
  
    u_DG_val2 = P2*coef2;   %DG solution on Kappa2;
    
    grad_u_DG2 = [P2x*coef2 , P2y*coef2];   %gradient of DG on Kappa2;
     
    
     
    
     
     % Part 2 DG norm error   
     % sigma*jump{u_DG}^2+2a(grad_u - aver{grad_U_DG})\cdot jump{u_DG} 
     
     jump_u_DG = (u_DG_val1-u_DG_val2);
          
     
     t1 = alpha.*jump_u_DG.^2;
     
     
     jump_grad_u_DG = (grad_u_DG1-grad_u_DG2);
          
     
      t2 = beta.* sum((n_vec.*jump_grad_u_DG).^2,2);
     
     
     t = t1+t2;
     

     DGPart_2= DGPart_2+ De.*dot((t),weights);

end