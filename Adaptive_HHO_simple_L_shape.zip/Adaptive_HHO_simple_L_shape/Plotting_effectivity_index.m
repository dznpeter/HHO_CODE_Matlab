%clear all; close all;

figure


Polynomial_degree = 1;   


end_interval = [28, 47, 75, 101, 119];


%% different elements we use different order of basis

start_level = 1; Total_level = end_interval(Polynomial_degree+1);   


Marker = {'s','^','o','d','*','>'};

err_P = NaN(Total_level,1);  err_eta_P = NaN(Total_level,1); 

dof_P = NaN(Total_level,1);


for i=1 :Total_level
    
    
            
  %load(['Error Mesh level ' num2str(i) ' for HHO(P' num2str(Polynomial_degree) ') basis ' num2str(estimator_type) '.mat'])
      
      load(['Error Mesh level ' num2str(i) ' for HHO(P' num2str(Polynomial_degree) ') basis.mat'])
             
    
%      switch estimator_type
%     
%     case 'conforming'  % with nornal flux jump
%         
%         total_estimator =  total_estimator_C;
%         
%        err_eta_P(i) = sqrt(sum(total_estimator.^2)); 
%            
%         
%     case 'nonconforming'  % without nornal flux jump
%         
%         total_estimator =  total_estimator_N;
%         
%         err_eta_P(i) = sqrt(sum(total_estimator.^2)); 
%        
%         
%       end

total_estimator = min([total_estimator_N, total_estimator_C],[],2);

     err_eta_P(i) = sqrt(sum(total_estimator.^2)); 
      
        err_P(i,1)= Energy_err;   
        
     
        
dof_P(i) = dim_FEM;

       

end

Pind = start_level:Total_level;


effeciency_index = err_eta_P./err_P;

%figure;

plot(dof_P(Pind),effeciency_index(Pind),['k-' num2str(Marker{Polynomial_degree+1})],'LineWidth',2,'MarkerSize',10);
        
        

      

%legend(['HCT3 error slope ' num2str(slope_Poly)],['HCT3 estimator slope ' num2str(slope_Poly_est)])



   
%   switch estimator_type
%           
%     
%   case 'conforming'  % with nornal flux jump
%    
%         
%       h= legend(['k' num2str(Polynomial_degree) ' effectivity (C)']); set(h,'Interpreter','latex')   
% 
%         
%   case 'nonconforming'  % without nornal flux jump
%         
%       h= legend(['k' num2str(Polynomial_degree) ' effectivity (NC)']); set(h,'Interpreter','latex')   
% 
%         
%   end

    h = legend(['k' num2str(Polynomial_degree)],...
       ['k' num2str(Polynomial_degree) ' estimator'],...
       ['$\mathcal{O}({\rm DoFs}^{-\frac{' num2str(Polynomial_degree+1) '}{2}})$']);

  


xlabel('${\rm DoFs}$','FontSize',20,'Interpreter','latex');


ylabel('Effectivity index','FontSize',20,'Interpreter','latex');
        
       


set(gca,'FontSize',30)

set(gca,'FontSize',30)





