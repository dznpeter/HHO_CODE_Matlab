%% Show the mesh

%clear all;


%load('16 polygonal Elements.mat')


figure;
hold on;
for i = 1: NT
 %% plot element
 
b = Node(Elem{i,1},:);
plot([b(:,1) ;b(1,1)],[b(:,2); b(1,2)],'k-','LineWidth',1)    


end

