function z = u_true(x)


if size(x,2)~= 2
    
   error('input should be 2 dimensional points')
    
end


 %Case 1

 z = sin(pi.*x(:,1)).*sin(pi.*x(:,2));


% % %Case 2


%z = x(:,1).*(1-x(:,1)).*x(:,2).*(1-x(:,2));

end