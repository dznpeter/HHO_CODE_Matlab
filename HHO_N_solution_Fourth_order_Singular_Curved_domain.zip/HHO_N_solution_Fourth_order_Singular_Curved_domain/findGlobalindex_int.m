         
function Global_basis_index = findGlobalindex_int(t,Face_index,int_BD_ind,dim_elem,dim_face,dim_NF_face,dim_total_elem,dim_total_face)


%% for t_th element 

global_elem_index = ((t-1)*dim_elem+1  : t*dim_elem)';

%% for different faces of face basis for trace variable and flux variable

interior_face_ind= find(int_BD_ind~=0);


int_Face_index= Face_index(interior_face_ind);

global_int_face_index = NaN(dim_face,size(int_Face_index,1));

global_int_NF_face_index = NaN(dim_NF_face,size(int_Face_index,1));

for k=1:size(int_Face_index,1)
    
   global_int_face_index(:,k) = ((Face_index(k)-1)*dim_face+1 : Face_index(k)*dim_face)'; 
   
   
   global_int_NF_face_index(:,k) = ((Face_index(k)-1)*dim_NF_face+1 : Face_index(k)*dim_NF_face)'; 
    
end

global_int_face_index = global_int_face_index(:)+dim_total_elem;

global_int_NF_face_index = global_int_NF_face_index(:)+dim_total_elem + dim_total_face;


Global_basis_index =[global_elem_index;global_int_face_index;global_int_NF_face_index];

end