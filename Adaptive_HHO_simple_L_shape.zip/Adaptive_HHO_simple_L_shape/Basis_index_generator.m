function  Lege_ind = Basis_index_generator(Polydegree,Basis_Type,Dimension)

if Dimension ==2
   

switch Basis_Type 
    

    case 'P'
               

% P basis

t=0:Polydegree;  t=t';

temp = ones(Polydegree+1,1);

Lege_ind = [kron(t,temp) , kron(temp,t)];

% delete the index 

index = find( sum(Lege_ind,2) > Polydegree );

Lege_ind(index,:) = [];

    
    case 'Q'

% Q basis

t=0:Polydegree;  t=t';

temp = ones(Polydegree+1,1);

Lege_ind = [kron(t,temp) , kron(temp,t)];



    case 'S'
               

% Smolyak basis

t=0:Polydegree;  t=t';

temp = ones(Polydegree+1,1);

Qindex = [kron(t,temp) , kron(temp,t)];

% delete the index 

testQindex = Qindex;

ind_0 = find(testQindex(:) == 0);  ind_1 = find(testQindex(:) == 1); 

testQindex(ind_0) = 1;   testQindex(ind_1) = 2; 

ind_S = find( sum(log2(testQindex),2) <= log2(Polydegree));


Lege_ind = Qindex(ind_S,:);




case 'HC'
    
    %% Hyperbolic_Cross_type_2


t=0:1:Polydegree;  t=t';

temp = ones(Polydegree+1,1);

Qindex = [kron(t,temp) , kron(temp,t)];

%% choose the Smolyak basis from Q basis


testQindex = Qindex;

ind_0 = find(Qindex(:) == 0); 

testQindex(ind_0) = 1; 

ind_H = find(prod(testQindex,2) <= Polydegree);

Lege_ind = Qindex(ind_H,:);


end


end





if Dimension ==3
   

switch Basis_Type 
    

    case 'P'
               

% P basis

t=0:Polydegree;  t=t';

temp = ones(Polydegree+1,1);

Lege_ind = [  kron(kron(t,temp),temp) , kron(kron(temp,t),temp), kron(kron(temp,temp),t)];


% delete the index 

index = find( sum(Lege_ind,2) > Polydegree );

Lege_ind(index,:) = [];

    
    case 'Q'

% Q basis

t=0:Polydegree;  t=t';

temp = ones(Polydegree+1,1);

Lege_ind = [  kron(kron(t,temp),temp) , kron(kron(temp,t),temp), kron(kron(temp,temp),t)];



 case 'PQ'
               

% 2D space with P basis tensor 1D time

t=0:Polydegree;  t=t';

temp = ones(Polydegree+1,1);

Lege_ind = [  kron(kron(t,temp),temp) , kron(kron(temp,t),temp), kron(kron(temp,temp),t)];


% delete the index 

index = find( sum(Lege_ind(:,1:2),2) > Polydegree );

Lege_ind(index,:) = [];


case 'S'
               

% S basis

t=0:Polydegree;  t=t';

temp = ones(Polydegree+1,1);

Qindex = [  kron(kron(t,temp),temp) , kron(kron(temp,t),temp), kron(kron(temp,temp),t)];


% delete the index 

%% choose the Smolyak basis from Q basis

testQindex = Qindex;

ind_0 = find(Qindex(:) == 0);  ind_1 = find(Qindex(:) == 1); 

testQindex(ind_0) = 1; testQindex(ind_1) = 2; 

ind_S = find( sum(log2(testQindex),2) <= log2(Polydegree));

Lege_ind = Qindex(ind_S,:);



case 'SP'
    
  Qindex = Basis_index_generator(Polydegree,'S',Dimension-1);
    
  s_index = Qindex(:,1);  t_index = Qindex(:,2);  
  
  % change 1D space index to 2D P basis
 

Z_index = (s_index+1).*(s_index+2)./2;   

No = sum(Z_index);

Z_index = cumsum(Z_index) ;  

S2index = NaN(No,3);

%% i =0 

S2index(1:1:Z_index(1),1:2) = Basis_index_generator(s_index(1),'P',2); 
     
S2index(1:1:Z_index(1),3)  =  kron(t_index(1),ones(Z_index(1),1));
    

for i=2: size(s_index,1)
    
    
     S2index(Z_index(i-1)+1:1:Z_index(i),1:2) = Basis_index_generator(s_index(i),'P',2); 
     
     S2index(Z_index(i-1)+1:1:Z_index(i),3)  =  kron(t_index(i),ones(Z_index(i)-Z_index(i-1),1));
    
end

    

SPindex = unique(S2index,'rows');
  
Lege_ind = SPindex;




case 'HC'
    
    %% Hyperbolic_Cross_type_2


t=0:1:Polydegree;  t=t';

temp = ones(Polydegree+1,1);

Qindex = [  kron(kron(t,temp),temp) , kron(kron(temp,t),temp), kron(kron(temp,temp),t)];


%% choose the Smolyak basis from Q basis


testQindex = Qindex;

ind_0 = find(Qindex(:) == 0); 

testQindex(ind_0) = 1; 

ind_H = find(prod(testQindex,2) <= Polydegree);

Lege_ind = Qindex(ind_H,:);

end


end


end