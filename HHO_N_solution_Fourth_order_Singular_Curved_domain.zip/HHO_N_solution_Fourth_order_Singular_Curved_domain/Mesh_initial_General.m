

addpath(genpath('ifem'))


%% The initialization will only be done in level 1

% The mesh will aggolomerate for Corsen_LeveL, and when the number of
% elemetns are less than Min_No_Elem, then it will stop.


fd=inline('ddiff(dcircle(p,0,0,1),dcircle(p,0.25,0.2,0.4))','p');

[node_tri,elem_tri]=distmesh2d(fd,@huniform,0.2*(2)^(-4.1),[-1,-1;1,1],[]);




%{


% 
% 
% %% Generating the level 0 for the background triangular elements
% 
% [node_tri,elem_tri] = squaremesh([0,1,0,1],1);
% 
% 
%  for k=1:5
% 
%  [node_tri,elem_tri]=uniformrefine(node_tri,elem_tri);
%  
%  end
%  
%   for k=1:2
%  
%  [node_tri,elem_tri]=uniformbisect(node_tri,elem_tri);
%  
%   end
%   
%   
% 
% %% modify the geometry  
% 
% % modify the boudnary 
% 
% [node_tri,elem_tri] = delmesh(node_tri,elem_tri,'y < 0.01 + cos(20*pi*x)*0.01');
% 
% [node_tri,elem_tri] = delmesh(node_tri,elem_tri,'y > (1-0.01) + cos(20*pi*x)*0.01');
% 
% [node_tri,elem_tri] = delmesh(node_tri,elem_tri,'x > (1-0.01) + cos(20*pi*y)*0.01');
% 
% [node_tri,elem_tri] = delmesh(node_tri,elem_tri,'x < (0.01) + cos(20*pi*y)*0.01');
% 
% % add a hole
% 
% %[node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-(1-0.01)).^2+(y-(1-0.01)).^2 < 0.1^2');
% 
% 
% 
% 
% % add a circle inside the mesh
% 
% [node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-0.3).^2+(y-0.3).^2 < 0.1^2');
% 
% %[node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-0.5).^2+(y-0.25).^2 < 0.02^2');
% 
% [node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-0.7).^2+(y-0.3).^2 < 0.05^2');
% 
% [node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-0.3).^2+(y-0.7).^2 < 0.04^2');
% 
% %[node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-0.5).^2+(y-0.5).^2 < 0.05^2');
% 
% [node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-0.7).^2+(y-0.7).^2 < 0.025^2');
% 
% %[node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-0.25).^2+(y-0.75).^2 < 0.025^2');
% 
% %[node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-0.5).^2+(y-0.75).^2 < 0.035^2');
% 
% %[node_tri,elem_tri] = delmesh(node_tri,elem_tri,'(x-0.75).^2+(y-0.75).^2 < 0.045^2');
% 


%}
%showmesh(node_tri,elem_tri);



  
  T = auxstructure(elem_tri); % Data needed for agglomoration
     
 
Node=node_tri;  Element=elem_tri;  

%clear  node elem;

%% Generate bounding box for each polygonal element

% move to the correct place.

n = 12;   Node = round(10^n.*Node)/10^n;


%  and  finding all the edges. Label element to edges Background meshes

N_tri = size(Node,1); NT_tri = size(Element,1); 

Elem_tri = cell(NT_tri,2);  P = NaN(NT_tri,2);

P1 = NaN(NT_tri,2); P2 = NaN(NT_tri,2); P3 = NaN(NT_tri,2);

totalEdge = NaN(3*NT_tri,2); elemperedge = 3*ones(NT_tri,1);

totalNode = NaN(3*NT_tri,1); elempernode = 3*ones(NT_tri,1);


for i =1: NT_tri
    
    % barycenter
    
    P(i,:) = sum(Node(Element(i,:)',:))./size(Node(Element(i,:)',:),1);
    
    P1(i,:) = Node(Element(i,1)',:);
    
    P2(i,:) = Node(Element(i,2)',:);
    
    P3(i,:) = Node(Element(i,3)',:);
    % calculate all the bounding box
    
    Elem_tri{i,1}= Element(i,:)';
   
    
    bdbox_x = sort(Node(Element(i,:)',1));
    
    bdbox_y = sort(Node(Element(i,:)',2));
    
    Elem_tri{i,2} = [bdbox_x([1,end]) ,  bdbox_y([1,end])]; %bounding box is [x_min y_min
                                                        %                 x_max y_max]
                                                                                                        
    % take out all the edges  
    
    totalEdge((i-1)*3+1:3*i,:) = [[elem_tri(i,:)', [elem_tri(i,(2:end))'; elem_tri(i,(1))' ] ] ] ;                                                       
    
    totalNode((i-1)*3+1:3*i,:) = elem_tri(i,:)';
    
end

elemtotaledge = cumsum(elemperedge);

elemtotalnode = cumsum(elempernode);


%% Classsify all the nodes 
% build up the link from each node to element 

node2elem = cell(N_tri,1); 

parfor i = 1: N_tri
   
    edge2elem = elem_share_node(i,totalNode,elemtotalnode);
    
    node2elem{i} =   edge2elem';
    
end


%% Classify all the edges

% totalEdge is all the edges from summation of each element
% edge is the all the edges from triagulation 
% bdEdge is the boundary edge and intEdge is the interior edge

totalEdge = sort(totalEdge, 2);

[i , j ,s ] = find(sparse(totalEdge(:,2),totalEdge(:,1),1));

allEdge_tri = [j,i]; bdEdge_tri = [j(s==1), i(s==1)]; intEdge_tri = [j(s==2), i(s==2)];

%% The relation between edge to element and

% internal edge is shared by 2 elements and boundary edge is only used by 1
% edge

int_edge2elem_tri = NaN(size(intEdge_tri,1),2); bd_edge2elem_tri = NaN(size(bdEdge_tri,1),1);

parfor i = 1: size(intEdge_tri,1)
   
    edge2elem = elem_share_edge(intEdge_tri(i,:),totalEdge,elemtotaledge);
    
    int_edge2elem_tri(i,:) =   edge2elem';
    
end

parfor i = 1: size(bdEdge_tri,1)
   
    edge2elem = elem_share_edge(bdEdge_tri(i,:),totalEdge,elemtotaledge);
    
    bd_edge2elem_tri(i) =   edge2elem;
    
end



%% Outward Normal vectors for all boundary edges

% For bdedge, only one normal vector
% For internal edge there two normnal vector, but we only use one.

% tangert vector of the edge%%%%%%
 bdtan_vec_tri = Node(bdEdge_tri(:,1),:) - Node(bdEdge_tri(:,2),:);
 
inttan_vec_tri = Node(intEdge_tri(:,1),:) - Node(intEdge_tri(:,2),:);
 
  % normal vector of the edge%%%%%%
 bdnorvec_tri = [bdtan_vec_tri(:,2)./sqrt(bdtan_vec_tri(:,1).^2 +bdtan_vec_tri(:,2).^2) , -bdtan_vec_tri(:,1)./sqrt(bdtan_vec_tri(:,1).^2 +bdtan_vec_tri(:,2).^2)];

intnorvec_tri = [inttan_vec_tri(:,2)./sqrt(inttan_vec_tri(:,1).^2 +inttan_vec_tri(:,2).^2) , -inttan_vec_tri(:,1)./sqrt(inttan_vec_tri(:,1).^2 +inttan_vec_tri(:,2).^2)];
 
% outward normal vector of the edge%%%%%%
  bdoutward = Node(bdEdge_tri(:,1),:)-P(bd_edge2elem_tri(:),:);
  
  intoutward = Node(intEdge_tri(:,1),:)-P(int_edge2elem_tri(:,1),:); % the first element
 
  
 
 bdindex =  max(sum(bdnorvec_tri.*bdoutward,2),0);
 
 intindex =  max(sum(intnorvec_tri.*intoutward,2),0);
 
 [i ,j ,s] = find(bdindex==0);   [m ,n ,k] = find(intindex==0);
 
 bdnorvec_tri(i,:) = - bdnorvec_tri(i,:);
  
 intnorvec_tri(m,:) = - intnorvec_tri(m,:);

 %showmesh(node_tri,elem_tri)
 
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%% All information about the background meshes are derived %%%%%%
 
 NT =  NT_tri;
 
 Elem = Elem_tri;
 
 bdEdge = bdEdge_tri;
 
 bd_edge2elem = bd_edge2elem_tri;
 
 intEdge = intEdge_tri;
 
 int_edge2elem = int_edge2elem_tri;
 
 bdnorvec = bdnorvec_tri;
 
 intnorvec = intnorvec_tri;
 
 
%% find each element contains which edge
% the global index of edge is based as inter_edge, BD_edge
  
parfor i =1: NT
    
 index_int1 = find(int_edge2elem(:,1)==i);
 
 index_int2 = find(int_edge2elem(:,2)==i);
 
 index_bd =  find(bd_edge2elem(:)==i);
 
    
    Elem{i,3}= [index_int1; index_int2; index_bd+size(intEdge,1)];
       
end


Full_edge = [intEdge;bdEdge];
 
 
 
  savefile = [ num2str(NT) ' polygonal Elements.mat'];
 
 save(savefile, 'Elem','Node','NT','bdEdge','bd_edge2elem','intEdge','int_edge2elem','bdnorvec','intnorvec','Full_edge','-v7.3');
