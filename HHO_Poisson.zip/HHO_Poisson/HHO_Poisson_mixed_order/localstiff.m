function [local_stiff,local_reconstruction] = localstiff(elem_nodes,face_nodes,BDbox,sigma,out_normal_vectors,local_dim_elem, Po,HHO_elem_ind,HHO_face_ind,RHHO_ind,assume_dim_elem)

NF = size(face_nodes,3);

% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);

[Qpoints_elem,weights_elem]=quad_poly_special(elem_nodes,Po); % get the quadrature points on polygon

%% find the quadtrature points on each edge

[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);

%%%%%%%%%%%%%%%%%%%%%%%%Local reconstruction%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% local_dim_elem = dim(HHO_elem_ind+HHO_face_ind*NF)
% dim_elem_R = dim(RHHO_ind)
% 
    
dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 

dim_elem_inter = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 

dim_elem_face = size(HHO_face_ind,1); % Dimention for face basis on each individual face 


S = zeros(dim_elem_R-1,dim_elem_R-1); 

for i = 1:dim_elem_R-1
   
    %%symetric term
    
    for j=i:dim_elem_R-1
    
        % first term { \Delat(u)  \Delta(v)} is symetric
            
        
        grad1 = gradtensor_leg(Qpoints_elem,m,h,RHHO_ind(i+1,:));
        
        grad2 = gradtensor_leg(Qpoints_elem,m,h,RHHO_ind(j+1,:));
        
        t =  sum(grad1.*grad2,2);
        
        S(i,j) = dot(t,weights_elem);
        
    end
end

%%symetric term

S = S + (triu(S,1))';


%Condition_NO_local = condest(S)

%% the rectangular matrix V 



V1 = zeros(dim_elem_R-1,local_dim_elem); 

for i = 1:dim_elem_R-1
   
    
    for j=1:dim_elem_inter
    
        % element intergral stiffness
        
        grad1 = gradtensor_leg(Qpoints_elem,m,h,RHHO_ind(i+1,:));
        
        grad2 = gradtensor_leg(Qpoints_elem,m,h,HHO_elem_ind(j,:));
        
        t1 =  sum(grad1.*grad2,2);
        
        val1 =  dot(t1,weights_elem);
        
        % the trace term on each face
        
        val2 = 0;
        
        for k=1:NF
            
            % face k, 
            
            n_vec = out_normal_vectors(k,:);
           
             U2_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
            
             grad1_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+1,:));
             
             temp = U2_trace.*(grad1_trace(:,1).*n_vec(1)+grad1_trace(:,2).*n_vec(2));
             
            trace = dot(temp,weights_faces(:,k));
            
            val2 = val2+trace;
            
        end
                     
        
        V1(i,j) = val1-val2;
        
    end
end






V2 = zeros(dim_elem_R-1,local_dim_elem); 

for i = 1:dim_elem_R-1
   
    
    for j=dim_elem_inter+1:local_dim_elem
           
        
        % the trace term on each face
        
        val = 0;  
        
         % face k, use different face basis, quadratures
         
        k = floor((j-dim_elem_inter-0.5)./dim_elem_face)+1;
            
            local_edges_nodes =face_nodes(:,:,k);
                        
            n_vec = out_normal_vectors(k,:);
            
            j_face = j-dim_elem_inter-(k-1)*dim_elem_face;
           
            %% Othrognoal basis  for the face basis
            
             grad1_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+1,:));
            
             U2_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j_face,:));                  
             
             temp = U2_trace.*(grad1_trace(:,1).*n_vec(1)+grad1_trace(:,2).*n_vec(2));
             
            trace = dot(temp,weights_faces(:,k));
            
            val = val+trace;            
                     
        
        V2(i,j) = val;
        
    end
end

%% The RHS of the reconstrction operator is done

V = V1+V2;

%% The reconstruction operator is defined as R = S^{-1}*V

S_inv = inv(S);

R = S_inv*V;

A1 = V'*S_inv*V;


%%%%%%%%%%%%%%%%%%%%%%%%Stabilisation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% We start with computing the mass matrces and the difference matrices 
%% Lehrenfeld-schoberl stabilisation

%% Next is the face element matrix and face face matrix. The matrix depends on the number of faces.

% there is totally NF faces, stabilisation is done on each face

%% After computing the Difference matrix, we can compute the stabilisation term on each edge

% penalty parameter is from trace inverse inequality, we can use h_k

h_k = norm(BDbox(2,:)-BDbox(1,:));  % it should not be h_f

 
sigma = sigma/h_k; % from the stability estimates 


A_stab_Face = zeros(local_dim_elem,local_dim_elem,NF);


for k=1:NF
    
    
    local_edges_nodes =face_nodes(:,:,k);
    
    % compute the MFF matrix, this matrix is diagonal but not identity
    
M_FF = zeros(dim_elem_face,dim_elem_face);    
    

for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_face
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        V_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j,:)); 
        
        t =  sum(U_trace.*V_trace,2);
        
        M_FF(i,j) = dot(t,weights_faces(:,k));
        
    end
end

    
 M_FF_inv = inv(M_FF);   
    
    
 %% computing the matrix M_FT
 
 
 M_FT_all = zeros(dim_elem_face,dim_elem_inter);  
    
 
for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_inter
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        R_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
        
        t =  sum(U_trace.*R_trace,2);
        
         M_FT_all(i,j) = dot(t,weights_faces(:,k));
        
    end
end

% M_FT_p is the first p part

M_FT_p = M_FT_all(1:dim_elem_face,1:dim_elem_inter);


%Define the difference operator on each face

Proj_TF = M_FF_inv*M_FT_p; 

% D_TF is dim_elem_face * local_dim_elem

D_TF=  zeros(dim_elem_face,local_dim_elem);

D_TF(1:dim_elem_face,1:dim_elem_inter) = Proj_TF;



% Find the index of the face basis 

index_face_local = dim_elem_inter+((k-1)*dim_elem_face+1:k*dim_elem_face);



D_TF(:,index_face_local) = D_TF(:,index_face_local) - eye(dim_elem_face);


%% After computing the Difference matrix, we can compute the stabilisation term on each edge


% the stabilisation operator

T = D_TF;


A_stab_Face(:,:,k) = sigma.*T'*M_FF*T;

 
end

%% sum all each stabiulisation on each face 

A_stab = sum(A_stab_Face,3);

%% get the final local stiffness matrix 

local_stiff = A1+A_stab;

%% Put the local reconstruction operator 

local_reconstruction = zeros(size(R,1),assume_dim_elem);


local_reconstruction(:,1:size(R,2))= R;

end

