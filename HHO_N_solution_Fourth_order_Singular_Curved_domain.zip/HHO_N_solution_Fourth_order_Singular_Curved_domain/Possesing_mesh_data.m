%% possesing the mesh data for the cells   

clear;

load('9411 polygonal Elements.mat')

no_subtriangles_curve = 15; % How many tiny partitions of the edge nodes to approximate the curve

New_nodes = NaN(size(bdEdge,1).*(no_subtriangles_curve-1),2);


new_Elem = cell(NT,3);  P = NaN(NT,2);

totalEdge_set = cell(NT,1);  elemperedge = NaN(NT,1);

Tri_bdnorvec = bdnorvec;   Tri_bd_edge2elem = bd_edge2elem;

%% Adding new nodes

for t=1:size(bdEdge,1)
   
                
  local_face_index =  bdEdge(t,:);        
  
  face_nodes = get_face_nodes(local_face_index,Node);
  
   local_elem = bd_edge2elem(t); 
    
   
   tri_index =  elem_tri(local_elem ,: );
   
   %%%%%%%%%% We need find the correct direction%%%%%%%
   
   ind1 = find(tri_index-local_face_index(1)==0);
   
   ind2 = find(tri_index-local_face_index(2)==0);
   
   
   free_ind = 1:3;  free_ind([ind1,ind2])=[];
   
   new_tri_index = [local_face_index,  tri_index(free_ind)];
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
   
   BDbox = Elem{local_elem,2}; 
   
   
   P(local_elem,:) = sum(BDbox,1).*0.5;
   
   [subedge_nodes,BDbox,index_level_set] = generating_subedge(new_tri_index,BDbox,Node,no_subtriangles_curve);
            
   
   if sum(abs(subedge_nodes(1,:)-face_nodes(1,:)))<0.01
       
       subedge_nodes = subedge_nodes;
   else
       
       subedge_nodes = subedge_nodes(end:-1:1,:);
       
   end
   
   new_vertice = subedge_nodes(2:end-1,:);
   
   New_nodes((t-1)*(no_subtriangles_curve-1)+1:(t)*(no_subtriangles_curve-1),:) = new_vertice;
   
   
   tem_index =size(Node,1)+ [(t-1)*(no_subtriangles_curve-1)+1:(t)*(no_subtriangles_curve-1)]; 
      
   
       
    curved_elem_index = [local_face_index(1),tem_index , local_face_index(2), sum(tri_index)-sum(local_face_index)];
  
    
 
    new_Elem{local_elem,1}= curved_elem_index';  
    
     new_Elem{local_elem,2}= BDbox;
     
     totalEdge_set{local_elem} = [ [new_Elem{local_elem,1}, [new_Elem{local_elem,1}(2:end); new_Elem{local_elem,1}(1) ] ] ] ;                                                       
    
     elemperedge(local_elem) = size(new_Elem{local_elem,1},1);
end

% adding old index

int_index= 1:NT;  int_index(bd_edge2elem)=[];


for t = 1 :size(int_index,2)
    
    
    local_elem = int_index(t);
    
     new_Elem{local_elem,1}= elem_tri(local_elem,:)';  
    
     
     BDbox = Elem{local_elem,2};
     
     new_Elem{local_elem,2}= BDbox;
     
     P(local_elem,:) = sum(BDbox,1).*0.5;
     
     totalEdge_set{local_elem} = [[new_Elem{local_elem,1}, [new_Elem{local_elem,1}(2:end); new_Elem{local_elem,1}(1) ] ] ] ;                                                       
    
     elemperedge(local_elem) = size(new_Elem{local_elem,1},1);
end
    

elemtotaledge = cumsum(elemperedge);




totalEdge(1,:)=NaN(1,2);


for i = 1:NT
   
    
    totalEdge = [totalEdge; totalEdge_set{i}];
end


totalEdge(1,:)=[];



Elem = new_Elem;

Node = [Node; New_nodes];

if NT <= 300

figure;
hold on;
for i = 1:NT
 %% plot element
 
b = Node(Elem{i,1},:);
plot([b(:,1) ;b(1,1)],[b(:,2); b(1,2)],'k-','LineWidth',1)    
 %% bounding box 
 
a=[Elem{i,2}(1,:);[Elem{i,2}(1,1) Elem{i,2}(2,2)]  ;Elem{i,2}(2,:);  [Elem{i,2}(2,1) Elem{i,2}(1,2)] ] ;
plot([a(:,1) ;a(1,1)],[a(:,2); a(1,2)],'o-','LineWidth',1,'MarkerSize',5)

%BD_box = Elem{i,2};

%P = sum(BD_box,1).*0.5;

text(P(i,1),P(i,2), num2str(i));

end 


end



%% Classify all the edges

% totalEdge is all the edges from summation of each element
% edge is the all the edges from triagulation 
% bdEdge is the boundary edge and intEdge is the interior edge

totalEdge = sort(totalEdge, 2);

[i , j ,s ] = find(sparse(totalEdge(:,2),totalEdge(:,1),1));

edge = [j,i]; bdEdge = [j(s==1), i(s==1)]; intEdge = [j(s==2), i(s==2)];

%% The relation between edge to element and

% internal edge is shared by 2 elements and boundary edge is only used by 1
% edge

int_edge2elem = NaN(size(intEdge,1),2); bd_edge2elem = NaN(size(bdEdge,1),1);

parfor i = 1: size(intEdge,1)
   
    edge2elem = elem_share_edge(intEdge(i,:),totalEdge,elemtotaledge);
    
    int_edge2elem(i,:) =   edge2elem';
    
end

parfor i = 1: size(bdEdge,1)
   
    edge2elem = elem_share_edge(bdEdge(i,:),totalEdge,elemtotaledge);
    
    bd_edge2elem(i) =   edge2elem;
    
end


%% Plot for bdedge


% figure; hold on;
% 
% for i = 1 : size(bdEdge,1) 
%     
%    
%    
%   t=Node(bdEdge(i,:),:);
%    
%   plot(t(:,1), t(:,2),'o-','LineWidth',1,'MarkerSize',5)
%        
% end



%% Outward Normal vectors for all boundary edges

% For bdedge, only one normal vector
% For internal edge there two normnal vector, but we only use one.

% tangert vector of the edge%%%%%%
 bdtan_vec = Node(bdEdge(:,1),:) - Node(bdEdge(:,2),:);
 
inttan_vec = Node(intEdge(:,1),:) - Node(intEdge(:,2),:);
 
  % normal vector of the edge%%%%%%
 bdnorvec = [bdtan_vec(:,2)./sqrt(bdtan_vec(:,1).^2 +bdtan_vec(:,2).^2) , -bdtan_vec(:,1)./sqrt(bdtan_vec(:,1).^2 +bdtan_vec(:,2).^2)];

intnorvec = [inttan_vec(:,2)./sqrt(inttan_vec(:,1).^2 +inttan_vec(:,2).^2) , -inttan_vec(:,1)./sqrt(inttan_vec(:,1).^2 +inttan_vec(:,2).^2)];
 
% outward normal vector of the edge%%%%%%
% 
% %% find the correct interior nodes 
% 
% P_bd_bodes = NaN(size(bd_edge2elem,1),2);
% 
% parfor i=1 :size(bd_edge2elem,1)
% 
%      local_elem = bd_edge2elem(i); 
%     
%      inter_nodes_index =  new_Elem{local_elem,1}(end);
%      
%      P_bd_bodes(i,:) = Node(inter_nodes_index,:);
% end 
% 
% 
%   bdoutward = Node(bdEdge(:,1),:)-P_bd_bodes;
%   
  
% outward normal vector of the edge%%%%%%

P_tri_bd_vec = NaN(size(bd_edge2elem,1),2);


parfor i=1 :size(bd_edge2elem,1)

     local_elem = bd_edge2elem(i); 
    
     tri_bdface_index =  find(Tri_bd_edge2elem==local_elem);
     
     P_tri_bd_vec(i,:) = Tri_bdnorvec(tri_bdface_index,:);% Node(inter_nodes_index,:);
end 


  bdoutward =  P_tri_bd_vec;
  

%% find the correct interior nodes for inter eleme1 

P_int_bodes = NaN(size(int_edge2elem,1),2);

parfor i=1 :size(int_edge2elem,1)

     local_elem = int_edge2elem(i,1); 
    
     inter_nodes_index =  new_Elem{local_elem,1};
     
     local_nodes = Node(inter_nodes_index,:);
     
     P_int_bodes(i,:) = sum(local_nodes,1)./size(local_nodes,1);
end 

  
  intoutward = Node(intEdge(:,1),:)-P_int_bodes; % the first element
 
  
 
 bdindex =  max(sum(bdnorvec.*bdoutward,2),0);
 
 intindex =  max(sum(intnorvec.*intoutward,2),0);
 
 [i ,j ,s] = find(bdindex==0);   [m ,n ,k] = find(intindex==0);
 
 bdnorvec(i,:) = - bdnorvec(i,:);
  
 intnorvec(m,:) = - intnorvec(m,:);

 
%% find each element contains which edge
% the global index of edge is based as inter_edge, BD_edge
  
parfor i =1: NT
    
 index_int1 = find(int_edge2elem(:,1)==i);
 
 index_int2 = find(int_edge2elem(:,2)==i);
 
 index_bd =  find(bd_edge2elem(:)==i);
 
    
    Elem{i,3}= [index_int1; index_int2; index_bd+size(intEdge,1)];
       
end


Full_edge = [intEdge;bdEdge];





savefile = [ num2str(NT) ' curved Elements.mat'];
save(savefile, 'Elem','Node','NT','bdEdge','bd_edge2elem','intEdge','int_edge2elem','bdnorvec','intnorvec','Full_edge','-v7.3');

