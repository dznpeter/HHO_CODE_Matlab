function d2 = levelset2(x)

% d1>=0 means inside

r = sqrt(((x(:,1)-0.25).^2+(x(:,2)-0.25).^2));

d2 = (0.4^2- r.^2 );

end