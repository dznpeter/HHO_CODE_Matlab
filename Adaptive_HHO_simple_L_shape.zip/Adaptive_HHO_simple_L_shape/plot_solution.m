%%plot DG solution 

clear all;

Polydegree = 2;

Dimension =2; 

Basis_type = 'P';%Q

NT = 4096;

penalty = 10;

load([num2str(NT) ' polygonal Elements.mat']);

% true solution 
U_true = u_true(Node);




figure 

hold on;


for i=1:NT
   
    elem = Elem{i};
    
    node = Node(elem,:);
        
    z = u_true(node); 
    
    c = (z-min(U_true))./max(U_true);
    
    fill3(node(:,1),node(:,2),z,c)    
end

hold off ; view(3);




%%DG Solution 
load(['Error ' num2str(NT) ' polygonal Elements penalty ' num2str(penalty) ' P' num2str(Polydegree) ' basis.mat'])


Lege_ind = Basis_index_generator(Polydegree,Basis_type,Dimension);

dim_elem = size(Lege_ind,1); %number of basis for each element.


figure 

hold on

for t =1:NT
   
    [elem, BDbox] = Elem{t,:};   
    
    node = Node(elem,:);
   
  
            
    % calculating nodal values 
    coef = U((t-1)*dim_elem+1 : 1 :t*dim_elem ,1); % c is coefficeint
       
    % information about the bounding box

    h = (BDbox(2,:)-BDbox(1,:))./2;  

    m = 0.5.*sum(BDbox);

    P = zeros(size(node,1) ,dim_elem);  
    
    for i =1:dim_elem
        
        P(:,i)= tensor_leg(node,m,h,Lege_ind(i,:));                
                
    end
  
    u_DG_val = P*coef;   %DG solution;

    % plot 
    
    %c = (u_DG_val-min(U_true))./max(U_true);
    
    c = u_DG_val;
    
    fill3(node(:,1),node(:,2),u_DG_val,c) ; 
end



hold off;view(3);