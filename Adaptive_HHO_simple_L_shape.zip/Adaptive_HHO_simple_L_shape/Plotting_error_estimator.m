%clear all; close all;

figure;



Polynomial_degree = 0;   

%end_interval = [6,6,6,6];

end_interval = [28, 47, 75, 101, 119]; % without A_F in front of T_jump

%% different elements we use different order of basis

start_level = 1; Total_level = end_interval(Polynomial_degree+1);   



Marker = {'s','^','o','d','*','>'};


%estimator_type = 'nonconforming'; % nonconforming, conforming

 
err_P = NaN(Total_level,1);  err_eta_P = NaN(Total_level,1); 

dof_P = NaN(Total_level,1);


for i=1 :Total_level
    
    
       
      load(['Error Mesh level ' num2str(i) ' for HHO(P' num2str(Polynomial_degree) ') basis.mat'])
      
   %% minimum between two type estimator
   
       total_estimator = max([total_estimator_N, total_estimator_C],[],2);

   %% Nonconforming estimator   
   
      % total_estimator = total_estimator_N;
      
   %% Conforming estimator   
   
     %  total_estimator = total_estimator_C;    
   
      err_eta_P(i) = sqrt(sum(total_estimator.^2)); 
       
      
        err_P(i,1)= Energy_err;   
        
     



dof_P(i) = dim_linear_system;

       

end


%slope for poly


logerr_P1 = abs(log(err_P(:,1))); 

slope_P1 = abs((logerr_P1(2:end)-logerr_P1(1:end-1))./(log(dof_P(2:end))-log(dof_P(1:end-1))))

slope_Poly = mean(slope_P1(end-1));

%slope_Poly = max(slope_P1);


logest_P1 = abs(log(err_eta_P(:,1))); 

slope_P1_est = abs((logest_P1(3:2:end)-logest_P1(1:2:end-2))./(log(dof_P(3:2:end))-log(dof_P(1:2:end-2))));

slope_Poly_est = mean(slope_P1_est(end));

%slope_Poly_est = max(slope_P1_est);

Pind = start_level:Total_level;



        loglog(dof_P(Pind),err_P(Pind,1),'bs-.','LineWidth',2,'MarkerSize',10);
        
        hold on;
        
        loglog(dof_P(Pind),err_eta_P(Pind,1),'ks-','LineWidth',2,'MarkerSize',10);


        %% compute the slope based on the data 
        
        a = dof_P(Pind([1,end]));  kappa = (Polynomial_degree+1)/2;
        
        x1 = a(1); x2 = a(2); 
        
        y1 = sqrt(err_eta_P(Pind(1),1)*err_P(Pind(1),1));
        
        y2 = exp(kappa.*(log(x1)-log(x2))+log(y1));
        
        b = [y1,y2];
        
        loglog(a,3.*b, ['r--' num2str(Marker{Polynomial_degree+1})],'LineWidth',2,'MarkerSize',10);

       
        



   
%   switch estimator_type
%           
%     
%     case 'nonconforming'  % with nornal flux jump
%         
%        h = legend(['k' num2str(Polynomial_degree) ' error (NC)'],...
%        ['k' num2str(Polynomial_degree) ' estimator (NC)'],...
%        ['$\mathcal{O}({\rm DoFs}^{-\frac{' num2str(Polynomial_degree+1) '}{2}})$']);
% 
%         
%     case 'conforming'  % with nornal flux jump
%         
%        h = legend(['k' num2str(Polynomial_degree) ' error (C)'],...
%        ['k' num2str(Polynomial_degree) ' estimator (C)'],...
%        ['$\mathcal{O}({\rm DoFs}^{-\frac{' num2str(Polynomial_degree+1) '}{2}})$']);
% 
%         
%   end

    
   h = legend(['k' num2str(Polynomial_degree) ' error (Adaptive)'],...
       ['k' num2str(Polynomial_degree) ' estimator (Adaptive)'],...
       ['$\mathcal{O}({\rm DoFs}^{-\frac{' num2str(Polynomial_degree+1) '}{2}})$']);

   
   
set(h,'Interpreter','latex')   


xlabel('${\rm DoFs}$','FontSize',20,'Interpreter','latex');


%ylabel('$|u-R(u_h)|_{H^1{(\Omega)}}$','FontSize',20,'Interpreter','latex');
        
  
ylabel('$|||u-\hat{u_h}|||$','FontSize',20,'Interpreter','latex');
 


set(gca,'FontSize',30)
set(gca,'FontSize',30)
