%% Plotting the R-HHO_Solution solutions 

clear all;


%% load tht data from 9411 elements

Polynomial_order = [1];

Po=Polynomial_order+4;    

Mesh_type = 'curved';   %polygonal, rectangle, curved

Static_Condensation = 'on'; % on, off

Dimension =2;

epsilon = 10^(-4);






Number_Elements = 9411; 


 load([num2str(Number_Elements) ' ' num2str(Mesh_type) ' Elements.mat'])
 
 
 load(['Error ' num2str(Number_Elements) ' curved Elements P' num2str(Polynomial_order) ' basis epsilon ' num2str(epsilon) '.mat'])
 
Polydegree = Polynomial_order ;  % polynomial degree of DGFEM    

Po=Polydegree+4;         % quadrature order 

alpha = (Polydegree+1).*(Polydegree+Dimension);


Polydegree_elem = Polydegree+2; 

Polydegree_face = Polydegree+2; 

Polydegree_NF_face = Polydegree; 

R_Polydegree = Polydegree+2; 


dim_elem = nchoosek(Polydegree_elem+Dimension,Dimension);   

dim_face = nchoosek(Polydegree_face+Dimension-1,Dimension-1); 

dim_NF_face = nchoosek(Polydegree_NF_face+Dimension-1,Dimension-1); 

% the global index is Element index - Faceindex

dim_total_elem = dim_elem.*NT;

%NF = size(Full_edge);  % There is no boundary basis functions

NF_I = size(intEdge,1);  % There is no boundary basis functions

dim_total_face = dim_face.*NF_I;

dim_total_NF_face = dim_NF_face.*NF_I;

dim_FEM = dim_total_elem + dim_total_face + dim_total_NF_face;

RHHO_ind = Basis_index_generator2D(R_Polydegree,Dimension);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Hession_norm_vec = NaN(NT,1);

%figure 

%hold on
for t =1:NT
   
    
    [elem, BDbox, Face_index] = Elem{t,:};     elem_nodes =Node(elem,:);
    
    local_face_index = Full_edge(Face_index,:); 
           
    
    %% deal with the normal vector for the edges 
         
    [out_normal_vectors,~,int_BD_ind] = get_normal_vector(t,Face_index,intnorvec,bdnorvec,int_edge2elem);
       
     NO_intface = sum(int_BD_ind);  % int_BD_ind is the indicator for interior faces
                      
     local_dim_elem = dim_elem + NO_intface*dim_face+ NO_intface*dim_NF_face; 
                
    face_nodes = get_face_nodes(local_face_index,Node);
       
    Global_basis_index = findGlobalindex_int(t,Face_index,int_BD_ind,dim_elem,dim_face,dim_NF_face,dim_total_elem,dim_total_face);
   
    coef = U(Global_basis_index); % c is coefficeint
            
    %% Taking into account of the lifting 
    local_Reconstruction = Reconstruction(:,:,t)+Lifting(:,:,t);
   
     [~, ~,Hessian_u_R_HHO_nodal_value] = Plotting_solution(elem_nodes,BDbox, coef,local_Reconstruction, RHHO_ind,epsilon);

      
       norm_Hessian = sqrt(sum(Hessian_u_R_HHO_nodal_value.^2,2));  
       
%{       
%       fill3(elem_nodes(:,1),elem_nodes(:,2),norm_Hessian,norm_Hessian);      
%       
%       
%             
%}
       
      %Hessian_u_R_HHO_norm = Plotting_Hessian_norm(elem_nodes,BDbox,Po, coef,local_Reconstruction, RHHO_ind);
      
      %Hession_norm_vec(t) = Hessian_u_R_HHO_norm;
      
      
      Hession_norm_vec(t) = max(norm_Hessian); % Maximum value for Hessian on each cell
      
end


Max_value = 400;

%group_num = 10;  

%inter_value = Max_value/group_num; group_value = inter_value.*[1:group_num];

group_value = [4,8,12,16,20,24,28,32,36,40,80,120,160,200,300,400];

group_num =size(group_value,2);

Num_element_inter = NaN(group_num,1);


Cum_Num_element_inter = NaN(group_num,1);


for k = 1 :group_num

   ind = find(Hession_norm_vec<=group_value(k)); 
   
    
    Cum_Num_element_inter(k) = size(ind,1);
    
end


Num_element_inter(1) = Cum_Num_element_inter(1);

Num_element_inter(2:end) = Cum_Num_element_inter(2:end)-Cum_Num_element_inter(1:end-1);


percent_Num_element_9411 = Num_element_inter./NT;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%% load tht data from 9411 elements

Number_Elements = 2266; 


 load([num2str(Number_Elements) ' ' num2str(Mesh_type) ' Elements.mat'])
 
 
 load(['Error ' num2str(Number_Elements) ' curved Elements P' num2str(Polynomial_order) ' basis epsilon ' num2str(epsilon) '.mat'])
 
Polydegree = Polynomial_order ;  % polynomial degree of DGFEM    

Po=Polydegree+4;         % quadrature order 

alpha = (Polydegree+1).*(Polydegree+Dimension);


Polydegree_elem = Polydegree+2; 

Polydegree_face = Polydegree+2; 

Polydegree_NF_face = Polydegree; 

R_Polydegree = Polydegree+2; 


dim_elem = nchoosek(Polydegree_elem+Dimension,Dimension);   

dim_face = nchoosek(Polydegree_face+Dimension-1,Dimension-1); 

dim_NF_face = nchoosek(Polydegree_NF_face+Dimension-1,Dimension-1); 

% the global index is Element index - Faceindex

dim_total_elem = dim_elem.*NT;

%NF = size(Full_edge);  % There is no boundary basis functions

NF_I = size(intEdge,1);  % There is no boundary basis functions

dim_total_face = dim_face.*NF_I;

dim_total_NF_face = dim_NF_face.*NF_I;

dim_FEM = dim_total_elem + dim_total_face + dim_total_NF_face;

RHHO_ind = Basis_index_generator2D(R_Polydegree,Dimension);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Hession_norm_vec = NaN(NT,1);

%figure 

%hold on
for t =1:NT
   
    
    [elem, BDbox, Face_index] = Elem{t,:};     elem_nodes =Node(elem,:);
    
    local_face_index = Full_edge(Face_index,:); 
           
    
    %% deal with the normal vector for the edges 
         
    [out_normal_vectors,~,int_BD_ind] = get_normal_vector(t,Face_index,intnorvec,bdnorvec,int_edge2elem);
       
     NO_intface = sum(int_BD_ind);  % int_BD_ind is the indicator for interior faces
                      
     local_dim_elem = dim_elem + NO_intface*dim_face+ NO_intface*dim_NF_face; 
                
    face_nodes = get_face_nodes(local_face_index,Node);
       
    Global_basis_index = findGlobalindex_int(t,Face_index,int_BD_ind,dim_elem,dim_face,dim_NF_face,dim_total_elem,dim_total_face);
   
    coef = U(Global_basis_index); % c is coefficeint
            
    %% Taking into account of the lifting 
    local_Reconstruction = Reconstruction(:,:,t)+Lifting(:,:,t);
   
     [~, ~,Hessian_u_R_HHO_nodal_value] = Plotting_solution(elem_nodes,BDbox, coef,local_Reconstruction, RHHO_ind,epsilon);

      
       norm_Hessian = sqrt(sum(Hessian_u_R_HHO_nodal_value.^2,2));  
       
%{       
%       fill3(elem_nodes(:,1),elem_nodes(:,2),norm_Hessian,norm_Hessian);      
%       
%       
%      Hessian_u_R_HHO_norm = Plotting_Hessian_norm(elem_nodes,BDbox,Po, coef,local_Reconstruction, RHHO_ind);
%             
     
      
      %Hession_norm_vec(t) = Hessian_u_R_HHO_norm;
%}      
      
      Hession_norm_vec(t) = max(norm_Hessian); % Maximum value for Hessian on each cell
      
end



%group_num = 10;  

%inter_value = Max_value/group_num;  group_value = inter_value.*[1:group_num];

group_value = [4,8,12,16,20,24,28,32,36,40,80,120,160,200,300,400];

group_num =size(group_value,2);

Num_element_inter = NaN(group_num,1);


Cum_Num_element_inter = NaN(group_num,1);


for k = 1 :group_num

   ind = find(Hession_norm_vec<=group_value(k)); 
   
    
    Cum_Num_element_inter(k) = size(ind,1);
    
end


Num_element_inter(1) = Cum_Num_element_inter(1);

Num_element_inter(2:end) = Cum_Num_element_inter(2:end)-Cum_Num_element_inter(1:end-1);


percent_Num_element_2266 = Num_element_inter./NT;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







vals = [percent_Num_element_2266'; percent_Num_element_9411'];


X = categorical({'0 to 4','4 to 8','8 to 12','12 to 16','16 to 20','20 to 24','24 to 28','28 to 32','32 to 36','36 to 40','40 to 80','80 to 120','120 to 160','160 to 200','200 to 300','300 to 400'});


X = reordercats(X,{'0 to 4','4 to 8','8 to 12','12 to 16','16 to 20','20 to 24','24 to 28','28 to 32','32 to 36','36 to 40','40 to 80','80 to 120','120 to 160','160 to 200','200 to 300','300 to 400'});

b = bar(X,vals);


   legend('The percentage of $|\nabla^2 R_K(\hat{u}_K)|_{L_\infty(K)}$ for 2266 elements',...
       'The percentage of $|\nabla^2 R_K(\hat{u}_K)|_{L_\infty(K)}$ for 9441 elements',...
       'Location','NorthEast','Interpreter','latex')


  

   set(gca,'FontSize',20);set(gca,'FontSize',20);set(gca,'FontSize',20);
   
   
   
% hold off;view(2);axis off;
% 
