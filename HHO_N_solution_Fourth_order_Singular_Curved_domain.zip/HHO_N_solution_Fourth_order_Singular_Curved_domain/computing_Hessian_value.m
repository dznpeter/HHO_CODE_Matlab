%% Plotting the R-HHO_Solution solutions 

clear all;
%% load tht data from 9411 elements
epsilon = 10^(-3);

Number_Elements = 29496; 

Polynomial_order = [1];

Po=Polynomial_order+4;    

Theta = 0.2; %% The percentage 

Mesh_type = 'curved';   %polygonal, rectangle, curved

Dimension =2;








 load([num2str(Number_Elements) ' ' num2str(Mesh_type) ' Elements.mat'])
 
 
 load(['Error ' num2str(Number_Elements) ' curved Elements P' num2str(Polynomial_order) ' basis epsilon ' num2str(epsilon) '.mat'])
 
Polydegree = Polynomial_order ;  % polynomial degree of DGFEM    

Po=Polydegree+4;         % quadrature order 

alpha = (Polydegree+1).*(Polydegree+Dimension);


Polydegree_elem = Polydegree+2; 

Polydegree_face = Polydegree+2; 

Polydegree_NF_face = Polydegree; 

R_Polydegree = Polydegree+2; 


dim_elem = nchoosek(Polydegree_elem+Dimension,Dimension);   

dim_face = nchoosek(Polydegree_face+Dimension-1,Dimension-1); 

dim_NF_face = nchoosek(Polydegree_NF_face+Dimension-1,Dimension-1); 

% the global index is Element index - Faceindex

dim_total_elem = dim_elem.*NT;

%NF = size(Full_edge);  % There is no boundary basis functions

NF_I = size(intEdge,1);  % There is no boundary basis functions

dim_total_face = dim_face.*NF_I;

dim_total_NF_face = dim_NF_face.*NF_I;

dim_FEM = dim_total_elem + dim_total_face + dim_total_NF_face;

RHHO_ind = Basis_index_generator2D(R_Polydegree,Dimension);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Hession_norm_vec = NaN(NT,1);

%figure 

%hold on
parfor t =1:NT
   
    
    [elem, BDbox, Face_index] = Elem{t,:};     elem_nodes =Node(elem,:);
    
    local_face_index = Full_edge(Face_index,:); 
           
    
    %% deal with the normal vector for the edges 
         
    [out_normal_vectors,~,int_BD_ind] = get_normal_vector(t,Face_index,intnorvec,bdnorvec,int_edge2elem);
       
     NO_intface = sum(int_BD_ind);  % int_BD_ind is the indicator for interior faces
                      
     local_dim_elem = dim_elem + NO_intface*dim_face+ NO_intface*dim_NF_face; 
                
    face_nodes = get_face_nodes(local_face_index,Node);
       
    Global_basis_index = findGlobalindex_int(t,Face_index,int_BD_ind,dim_elem,dim_face,dim_NF_face,dim_total_elem,dim_total_face);
   
    coef = U(Global_basis_index); % c is coefficeint
            
    %% Taking into account of the lifting 
    local_Reconstruction = Reconstruction(:,:,t)+Lifting(:,:,t);
   
     [~, ~,Hessian_u_R_HHO_nodal_value] = Plotting_solution(elem_nodes,BDbox, coef,local_Reconstruction, RHHO_ind,epsilon);

      
       norm_Hessian = mean((max(abs(Hessian_u_R_HHO_nodal_value)'))');  
       
%{       
%       fill3(elem_nodes(:,1),elem_nodes(:,2),norm_Hessian,norm_Hessian);      
%       
%       
%             
%}
       
      %Hessian_u_R_HHO_norm = Plotting_Hessian_norm(elem_nodes,BDbox,Po, coef,local_Reconstruction, RHHO_ind);
      
      %Hession_norm_vec(t) = Hessian_u_R_HHO_norm;
      
      
      Hession_norm_vec(t) = mean(norm_Hessian); % Maximum value for Hessian on each cell
      
end

[new_Hession_norm_vec,index_area ]= sort(Hession_norm_vec);

Max_value = new_Hession_norm_vec(NT)


% find the cells whose norm is higher than Theta of the maximum value

index_max_norm = find(Hession_norm_vec>=Theta.*Max_value);


No_cell_Theta = size(index_max_norm,1)

No_cell_area = No_cell_Theta;
%% compute the area of the cells 


marked_index = index_area(NT+1-No_cell_area:NT);

area = 0;

for i = 1 :size(marked_index,1)

    t = marked_index(i);
    
    
    [elem, ~, ~] = Elem{t,:};     elem_nodes =Node(elem,:);
    
    
    [~,weights_elem]=quad_poly_special(elem_nodes,Po); % get the quadrature points on polygon

    
    
    area = area +sum(weights_elem);

end


area


node_edges =  Node(Full_edge(:,1),:)-Node(Full_edge(:,2),:); 

node_d = sum(node_edges.^2,2);

max_h = max(sqrt(node_d))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
