function  [local_stiff,local_reconstruction, local_R_time, local_S_time] = localstiff(elem_nodes,face_nodes,BDbox,alpha,beta, out_normal_vectors,wrap_N,local_dim_elem,Po,HHO_elem_ind,HHO_face_ind, HHO_NF_face_ind,RHHO_ind,assume_dim_elem)


NF = size(face_nodes,3);

% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);

[Qpoints_elem,weights_elem]=quad_poly(elem_nodes,Po); % get the quadrature points on polygon

%% find the quadtrature points on each edge

[Qpoints_faces,weights_faces] = quad_all_faces(face_nodes,Po);

%%%%%%%%%%%%%%%%%%%%%%%%Local reconstruction%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 
tic;
initime = cputime;
% 
% 
% fintime = cputime;
% elapsed = toc;
% 
% 
% 
    
dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 

dim_elem_cell = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 

dim_elem_face = size(HHO_face_ind,1); % Dimention for face basis on each individual face 

dim_elem_NF_face = size(HHO_NF_face_ind,1); % Dimention for face basis of normal flux variables on each individual face 

%% Remove the linear polynomials 

S = zeros(dim_elem_R-3,dim_elem_R-3); 

for i = 1:dim_elem_R-3
   
    %%symetric term
    
    for j=i:dim_elem_R-3
    
        % first term { \Delat(u)  \Delta(v)} is symetric
            
        
        Hessian1 = Hessian_leg(Qpoints_elem,m,h,RHHO_ind(i+3,:));
        
        Hessian2 = Hessian_leg(Qpoints_elem,m,h,RHHO_ind(j+3,:));
        
        t =  sum(Hessian1.*Hessian2,2);
        
        S(i,j) = dot(t,weights_elem);
        
    end
end

%%symetric term

S = S + (triu(S,1))';


%Condition_NO_local = condest(S)

%% the rectangular matrix V1 contains the information of v_K on cell and face
% The index for i and j is the other way around compare to the previous 

V1 = zeros(dim_elem_R-3,local_dim_elem); 


% method 1
% 
% for i = 1:dim_elem_R-3
%    
%     
%     for j=1:dim_elem_cell
%     
%         % element intergral stiffness
%         
%         Hessian1 = Hessian_leg(Qpoints_elem,m,h,RHHO_ind(i+3,:));
%         
%         Hessian2 = Hessian_leg(Qpoints_elem,m,h,HHO_elem_ind(j,:));
%         
%         t1 =  sum(Hessian1.*Hessian2,2);
%         
%         val1 =  dot(t1,weights_elem);
%         
%         % the trace term on each face
%         
%         val2 = 0;
%         
%         for k=1:NF
%             
%             % face k, 
%             
%             local_edges_nodes = face_nodes(:,:,k);
%             
%             n_vec = out_normal_vectors(k,:);
%             
%             temp_vec = (local_edges_nodes(2,:)-local_edges_nodes(1,:));                       
%              
%             t_vec = temp_vec./norm(temp_vec);
%            
%             VK_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
%             
%             grad_VK_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
%              
%             %grad1_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+3,:));
%             
%             Hessian_W_trace = Hessian_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+3,:));
%                         
%             gradLaplacian_W_trace = gradLaplacian_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+3,:));
%                                     
%             
%             NGradLaplacian_W = (gradLaplacian_W_trace(:,1).*n_vec(1)+gradLaplacian_W_trace(:,2).*n_vec(2));
%             
%             NFL_VK_trace = (grad_VK_trace(:,1).*n_vec(1)+grad_VK_trace(:,2).*n_vec(2));
%             
%             TFL_VK_trace = (grad_VK_trace(:,1).*t_vec(1)+grad_VK_trace(:,2).*t_vec(2));
%                        
%             Partial_NN_W =  n_vec(1).*n_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*n_vec(2).*Hessian_W_trace(:,2)...
%                             +n_vec(2).*n_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*n_vec(2).*Hessian_W_trace(:,4);
%                         
%             Partial_NT_W =  n_vec(1).*t_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*t_vec(2).*Hessian_W_trace(:,2)...
%                             +n_vec(2).*t_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*t_vec(2).*Hessian_W_trace(:,4);
%           
%                         
%                         
%             % (v_K, \partial_n \Delta w_K)
%             
%             temp1 = VK_trace.*NGradLaplacian_W;                        
%             
%             % (\partial_n v_K, \partial_{nn} w_K) +  (\partial_t v_K, \partial_{nt} w_K)
%                           
%             temp2 = NFL_VK_trace.* Partial_NN_W;
%             
%             temp3 = TFL_VK_trace.* Partial_NT_W;
%             
%             
%             Temp = temp1  -  temp2 - temp3;
%             
%             trace = dot(Temp,weights_faces(:,k));
%            
%             
%             
%             val2 = val2+trace;
%             
%         end
%                      
%         
%         V1(i,j) = val1+val2;
%         
%     end
% end


%% Method two 


for i = 1:dim_elem_R-3
   
    
    for j = 1:dim_elem_cell
    
        % element intergral stiffness
                        
        
        Biharmonic_W = biLaplacian_leg(Qpoints_elem,m,h,RHHO_ind(i+3,:));
        
        VK = tensor_leg(Qpoints_elem,m,h,HHO_elem_ind(j,:));
        
        
        t1 =  sum(VK.*Biharmonic_W,2);
        
        val1 =  dot(t1,weights_elem);          
        
        V1(i,j) = val1;
        
    end
end




%%  Assembling for the trace variable v_{\parital K}


V2 = zeros(dim_elem_R-3,local_dim_elem); 


for i = 1:dim_elem_R-3
   
    
    for j= dim_elem_cell+1:dim_elem_cell+NF*dim_elem_face
           
        
        % the trace term on each face
        
        val = 0; 
        
         % face k, use different face basis, quadratures
         
        k = floor((j-dim_elem_cell-0.5)./dim_elem_face)+1;
            
             
            local_edges_nodes = face_nodes(:,:,k);
            
            n_vec = out_normal_vectors(k,:);
            
            temp_vec = (local_edges_nodes(2,:)-local_edges_nodes(1,:));                       
             
            t_vec = temp_vec./norm(temp_vec);
            
            
            j_face = j-dim_elem_cell-(k-1)*dim_elem_face;
           
            %% Othrognoal basis  for the face basis
                         
             V_PK_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j_face,:));  
             
             Tangential_V_PK_trace = Tangent_Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j_face,:));                            
             
             %grad1_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+3,:));            
             
             Hessian_W_trace = Hessian_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+3,:));
                        
             gradLaplacian_W_trace = gradLaplacian_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+3,:));
                   
             
             
            NGradLaplacian_W = (gradLaplacian_W_trace(:,1).*n_vec(1)+gradLaplacian_W_trace(:,2).*n_vec(2));
            
           % NFL_VK_trace = (grad_VK_trace(:,1).*n_vec(1)+grad_VK_trace(:,2).*n_vec(2));
            
           % TFL_VK_trace = (grad_VK_trace(:,1).*t_vec(1)+grad_VK_trace(:,2).*t_vec(2));
                       
           % Partial_NN_W =  n_vec(1).*n_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*n_vec(2).*Hessian_W_trace(:,2)...
           %                 +n_vec(2).*n_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*n_vec(2).*Hessian_W_trace(:,4);
                        
            Partial_NT_W =  n_vec(1).*t_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*t_vec(2).*Hessian_W_trace(:,2)...
                            +n_vec(2).*t_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*t_vec(2).*Hessian_W_trace(:,4);
          
                        
                        
             
           % (v_{\partial K}, \partial_n \Delta w_K)
            
            temp1 = V_PK_trace.*NGradLaplacian_W;
            
           %  (\patial_t v_{\partial K}, \partial_{nt} w_K)
            
            temp3 = Tangential_V_PK_trace.* Partial_NT_W;
            
            
            Temp = -temp1 + temp3;
            
            trace = dot(Temp ,weights_faces(:,k));
            
            val = val+trace;            
                     
        
        V2(i,j) = val;
        
    end
end



%%  Assembling for the normal flux trace variable v_{N \parital K}


V3 = zeros(dim_elem_R-3,local_dim_elem); 


for i = 1:dim_elem_R-3
   
    
    for j= dim_elem_cell+NF*dim_elem_face+1:local_dim_elem
           
        
        % the trace term on each face
        
        val = 0;  
        
         % face k, use different face basis, quadratures
         
        k = floor((j-dim_elem_cell-NF*dim_elem_face-0.5)./dim_elem_NF_face)+1;
            
            local_edges_nodes =face_nodes(:,:,k);
                        
            n_vec = out_normal_vectors(k,:);  local_wrap = wrap_N(k);
            
            indicator = (-1)^local_wrap; % To see if the normal vector is take in a correct way
            
            j_face = j-dim_elem_cell-NF*dim_elem_face-(k-1)*dim_elem_NF_face;
           
            %% Othrognoal basis  for the face basis
                         
                         
             V_NF_PK_trace =  Normal_Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(j_face,:));  
                           
             %grad1_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+3,:));            
             
             Hessian_W_trace = Hessian_leg(Qpoints_faces(:,:,k),m,h,RHHO_ind(i+3,:));
                                           
             
             
           % NGradLaplacian = (gradLaplacian_W_trace(:,1).*n_vec(1)+gradLaplacian_W_trace(:,2).*n_vec(2));
            
           % NFL_VK_trace = (grad_VK_trace(:,1).*n_vec(1)+grad_VK_trace(:,2).*n_vec(2));
            
           % TFL_VK_trace = (grad_VK_trace(:,1).*t_vec(1)+grad_VK_trace(:,2).*t_vec(2));
                       
            Partial_NN_W =  n_vec(1).*n_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*n_vec(2).*Hessian_W_trace(:,2)...
                            +n_vec(2).*n_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*n_vec(2).*Hessian_W_trace(:,4);
                        
           % Partial_NT_W =  n_vec(1).*t_vec(1).*Hessian_W_trace(:,1) + n_vec(1).*t_vec(2).*Hessian_W_trace(:,2)...
           %                 +n_vec(2).*t_vec(1).*Hessian_W_trace(:,3) + n_vec(2).*t_vec(2).*Hessian_W_trace(:,4);
          
                        
                                     
           %  (\patial_t v_{\partial K}, \partial_{nt} w_K)
            
            temp3 = indicator.*V_NF_PK_trace.* Partial_NN_W;
            
            
            Temp = temp3;
            
            trace = dot(Temp ,weights_faces(:,k));
            
            val = val+trace;            
                     
        
        V3(i,j) = val;
        
    end
end



%% The RHS of the reconstrction operator is done

V = V1+V2+V3;

%% The reconstruction operator is defined as R = S^{-1}*V

S_inv = inv(S);

R = S_inv*V;

A1 = V'*S_inv*V;




fintime = cputime;
elapsed = toc;


local_R_time = fintime - initime;




%%%%%%%%%%%%%%%%%%%%%%%%Stabilisation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% We start with computing the mass matrces and the difference matrices 
%% Lehrenfeld-schoberl stabilisation

%% Next is the face element matrix and face face matrix. The matrix depends on the number of faces.

% there is totally NF faces, stabilisation is done on each face

%% After computing the Difference matrix, we can compute the stabilisation term on each edge

% penalty parameter is from trace inverse inequality, we can use h_k

h_k = norm(BDbox(2,:)-BDbox(1,:));  % it should not be h_f

alpha = alpha/h_k; % from the stability estimates  

beta = beta/h_k^3; % from the stability estimates 


%% Computing the stabilisation for the face variable term
% the difficulty is to compute the H1 Proejctions


tic;
initime = cputime;



A_stab_Face = zeros(local_dim_elem,local_dim_elem,NF);


for k=1:NF
    
    
    local_edges_nodes = face_nodes(:,:,k);
    
    % compute the MFF matrix, this matrix is diagonal but not identity
    
M_FF = zeros(dim_elem_face,dim_elem_face);    

% compute the H1 projection, first compute the Mass marix

for i = 1:dim_elem_face
   
    %%symetric term      
    
    
    for j=1:dim_elem_face
        
        
    
        % first term uv is symetric                
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        V_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(j,:)); 
        
        t =  sum(U_trace.*V_trace,2);
        
        M_FF(i,j) = dot(t,weights_faces(:,k)); %  for the trace variables
                        
    end                       
                    
end


H_FF = M_FF; 


    %% Change the Mass matrix to H1 by modifying the last two lines  
            
      
       for j = 1:dim_elem_face
                           
        
        H_FF([dim_elem_face-1,dim_elem_face],j) =  Face_basis_Nodal_value(local_edges_nodes,HHO_face_ind(j,:));
        
       end
    
   

 H_FF_inv = inv(H_FF);   
 
 M_FF_inv = inv(M_FF);     
    
 %% computing the matrix M_FT
 
 
 M_FT_all = zeros(dim_elem_face,dim_elem_cell);  
    
 
for i = 1:dim_elem_face
   
    %%symetric term
    
    for j=1:dim_elem_cell
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_face_ind(i,:)); 
        
        R_trace = tensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
        
        t =  sum(U_trace.*R_trace,2);
        
         M_FT_all(i,j) = dot(t,weights_faces(:,k));
        
    end
end

% M_FT_p is the first p part

M_FT_p = M_FT_all(1:dim_elem_face,1:dim_elem_cell);

H_FT_p = M_FT_p ;


 %% Change the Mass matrix to H1 by modifying the last two lines  
            
       for j = 1:dim_elem_cell
                           
        
        H_FT_p([dim_elem_face-1,dim_elem_face],j) =  tensor_leg(local_edges_nodes,m,h,HHO_elem_ind(j,:));
        
       end
    


%Define the difference operator on each face

H1_Proj_TF = H_FF_inv*H_FT_p; 

%Proj_TF = M_FF_inv*M_FT_p; 

% D_TF is dim_elem_face * local_dim_elem

D_TF=  zeros(dim_elem_face,local_dim_elem);

D_TF(1:dim_elem_face,1:dim_elem_cell) = H1_Proj_TF;

%D_TF(1:dim_elem_face,1:dim_elem_cell) = Proj_TF;


% Find the index of the face basis 

index_face_local = dim_elem_cell+((k-1)*dim_elem_face+1:k*dim_elem_face);



D_TF(:,index_face_local) = - eye(dim_elem_face);


%% After computing the Difference matrix, we can compute the stabilisation term on each edge


% the stabilisation operator

T = D_TF;



A_stab_Face(:,:,k) = beta.*T'*M_FF*T;

 
end

% sum all each stabiulisation on each face 

A_stab = sum(A_stab_Face,3);









%% Computing the stabilisation for the normal flux face variable term

A_NF_stab_Face = zeros(local_dim_elem,local_dim_elem,NF);



for k=1:NF
    
    
    local_edges_nodes =face_nodes(:,:,k);
    
    % compute the MFF matrix, this matrix is diagonal but not identity
    
M_FF_NF = zeros(dim_elem_NF_face,dim_elem_NF_face);    
    




for i = 1:dim_elem_NF_face
   
    %%symetric term
    
    for j=1:dim_elem_NF_face
    
        % first term uv is symetric
                    
        U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(i,:)); 
        
        V_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(j,:)); 
        
        t =  sum(U_trace.*V_trace,2);
        
        M_FF_NF(i,j) = dot(t,weights_faces(:,k)); %  for the trace variables
        
    end
end

    
 M_FF_NF_inv = inv(M_FF_NF);   
    
    
 %% computing the matrix M_FT
 
 
M_FT_NF = zeros(dim_elem_NF_face,dim_elem_cell);  
    

n_vec = out_normal_vectors(k,:); local_wrap = wrap_N(k);

 indicator = (-1)^local_wrap; % To see if the normal vector is take in a correct way
           
 
for i = 1:dim_elem_NF_face
   
    %%symetric term
    
    for j=1:dim_elem_cell
    
        % first term uv is symetric
                    
        U_trace =  Normal_Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(i,:)); 
        
        %U_trace = Face_baisis(Qpoints_faces(:,:,k),local_edges_nodes,Po,HHO_NF_face_ind(i,:));         
        
        grad_R_trace = gradtensor_leg(Qpoints_faces(:,:,k),m,h,HHO_elem_ind(j,:));
        
        NF_R_trace = n_vec(1).*grad_R_trace(:,1)+ n_vec(2).*grad_R_trace(:,2);
        
        t =  indicator.*U_trace.*NF_R_trace;
        
        M_FT_NF(i,j) = dot(t,weights_faces(:,k));
        
    end
end



%Define the difference operator on each face

Proj_TF_NF =  M_FF_NF_inv*M_FT_NF; 

% D_TF is dim_elem_face * local_dim_elem

D_TF_NF=  zeros(dim_elem_NF_face,local_dim_elem);

D_TF_NF(1:dim_elem_NF_face,1:dim_elem_cell) = Proj_TF_NF;



% Find the index of the face basis for normal flux 

index_NF_face_local = dim_elem_cell+NF*dim_elem_face+((k-1)*dim_elem_NF_face+1:k*dim_elem_NF_face);

%% if the different direction of the normal flux variables are given, we need to be carefull

    
D_TF_NF(:,index_NF_face_local) = - eye(dim_elem_NF_face);

%% After computing the Difference matrix, we can compute the stabilisation term on each edge


% the stabilisation operator

T_NF = D_TF_NF;


A_NF_stab_Face(:,:,k) = alpha.*T_NF'*M_FF_NF*T_NF;

 
end

%% sum all each stabiulisation on each face 

A_NF_stab = sum(A_NF_stab_Face,3);





%% get the final local stiffness matrix 

local_stiff = A1+A_stab+ A_NF_stab;




fintime = cputime;
elapsed = toc;


local_S_time = fintime - initime;






%% Put the local reconstruction operator 

local_reconstruction = zeros(size(R,1),assume_dim_elem);


local_reconstruction(:,1:size(R,2))= R;

end

