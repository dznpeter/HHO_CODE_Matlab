function DGPart_3 = Err_BDface(node,vertice,BDbox, coef,n ,Po ,Lege_ind, alpha, beta , g_D ,g_N)


h =  (BDbox(2,:)-BDbox(1,:))./2 ;

m = 0.5.*sum(BDbox);

dim_elem =size(Lege_ind,1); % number of basis for each element.


DGPart_3=0;

% generating quadrature points and weights


%[weights,ref_Qpoints] = Golub_Welsch(ceil(Po/2));

[weights,ref_Qpoints] = quad_GL(ceil((Po+1)*0.5));

%change the quadrature nodes from reference domain to physical domain.

mid= sum(node)./2;   tanvec = 0.5* (node(2,:)-node(1,:));

C = kron(mid,ones(size(ref_Qpoints,1),1));

P_Qpoints = kron(ref_Qpoints,tanvec) + C;  De = norm((node(2,:)-node(1,:))).*0.5;

% penalty term

%a_center = a(mid);

%lamda = eigs(reshape(a_center,2,2),1);


%temp = [n(1).^2,n(1).*n(2),n(1).*n(2),n(2).^2 ];

%lamda = dot(a_center,temp);

%correct measure

measure_B = De*max(abs(sum((vertice-kron(node(1,:),ones(size(vertice,1),1))).*kron(n,ones(size(vertice,1),1)),2)));


alpha = alpha.*(2.*De/measure_B)^3; % \alpha = penalty * p^6/h^3;


beta = beta.*(2.*De/measure_B);   % \beta = penalty * p^2/h;  

 % data for quadrature, function value b and normal vector n_vec
    
      
u_val = g_D(P_Qpoints);    grad_u_val = g_N(P_Qpoints);

n_vec =kron(n,ones(size(ref_Qpoints,1),1));
 
    % construct the matrix for all the local basis function

    
   P = zeros(size(P_Qpoints,1) ,dim_elem);
   
   Px = zeros(size(P_Qpoints,1) ,dim_elem);
    
   Py = zeros(size(P_Qpoints,1) ,dim_elem);
  
    
    for i =1:dim_elem
        
        P(:,i)= tensor_leg(P_Qpoints,m,h,Lege_ind(i,:));
        
        t = gradtensor_leg(P_Qpoints,m,h,Lege_ind(i,:));
        
        Px(:,i) = t(:,1); Py(:,i) = t(:,2);
      
        
    end
  
    u_DG_val = P*coef;   %DG solution;
    
    grad_u_DG = [Px*coef , Py*coef];   %gradient of DG on Kappa1;
    
    
    
     
     % Part 3 DG norm error  
     % sigma*(u-u_DG)^2-2a(grad_u - grad_U_DG)\cdot n* (u-u_DG) 
     
    
     
     t1 = alpha.*(u_val-u_DG_val).^2;
     
     
     
     t2 = beta.* sum((n_vec.*(grad_u_DG-grad_u_val)).^2,2);
     
     t = t1+t2;

     DGPart_3= DGPart_3+ De.*dot(t,weights);

end