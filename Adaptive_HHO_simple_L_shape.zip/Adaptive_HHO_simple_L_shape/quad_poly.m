function [P_Qpoints,weights]=quad_poly(elem_nodes,Po)



elem =delaunay(elem_nodes);       NTri = size(elem,1);

for k = 1:NTri
       
[tri_P_Qpoints, tri_weights] = quad_tri(elem_nodes(elem(k,:),:),Po);

NO_points = size(tri_P_Qpoints,1);

if k==1

P_Qpoints = NaN(NTri*NO_points,size(tri_P_Qpoints,2));

weights = NaN(NTri*NO_points,size(tri_weights,2));

end

P_Qpoints((k-1)*NO_points+1:1: k*NO_points,:) = tri_P_Qpoints;

weights((k-1)*NO_points+1:1: k*NO_points,:) = tri_weights;

end
  