%% Plotting the R-HHO_Solution solutions 

clear all;

figure_type = 'grad_U'; %U, grad_U,Hessian_U

Number_Elements = 65; 

Polynomial_order = [1];

Mesh_type = 'curved';   %polygonal, rectangle, curved

Static_Condensation = 'on'; % on, off

Dimension =2;

epsilon = 0.001;


 load([num2str(Number_Elements) ' ' num2str(Mesh_type) ' Elements.mat'])
 
 
 load(['Error ' num2str(Number_Elements) ' curved Elements P' num2str(Polynomial_order) ' basis epsilon ' num2str(epsilon) '.mat'])
 
Polydegree = Polynomial_order ;  % polynomial degree of DGFEM    

Po=Polydegree+4;         % quadrature order 

alpha = (Polydegree+1).*(Polydegree+Dimension);


Polydegree_elem = Polydegree+2; 

Polydegree_face = Polydegree+2; 

Polydegree_NF_face = Polydegree; 

R_Polydegree = Polydegree+2; 


dim_elem = nchoosek(Polydegree_elem+Dimension,Dimension);   

dim_face = nchoosek(Polydegree_face+Dimension-1,Dimension-1); 

dim_NF_face = nchoosek(Polydegree_NF_face+Dimension-1,Dimension-1); 

% the global index is Element index - Faceindex

dim_total_elem = dim_elem.*NT;

%NF = size(Full_edge);  % There is no boundary basis functions

NF_I = size(intEdge,1);  % There is no boundary basis functions

dim_total_face = dim_face.*NF_I;

dim_total_NF_face = dim_NF_face.*NF_I;

dim_FEM = dim_total_elem + dim_total_face + dim_total_NF_face;

RHHO_ind = Basis_index_generator2D(R_Polydegree,Dimension);



figure 

hold on
for t =1:NT
   
    
    [elem, BDbox, Face_index] = Elem{t,:};     elem_nodes =Node(elem,:);
    
    local_face_index = Full_edge(Face_index,:); 
           
    
    %% deal with the normal vector for the edges 
         
    [out_normal_vectors,~,int_BD_ind] = get_normal_vector(t,Face_index,intnorvec,bdnorvec,int_edge2elem);
       
     NO_intface = sum(int_BD_ind);  % int_BD_ind is the indicator for interior faces
                      
     local_dim_elem = dim_elem + NO_intface*dim_face+ NO_intface*dim_NF_face; 
                
    face_nodes = get_face_nodes(local_face_index,Node);
       
    Global_basis_index = findGlobalindex_int(t,Face_index,int_BD_ind,dim_elem,dim_face,dim_NF_face,dim_total_elem,dim_total_face);
   
    coef = U(Global_basis_index); % c is coefficeint
            
    %% Taking into account of the lifting 
    local_Reconstruction = Reconstruction(:,:,t)+Lifting(:,:,t);
   
    [u_R_HHO_val , grad_u_R_HHO_val,Hessian_u_R_HHO] = Plotting_solution(elem_nodes,BDbox, coef,local_Reconstruction, RHHO_ind,epsilon);
    
    
    switch figure_type
    
        case 'U'

    fill3(elem_nodes(:,1),elem_nodes(:,2),u_R_HHO_val,u_R_HHO_val); 
    

 case 'grad_U'
    
    norm_grad = sqrt(sum(grad_u_R_HHO_val.^2,2));      
    fill3(elem_nodes(:,1),elem_nodes(:,2),norm_grad,norm_grad); 

    
 case 'Hessian_U'
     
       norm_Hessian = sqrt(sum(Hessian_u_R_HHO.^2,2));  
       fill3(elem_nodes(:,1),elem_nodes(:,2),norm_Hessian,norm_Hessian);
 
    end
    
%      norm_Hessian = sqrt(sum(Hessian_u_R_HHO.^2,2));  
%      fill3(elem_nodes(:,1),elem_nodes(:,2),norm_Hessian,norm_Hessian); 
% %      
end

colorbar;

hold off;view(2);axis off;

%view(3); set(gca,'FontSize',18);