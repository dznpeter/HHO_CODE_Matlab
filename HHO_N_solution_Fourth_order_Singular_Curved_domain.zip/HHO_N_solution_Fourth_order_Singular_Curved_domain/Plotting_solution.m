function [ u_R_HHO_val , grad_u_R_HHO_val,Hessian_u_R_HHO] = Plotting_solution(elem_nodes,BDbox, coef,local_Reconstruction, RHHO_ind,epsilon)

%% First compute the local Reconstruction R_HHO

ind = size(coef,1); % remove the rededuncy 

R_HHO_nc = local_Reconstruction(:,1:ind)*coef;




dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 

%dim_elem_cell = size(HHO_elem_ind,1); % Dimention for HHO basis on each element 

%dim_elem_face = size(HHO_face_ind,1); % Dimention for face basis on each individual face 




% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);


R_HHO_miss = coef(1);

%% R_HHO solution finally find.....

local_R_HHO =[R_HHO_miss ;R_HHO_nc];


%% computing the error


%Computing the error for the projection of the u and u_h

% the mass matrix on the element basis T and T between dim_elem_inter * dim_elem_R


         
    
    % construct the matrix for all the local basis function

   % elem_nodes = [elem_nodes ;Qpoints_elem];
    
    
      P = zeros(size(elem_nodes,1) ,dim_elem_R );
      
     Px = zeros(size(elem_nodes,1) ,dim_elem_R );
      
     Py = zeros(size(elem_nodes,1) ,dim_elem_R );
    
    Pxx = zeros(size(elem_nodes,1) ,dim_elem_R );
    
    Pxy = zeros(size(elem_nodes,1) ,dim_elem_R );
    
    Pyx = zeros(size(elem_nodes,1) ,dim_elem_R );
    
    Pyy = zeros(size(elem_nodes,1) ,dim_elem_R );
   
   
    
    
    for i =1:dim_elem_R 
        
        P(:,i)= tensor_leg(elem_nodes,m,h,RHHO_ind(i,:));
        
        s =  gradtensor_leg(elem_nodes,m,h,RHHO_ind(i,:));
        
        Px(:,i) = s(:,1); Py(:,i) = s(:,2);
        
        t =  Hessian_leg(elem_nodes,m,h,RHHO_ind(i,:));
        
        Pxx(:,i) = t(:,1); Pxy(:,i) = t(:,2); Pyx(:,i) = t(:,3); Pyy(:,i) = t(:,4); 
    end
  
      % Recovered HHO solution
  
    u_R_HHO_val = P*local_R_HHO;   % R_HHO solution;
    
    grad_u_R_HHO_val = [Px*local_R_HHO,Py*local_R_HHO];   % R_HHO solution;
    
    Hessian_u_R_HHO = [Pxx*local_R_HHO, Pyx*local_R_HHO, Pxy*local_R_HHO , Pyy*local_R_HHO];   % gradient of R_HHO
    
   
        
    
end


