%%%%%% The second order elliptic PDE %%%%%%%%%%%
%matlabpool open local;
%clear all;


Number_Elements = [9411]; 

Polynomial_order = [1];

Mesh_type = 'curved';   %polygonal, rectangle, curved

Static_Condensation = 'on'; % on, off

epsilon_vec = [10^(-1),10^(-2),10^(-3)];

for m=1:size(epsilon_vec,2)
    
    epsilon = epsilon_vec(m);

for NO_elem = 1: size(Number_Elements,2)
     
 load([num2str(Number_Elements(NO_elem)) ' ' num2str(Mesh_type) ' Elements.mat'])

 
  
%% for different order of Basis!

for  O_B = 1:size(Polynomial_order,2)
    
    
    
disp([num2str(Number_Elements(NO_elem)) ' element with polynomial basis order 1 epsilon ' num2str(epsilon)]);




%%Innitialize the information about the PDE%%%%%%%%%%%

%a = @(x)diffusive(x); % Diffusive function

% 
% 
 g_D = @(x)u_true(x); % the Dirichelet boundary condition 
 
 g_grad = @(x)grad_u_true(x); % the Dirichelet boundary condition (without normal vector)

f = @(x)forcing(x); % the forcing founction

 u = @(x)u_true(x); % the analytic solution 
 
 grad_u = @(x)grad_u_true(x); % the gradient of analytic solution
 
 Hessian_u = @(x)Hessian_u_true(x); % the gradient of analytic solution

Dimension = 2; % 2D space

% if basis has degree 1 the the quadrature order should be 3 


Polydegree = Polynomial_order(O_B) ;  % polynomial degree of DGFEM    

Po=Polydegree+4;         % quadrature order 

alpha = (Polydegree+1).*(Polydegree+Dimension);   % \alpha = penalty * p^2/h, h is inside the face...

%% Set up different boundary condition

%% New pair element basis order P_{p-1} and face basis P_p

Polydegree_elem = Polydegree+2; 

Polydegree_face = Polydegree+2; 

Polydegree_NF_face = Polydegree; 

R_Polydegree = Polydegree+2; 


dim_elem = nchoosek(Polydegree_elem+Dimension,Dimension);   

dim_face = nchoosek(Polydegree_face+Dimension-1,Dimension-1); 

dim_NF_face = nchoosek(Polydegree_NF_face+Dimension-1,Dimension-1); 

% the global index is Element index - Faceindex

dim_total_elem = dim_elem.*NT;

%NF = size(Full_edge);  % There is no boundary basis functions

NF_I = size(intEdge,1);  % There is no boundary basis functions

dim_total_face = dim_face.*NF_I;

dim_total_NF_face = dim_NF_face.*NF_I;

dim_FEM = dim_total_elem + dim_total_face + dim_total_NF_face;


%% Size of the global couple linear system is determined by the internal face unknowns

dim_linear_system = (dim_face+dim_NF_face)*size(intEdge,1);


%% polynomial index for the HHO solution in P_k+2 space on element

HHO_elem_ind = Basis_index_generator2D(Polydegree_elem,Dimension);


%% polynomial index for the HHO solution in P_p+1 space on face

HHO_face_ind = Basis_index_generator2D(Polydegree_face,Dimension-1);


%% polynomial index for the HHO solution in P_p space on face

HHO_NF_face_ind = Basis_index_generator2D(Polydegree_NF_face,Dimension-1);

%% polynomial order for the Reconstrcution HHO in P_(p+1) space on element

   
RHHO_ind = Basis_index_generator2D(R_Polydegree,Dimension);

  
   




%% Contruct the bilinear form with Global matrix..

%% Part 1

% We assume that each elemenet contains less than 10 edges

MaxNE =10;

assume_dim_elem = dim_elem + dim_face*MaxNE + dim_NF_face*MaxNE;

% contribution from element

i=zeros(assume_dim_elem.^2,NT ); j =zeros(assume_dim_elem.^2,NT); s =zeros(assume_dim_elem.^2,NT ); 

% store the matrix for the reconstruction operator 

Reconstruction = zeros(size(RHHO_ind,1)-1,assume_dim_elem,NT); % no constant

Lifting = zeros(size(RHHO_ind,1)-1,assume_dim_elem,NT); %  no constant

Reconstruction_time  = zeros(NT,1); 

%Reconstruction_time_new  = zeros(NT,1);

Stabilisation_time  = zeros(NT,1);


parfor t =1:NT
    
    
    [elem, BDbox, Face_index] = Elem{t,:}; 
    
    %% actual size of the local matrix = dim_elem+No_face*dim_face + No_face*dim_NF_face
       
    
    elem_nodes = Node(elem,:);   local_face_index = Full_edge(Face_index,:);             
            
    %% deal with the normal vector for the edges 
   
    [out_normal_vectors,wrap_N,int_BD_ind] = get_normal_vector(t,Face_index,intnorvec,bdnorvec,int_edge2elem);
    
     NO_intface = sum(int_BD_ind);  % int_BD_ind is the indicator for interior faces
                      
     local_dim_elem = dim_elem + NO_intface*dim_face+ NO_intface*dim_NF_face; 
     
    face_nodes = get_face_nodes(local_face_index,Node);
    
  [local_stiff,local_reconstruction,local_lifting, local_R_time, local_S_time]  = localstiff(elem_nodes,face_nodes,BDbox,alpha,out_normal_vectors,wrap_N, int_BD_ind,local_dim_elem,Po,HHO_elem_ind,HHO_face_ind, HHO_NF_face_ind,RHHO_ind,assume_dim_elem,epsilon);
   
   %% Store the local_reconstruction operator
     
   Reconstruction(:,:,t) = local_reconstruction;
   
  Lifting(:,:,t) = local_lifting;
   
  %% find the correct global index.  
    
   Global_basis_index = findGlobalindex_int(t,Face_index,int_BD_ind,dim_elem,dim_face,dim_NF_face,dim_total_elem,dim_total_face);
    
   % We need to put the small matrix into the big matrix 
          
   Ks = zeros(assume_dim_elem,assume_dim_elem);
   
   Ks(1:local_dim_elem,1:local_dim_elem) = local_stiff;
    
   % We need to put the small index vector into the big one
   
   v1 = zeros(assume_dim_elem,1);   v2 = zeros(assume_dim_elem,1);
   
   v1(1:local_dim_elem)=ones(local_dim_elem,1);
   
   v2(1:local_dim_elem)=Global_basis_index;
   
   
   i(:,t) = kron(v1,v2 )  ;
   
   j(:,t) = kron(v2 ,v1) ;   
   
   s(:,t) = Ks(:);
   
   Reconstruction_time(t) = local_R_time;
      
   Stabilisation_time(t) = local_S_time;
    
end

%% remove the zero index term 

i_index = i(:); j_index = j(:); s_index = s(:);

zero_index = find(i_index==0); % the zero index is due to assume no of faces

i_index(zero_index)=[]; j_index(zero_index)=[]; s_index(zero_index)=[];

B = sparse(i_index,j_index ,s_index ,dim_FEM,dim_FEM);

disp('Bilinear form Element is over');




Reconstruction_time = sum(Reconstruction_time);

Stabilisation_time = sum( Stabilisation_time);



%disp('The condition NO of Sparse matrix B is ');

%Condition_NO = condest(B)





%% The right handside of the matrix, the linear functional;   
    
%Part 1

% contribution from element

i =zeros(dim_elem,NT); j =ones(dim_elem,NT); s =zeros(dim_elem,NT); 

parfor t =1:NT
   
   
    [elem, BDbox] = Elem{t,:}; 
    
     elem_nodes = Node(elem,:);
   
    localvec = vect_forcing(elem_nodes,BDbox, Po, HHO_elem_ind, @(x)f(x));
  
    % local index onlly related to the element interior basis
    
    ind = (t-1)*dim_elem+1 : t*dim_elem;   ind = ind'; 
    
   i(:,t) = ind ;
   
   s(:,t) = localvec;
    
end

L1 = sparse(i(:),j(:) ,s(:) ,dim_FEM,1 );


disp('Linear form Part 1 Element is over');


%% Impose the Dirichelt boundary condition on each Boundary face using Nische!


i = zeros(assume_dim_elem,size(bdEdge,1) ); j = ones(assume_dim_elem,size(bdEdge,1) ); s = zeros(assume_dim_elem,size(bdEdge,1) );


parfor t =1:size(bdEdge,1)
            
  local_face_index =  bdEdge(t,:);  n_vec = bdnorvec(t,:);   
  
  face_nodes = get_face_nodes(local_face_index,Node);
  
   local_elem = bd_edge2elem(t); 
   
   %% we need some information about the number of interiroir faces on the element 
      
    [~,BDbox, Face_index] = Elem{local_elem,:};        
    
    [~,~,int_BD_ind] = get_normal_vector(local_elem,Face_index,intnorvec,bdnorvec,int_edge2elem);
    
     NO_intface = sum(int_BD_ind);  % int_BD_ind is the indicator for interior faces
  
     local_dim_elem = dim_elem + NO_intface*dim_face + NO_intface*dim_NF_face;
    
    local_Reconstruction = Reconstruction(:,:,local_elem);
    
  % find the correct index for nodal basis and pick up the correc basis for
  % computing the projection
         
   %% calculating the projection of boundary condtion
                 
   local_Diri_val = vect_BDface(face_nodes,BDbox, Po,local_Reconstruction, local_dim_elem,HHO_elem_ind, RHHO_ind, n_vec,alpha,@(x)g_D(x),@(x)g_grad(x),epsilon);
   
   % Assembling
   
    Global_basis_index = findGlobalindex_int(local_elem,Face_index,int_BD_ind,dim_elem,dim_face,dim_NF_face,dim_total_elem,dim_total_face);
           
   
    % We need to put the small index vector into the big one
   
   v1 = zeros(assume_dim_elem,1);   v2 = zeros(assume_dim_elem,1);
   
   v1(1:local_dim_elem)=local_Diri_val(:);
   
   v2(1:local_dim_elem)=Global_basis_index;
   
   
   i(:,t) = v2;
   
   s(:,t) = v1;
    
end

%% remove the zero index term 

i_index = i(:); j_index = j(:); s_index = s(:);

zero_index = find(i_index==0); % the zero index is due to assume no of faces

i_index(zero_index)=[]; j_index(zero_index)=[]; s_index(zero_index)=[];

L2 = sparse(i_index,j_index ,s_index ,dim_FEM,1);



L = L1+L2;



Condition_NO =NaN;

switch Static_Condensation

    case 'off'   
    

U = B\L;

disp('the condition NO of the stiffness matrix is')

Condition_NO = condest(B)


    case 'on'
       
Size_Modal =  dim_elem;       
        
[U,Static_condensation_time,Solving_time] = StaticCondensation_FEM(B,L,NT,Size_Modal);    


end






dim_R_HHO  = size(RHHO_ind,1)*NT;


savefile = ['Error ' num2str(NT) ' ' num2str(Mesh_type) ' Elements P' num2str(Polydegree) ' basis epsilon ' num2str(epsilon) '.mat'];


save(savefile,'U','Reconstruction','Lifting','Reconstruction_time','Stabilisation_time','Static_condensation_time','Solving_time','dim_linear_system','dim_FEM','dim_R_HHO','Polydegree','Condition_NO');



end

end

end

%matlabpool close;