         
function Global_basis_index = findGlobalindex(t,Face_index,dim_elem,dim_face,dim_total_elem)


%% for t_th element 

global_elem_index = ((t-1)*dim_elem+1  : t*dim_elem)';

%% for different faces

global_face_index = NaN(dim_face,size(Face_index,1));

for k=1:size(Face_index,1)
    
   global_face_index(:,k) = ((Face_index(k)-1)*dim_face+1 : Face_index(k)*dim_face)'; 
    
end

global_face_index = global_face_index(:)+dim_total_elem;


Global_basis_index =[global_elem_index;global_face_index];

end