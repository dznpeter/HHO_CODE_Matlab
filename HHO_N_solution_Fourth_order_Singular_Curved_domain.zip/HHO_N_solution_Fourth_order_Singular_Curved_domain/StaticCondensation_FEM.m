function  [U_S,Static_condensation_time,Solving_time] = StaticCondensation_FEM(A,F,NT,Size_Modal)


%[U_S, Static_condensation_time] = StaticCondensation_FEM(B(int_index,int_index),L(int_index),NT,Size_Modal);

%Static_condensation_time

Modal_index = 1:NT*Size_Modal;

Bd_index = NT*Size_Modal+1:size(A,1);

% subdivide the large matrix A into 4 blocks!

MB = A(Bd_index,Bd_index); MBI = A(Bd_index,Modal_index);

MI = A(Modal_index,Modal_index); MIB = A(Modal_index,Bd_index);

FB = F(Bd_index);  FI = F(Modal_index);

U_S =NaN(size(F));

clear A F;

%% inverse the MI matrix elementwise for each Block on diagonal


% 
% tic;
% initime = cputime;
% 
% 
% fintime = cputime;
% elapsed = toc;
% 
% 
% 




Static_condensation_time_part1  = zeros(NT,1); 



i =zeros(Size_Modal.^2,NT ); j =zeros(Size_Modal.^2,NT ); s =zeros(Size_Modal.^2,NT );


parfor t =1:NT
    
    
    tic;
    initime = cputime;
    
    
    ind = (t-1)*Size_Modal+1:1:t*Size_Modal;
    
    ind = ind';
    
    local_inv_block_diag = inv(MI(ind,ind));
    
%    condest(MI(ind,ind))
      
    i(:,t) = kron(ones(Size_Modal,1),ind )  ;
   
    j(:,t) = kron(ind , ones(Size_Modal,1)) ;
   
    s(:,t) = local_inv_block_diag(:);
    
    fintime = cputime;
    elapsed = toc;
    
    Static_condensation_time_part1(t) = fintime - initime;
    
end


 tic;
    initime = cputime;
    

inv_MI = sparse(i,j ,s ,size(MI,1),size(MI,1) );


% Calculating the boundary part
B = MB-MBI*inv_MI*MIB;

L = FB - MBI*inv_MI*FI;


fintime = cputime;
    elapsed = toc;

Static_condensation_time_part2 = fintime - initime;


Static_condensation_time = sum(Static_condensation_time_part1) +Static_condensation_time_part2;


% reordering


tic;
initime = cputime;


P = symrcm(B);

u =B(P,P)\L(P);

u(P) = u;

%spy(B(P,P));

U_S(Bd_index) =u;

% Calculating the interior part

U_S(Modal_index) = inv_MI*FI -inv_MI*MIB*U_S(Bd_index);


fintime = cputime;
    elapsed = toc;
    
    
    
Solving_time = fintime-initime;

end