function z = u_true(X)


if size(X,2)~= 2
    
   error('input should be 2 dimensional points')
    
end


x = X(:,1); y = X(:,2);


z = (sin(pi.*x).^2).*(sin(pi.*y).^2);


%z = (x.^2 - 1).^2.*(y.^2 - 1).^2+1;


%z = (sin(pi.*x).^2).*(sin(pi.*y).^2)+x.^4 + y.^4;


% z = (x.^2 - 1).*(y.^2 - 1);


%z = (x.^2-4).^2.* (y.^2-4).^2;


%z = x.^0;

%z = sin(pi.*x).^2.*sin(pi.*y).^2 + exp(- (x - 1/2).^2 - (y - 1/2).^2);


end