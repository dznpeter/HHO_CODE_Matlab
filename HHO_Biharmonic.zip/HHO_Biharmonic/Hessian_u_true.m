function z = Hessian_u_true(X)


if size(X,2)~= 2
    
   error('input should be 2 dimensional points')
    
end

x = X(:,1); y = X(:,2);

uxx= 2.*pi.^2.*cos(pi.*x).^2.*sin(pi.*y).^2 - 2.*pi.^2.*sin(pi.*x).^2.*sin(pi.*y).^2;

uxy= 4.*pi.^2.*cos(pi.*x).*cos(pi.*y).*sin(pi.*x).*sin(pi.*y);

uyx = uxy;

uyy = 2.*pi.^2.*cos(pi.*y).^2.*sin(pi.*x).^2 - 2.*pi.^2.*sin(pi.*x).^2.*sin(pi.*y).^2;



% 
% uxx = 4.*(x.^2 - 1).*(y.^2 - 1).^2 + 8.*x.^2.*(y.^2 - 1).^2;
% 
% uxy = 16.*x.*y.*(x.^2 - 1).*(y.^2 - 1);
% 
% uyx = uxy;
% 
% uyy = 4.*(x.^2 - 1).^2.*(y.^2 - 1) + 8.*y.^2.*(x.^2 - 1).^2;
% 


% 
% uxx = 12.*x.^2+ 2.*pi.^2.*cos(pi.*x).^2.*sin(pi.*y).^2 - 2.*pi.^2.*sin(pi.*x).^2.*sin(pi.*y).^2;
% 
% uxy = 0.*y.^3+4.*pi.^2.*cos(pi.*x).*cos(pi.*y).*sin(pi.*x).*sin(pi.*y);
% 
% uyx = uxy;
% 
% uyy = 12.*y.^2+2.*pi.^2.*cos(pi.*y).^2.*sin(pi.*x).^2 - 2.*pi.^2.*sin(pi.*x).^2.*sin(pi.*y).^2;


% 
% uxx = 2.*y.^2 - 2;
% 
% uxy = 4.*x.*y;
% 
% uyx = uxy;
% 
% uyy = 2.*x.^2 - 2;



% 
% uxx = 4.*(x.^2 - 4).*(y.^2 - 4).^2 + 8.*x.^2.*(y.^2 - 4).^2;
% 
% uxy = 16.*x.*y.*(x.^2 - 4).*(y.^2 - 4);
% 
% uyx = uxy;
% 
% uyy = 4.*(x.^2 - 4).^2.*(y.^2 - 4) + 8.*y.^2.*(x.^2 - 4).^2;




% 
% 
% uxx = x-x;
% 
% uxy = x-x;
% 
% uyx = uxy;
% 
% uyy = x-x;


% uxx = exp(- (x - 1/2).^2 - (y - 1/2).^2).*(2.*x - 1).^2 - 2.*exp(- (x - 1/2).^2 - (y - 1/2).^2) - 2.*pi.^2.*sin(pi.*x).^2.*sin(pi.*y).^2 + 2.*pi.^2.*cos(pi.*x).^2.*sin(pi.*y).^2;
% 
% uxy = exp(- (x - 1/2).^2 - (y - 1/2).^2).*(2.*x - 1).*(2.*y - 1) + 4.*pi.^2.*cos(pi.*x).*cos(pi.*y).*sin(pi.*x).*sin(pi.*y);
% 
% uyx = uxy;
% 
% uyy = exp(- (x - 1/2).^2 - (y - 1/2).^2).*(2.*y - 1).^2 - 2.*exp(- (x - 1/2).^2 - (y - 1/2).^2) - 2.*pi.^2.*sin(pi.*x).^2.*sin(pi.*y).^2 + 2.*pi.^2.*cos(pi.*y).^2.*sin(pi.*x).^2;


z = [uxx, uxy, uyx, uyy];


end