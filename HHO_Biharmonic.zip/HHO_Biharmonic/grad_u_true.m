function z = grad_u_true(X)


if size(X,2)~= 2
    
   error('input should be 2 dimensional points')
    
end


x = X(:,1); y = X(:,2);

 z = [ 2.*pi.*cos(pi.*x).*sin(pi.*x).*sin(pi.*y).^2, 2.*pi.*cos(pi.*y).*sin(pi.*x).^2.*sin(pi.*y)];


%z=[4.*x.*(x.^2 - 1).*(y.^2 - 1).^2, 4.*y.*(x.^2 - 1).^2.*(y.^2 - 1)];




 %z = [ 2.*pi.*cos(pi.*x).*sin(pi.*x).*sin(pi.*y).^2+ 4.*x.^3, 2.*pi.*cos(pi.*y).*sin(pi.*x).^2.*sin(pi.*y)+4.*y.^3];


%z = [2.*x.*(y.^2 - 1), 2.*y.*(x.^2 - 1)];


%z=[4.*x.*(x.^2 - 4).*(y.^2 - 4).^2,4.*y.*(x.^2 - 4).^2.*(y.^2 - 4)];


%z= [x-x,x-x];


%z = [2.*pi.*cos(pi.*x).*sin(pi.*x).*sin(pi.*y).^2 - exp(- (x - 1/2).^2 - (y - 1/2).^2).*(2.*x - 1), 2.*pi.*cos(pi.*y).*sin(pi.*x).^2.*sin(pi.*y) - exp(- (x - 1/2).^2 - (y - 1/2).^2).*(2.*y - 1)];

end