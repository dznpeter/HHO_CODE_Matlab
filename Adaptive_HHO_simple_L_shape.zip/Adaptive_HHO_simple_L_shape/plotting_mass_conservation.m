%clear all; close all;

figure

%% different elements we use different order of basis

Total_level = 50;   start_level = 1;

Polynomial_degree = 0;   
 

err_P = NaN(Total_level,1);  err_eta_P = NaN(Total_level,1); 

dof_P = NaN(Total_level,1);


for i=1 :Total_level
    
    
            
      load(['Error Mesh level ' num2str(i) ' for HHO(P' num2str(Polynomial_degree) ') basis.mat'])
        

        err_P(i,1)= total_mass_conservation;   
                
     
dof_P(i) = dim_FEM;

       

end

Pind = start_level:Total_level;



%figure;

plot(dof_P(Pind),err_P(Pind),'k-o','LineWidth',2,'MarkerSize',10);
        
        

      

%legend(['HCT3 error slope ' num2str(slope_Poly)],['HCT3 estimator slope ' num2str(slope_Poly_est)])

h= legend(['HHO(P' num2str(Polynomial_degree) ') $\eta$']); set(h,'Interpreter','latex')   



xlabel('${\rm DoFs}$','FontSize',20,'Interpreter','latex');


ylabel('Mass conservation','FontSize',20,'Interpreter','latex');
        
       


set(gca,'FontSize',20)

