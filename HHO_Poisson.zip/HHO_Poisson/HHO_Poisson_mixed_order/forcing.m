function z= forcing(x)


if size(x,2)~= 2
    
   error('input should be 2 dimensional points')
    
end

% Diffussion part



 % case1
 
 
  z = 2.*pi.^2.*sin(pi.*x(:,1)).*sin(pi.*x(:,2));



% % % case 2
% % 


%z = +2.*x(:,2).*(1-x(:,2))+2.*x(:,1).*(1-x(:,1));
end