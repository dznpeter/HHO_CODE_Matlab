function [total_estimator_C,element_interface_estimator1,element_interface_interface1,total_estimator_N,element_interface_estimator2,element_interface_interface2,Elem,elem_tri,Node,bdEdge,bd_edge2elem,intEdge,int_edge2elem,intnorvec,bdnorvec]...
                = HHO_Elliptic_Solver(Elem,elem_tri,Node,bdEdge,bd_edge2elem,bdnorvec,intEdge,int_edge2elem,intnorvec,Full_edge,Level,Polynomial_order,maximum_No_edge_elem,Static_Condensation)
                                      

NT = size(Elem,1);  

No_of_elements = NT;  

%%Innitialize the information about the PDE%%%%%%%%%%%

a = @(x)diffusive(x); % Diffusive function

g_D = @(x)u_true(x); % the Dirichelet boundary condition 

f = @(x)forcing(x); % the forcing founction

u = @(x)u_true(x); % the analytic solution 

grad_u = @(x)grad_u_true(x); % the gradient of analytic solution

Dimension = 2; % 2D space

% if basis has degree 1 the the quadrature order should be 3 

Polydegree = Polynomial_order;  % polynomial degree of DGFEM    

Po = Polydegree+4;         % quadrature order 
 
sigma = 1*(Polydegree+1).*(Polydegree+Dimension);   % \beta = penalty * p^2/h, h is inside the face...



%%%%%%%%%%%

disp(['Mesh level ' num2str(Level) ' with ' num2str(No_of_elements) ' elements with HHO(P' num2str(Polynomial_order) ') basis'])



%% Set up different boundary condition

%DiribdEdge=bdEdge;   Diribd_edge2elem=bd_edge2elem;  Diribdnorvec = bdnorvec;

%% New pair element basis order P_{p-1} and face basis P_p

Polydegree_elem = Polydegree+1; 

Polydegree_face = Polydegree; 

R_Polydegree = Polydegree+1; 


dim_elem = nchoosek(Polydegree_elem+Dimension,Dimension);   

dim_face = nchoosek(Polydegree_face+Dimension-1,Dimension-1); 

% the global index is Element index - Faceindex

dim_total_elem = dim_elem.*NT;

NF = size(Full_edge,1);

dim_total_face = dim_face.*NF;

dim_FEM = dim_total_elem + dim_total_face;


%% polynomial index for the HHO solution in P_p space on element

HHO_elem_ind = Basis_index_generator2D(Polydegree_elem,Dimension);


%% polynomial index for the HHO solution in P_p space on face

HHO_face_ind = Basis_index_generator2D(Polydegree_face,Dimension-1);



%% polynomial order for the Reconstrcution HHO in P_(p+1) space on element

   
RHHO_ind = Basis_index_generator2D(R_Polydegree,Dimension);


%% Contruct the bilinear form with Global matrix..

%% Part 1

% We assume that each elemenet contains less than MaxNE edges

MaxNE = maximum_No_edge_elem;

assume_dim_elem = dim_elem + dim_face*MaxNE;

% contribution from element

i=zeros(assume_dim_elem.^2,NT ); j =zeros(assume_dim_elem.^2,NT); s =zeros(assume_dim_elem.^2,NT ); 

% store the matrix for the reconstruction operator

Reconstruction = zeros(size(RHHO_ind,1)-1,assume_dim_elem,NT); % contains the NaN



parfor t =1:NT
    
    
    [tri_ind, BDbox, Face_index] = Elem{t,:}; 
    
    submesh = generating_submesh(elem_tri(tri_ind,:),Node);
    
    NO_face = size(Face_index,1);
    
    %% actual size of the local matrix = dim_elem+No_face*dim_face
    
    local_dim_elem = dim_elem + NO_face*dim_face;
    
   % elem_nodes = Node(elem,:);   

   %% Adaptive needs the information on background meshes

    local_face_index = Full_edge(Face_index,:); 
    
    face_nodes = get_face_nodes(local_face_index,Node);
    
    %% deal with the normal vector for the edges 
    
    out_normal_vectors = get_normal_vector(t,Face_index,intnorvec,bdnorvec,int_edge2elem);
       
   [local_stiff,local_reconstruction] = localstiff(submesh,face_nodes,BDbox,sigma, out_normal_vectors,local_dim_elem,Po,HHO_elem_ind,HHO_face_ind,RHHO_ind,assume_dim_elem,@(x)a(x));
   
   %% Store the local_reconstruction operator
     
   Reconstruction(:,:,t) = local_reconstruction;
   
  %% find the correct global index.  
    
   Global_basis_index = findGlobalindex(t,Face_index,dim_elem,dim_face,dim_total_elem);
    
   % We need to put the small matrix into the big matrix 
          
   Ks = zeros(assume_dim_elem,assume_dim_elem);
   
   Ks(1:local_dim_elem,1:local_dim_elem) = local_stiff;
    
   % We need to put the small index vector into the big one
   
   v1 = zeros(assume_dim_elem,1);   v2 = zeros(assume_dim_elem,1);
   
   v1(1:local_dim_elem)=ones(local_dim_elem,1);
   
   v2(1:local_dim_elem)=Global_basis_index;
   
   
   i(:,t) = kron(v1,v2 )  ;
   
   j(:,t) = kron(v2 ,v1) ;   
   
   s(:,t) = Ks(:);
    
end



%% remove the zero index term 

i_index = i(:); j_index = j(:); s_index = s(:);

zero_index = find(i_index==0); % the zero index is due to assume no of faces

i_index(zero_index)=[]; j_index(zero_index)=[]; s_index(zero_index)=[];

B = sparse(i_index,j_index ,s_index ,dim_FEM,dim_FEM );

disp('Bilinear form Element is over');




%disp('The condition NO of Sparse matrix B is ');

%Condition_NO = condest(B)



%% The right handside of the matrix, the linear functional;   
    
%Part 1

% contribution from element

i =zeros(dim_elem,NT); j =ones(dim_elem,NT); s =zeros(dim_elem,NT); 

parfor t =1:NT
   
   
   [tri_ind, BDbox, Face_index] = Elem{t,:}; 
    
    submesh = generating_submesh(elem_tri(tri_ind,:),Node);
    
   
    localvec = vect_forcing(submesh,BDbox,  Po, HHO_elem_ind, @(x)f(x));
  
    % local index onlly related to the element interior basis
    
    ind = (t-1)*dim_elem+1 : t*dim_elem;   ind = ind'; 
    
   i(:,t) = ind ;
   
   s(:,t) = localvec;
    
end

L = sparse(i(:),j(:) ,s(:) , dim_FEM, 1 );


disp('Linear form Part 1 Element is over');




%% The coefficient of global basis is U

% Initialization of U 

U = zeros(size(L));

%% Impose the Dirichelt boundary condition on each Boundary face


i = zeros(dim_face,size(bdEdge,1) );  s = zeros(dim_face,size(bdEdge,1) );


parfor t =1:size(bdEdge,1)
            
  local_face_index =  bdEdge(t,:); 
  
  face_nodes = get_face_nodes(local_face_index,Node);
    

  local_face_index = (t-1)*dim_face+1:t*dim_face; 
  
  gloable_face_index = dim_total_elem+dim_face.*size(intEdge,1)+local_face_index;
  
  % find the correct index for nodal basis and pick up the correc basis for
  % computing the projection
         
   %% calculating the projection of boundary condtion
      
   Diri_val = DiriBC_projecton(face_nodes, Po  , HHO_face_ind ,dim_face,@(x)g_D(x));
   
   % Assembling
   
    
   i(:,t) = gloable_face_index';
   
   s(:,t) = Diri_val;
    
end

bdbasis_index = i(:);

U(bdbasis_index) = s(:); % Boundary condition on the boundary face basis

int_index = (1:dim_FEM)';

int_index(bdbasis_index)=[];

%Update the boundary data

L = L - B*U;



Condition_NO =NaN;


switch Static_Condensation

    case 'off'   
    

U(int_index) = B(int_index,int_index)\L(int_index);

dim_linear_system = size(int_index,1);

disp('the condition NO of the stiffness matrix is')

Condition_NO = condest(B(int_index,int_index))


    case 'on'
       
Size_Modal =  dim_elem;       
        
[U(int_index),Condition_NO] = StaticCondensation_FEM(B(int_index,int_index),L(int_index),NT,Size_Modal);        

dim_linear_system = (Polydegree_face+1).*size(intEdge,1);

end




%% Test error in L_2 norm and DG norm 


%Part 1

%Error from element  (L_2 norm)

R_L2_err_vec = NaN(NT,1);  R_H1_err_vec = NaN(NT,1); 

L2_err_vec = NaN(NT,1);  H1_err_vec = NaN(NT,1); 

Stabilisation_err_vec = NaN(NT,1);

%% compute the missing basis for Reconstruction  

 
R_HHO = zeros(size(RHHO_ind,1),NT);




parfor t =1:NT
   
    
    [tri_ind, BDbox, Face_index] = Elem{t,:}; 
    
    submesh = generating_submesh(elem_tri(tri_ind,:),Node);
    
    local_face_index = Full_edge(Face_index,:); 
    
    face_nodes = get_face_nodes(local_face_index,Node);
    
    %% deal with the normal vector for the edges 
    
    Global_basis_index = findGlobalindex(t,Face_index,dim_elem,dim_face,dim_total_elem);
    
    coef = U(Global_basis_index ); % c is coefficeint
        
    
    local_Reconstruction = Reconstruction(:,:,t);
   
    [R_L2_part, R_H1_part,L2_part, H1_part,local_R_HHO ] =Err_elem(submesh ,BDbox, coef,local_Reconstruction, Po ,HHO_elem_ind,RHHO_ind, @(x)u(x) ,@(x)grad_u(x),@(x)a(x));
    
    R_L2_err_vec(t) = R_L2_part;    R_H1_err_vec(t) = R_H1_part;
    
    L2_err_vec(t) = L2_part;    H1_err_vec(t) = H1_part;
  
    
    R_HHO(:,t) = local_R_HHO;
    
    
    [S_error ] = Err_stabilisation(face_nodes,BDbox, coef,Po ,sigma,HHO_elem_ind,HHO_face_ind,@(x)a(x));
    
    Stabilisation_err_vec(t) = S_error;
end



R_L2_err = sqrt(sum(R_L2_err_vec)) ; R_H1_err = sqrt(sum(R_H1_err_vec)) ;


L2_err = sqrt(sum(L2_err_vec)) ; H1_err = sqrt(sum(H1_err_vec)) ;

Stabilisation_err = sqrt(sum(Stabilisation_err_vec)) ;

Energy_err = sqrt(Stabilisation_err^2 + H1_err^2);



%%%%% Compute the estimator %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



elem_err_est = NaN(NT,1); 

parfor t =1:NT
   
    
  [tri_ind, BDbox, ~] = Elem{t,:}; 
    
    submesh = generating_submesh(elem_tri(tri_ind,:),Node);
              
    
    local_R_HHO_coe = R_HHO(:,t) ;
    
     % Find mesh size is approximated by bounding box           
    
    h_k = norm(BDbox(2,:)-BDbox(1,:),inf);             
    
    local_Reconstruction = Reconstruction(:,:,t);
   
    elem_residual = Estimator_elem(submesh,BDbox, local_R_HHO_coe,h_k,Polydegree, Po ,RHHO_ind, @(x)f(x),@(x)a(x));
    
   elem_err_est(t) =  elem_residual;  
   
end

sum_elem_residual = sqrt(sum(elem_err_est));



%Error from interior edge, jump of normal/tangential flux  (L_2 norm)

int_eta_edge_conforming = NaN(size(intEdge,1),1); 

int_eta_edge_nonconforming = NaN(size(intEdge,1),1);

int_edge_equilbrated_flux = NaN(size(intEdge,1),1);

parfor t =1:size(intEdge,1)
    
    elem_oneface = int_edge2elem(t,:);
    
    local_R_HHO_coef1 = R_HHO(:,elem_oneface(1)) ;
    
    local_R_HHO_coef2 = R_HHO(:,elem_oneface(2)) ;
    
    Face_index1 = Elem{elem_oneface(1),3};
            
    Global_basis_index1 = findGlobalindex(elem_oneface(1),Face_index1,dim_elem,dim_face,dim_total_elem);
    
    coef1 = U(Global_basis_index1 ); % c is coefficeint
  
    local_edge_index1 = find(Face_index1==t);
    
    Face_index2 = Elem{elem_oneface(2),3};
            
    Global_basis_index2 = findGlobalindex(elem_oneface(2),Face_index2,dim_elem,dim_face,dim_total_elem);
    
    coef2 = U(Global_basis_index2 ); % c is coefficeint
  
    local_edge_index2 = find(Face_index2==t);
    
    BDbox1 = Elem{elem_oneface(1),2};  BDbox2 = Elem{elem_oneface(2),2};
        
    tri1 = elem_tri(Elem{elem_oneface(1),1},:); tri2 = elem_tri(Elem{elem_oneface(2),1},:);
    
    vertice = [Node([tri1(:);tri2(:)],:)];
    
    face_nodes = Node(intEdge(t,:),:); n_F = intnorvec(t,:);
    
    [intEdge_residual_conforming,intEdge_residual_nonconforming,int_edge_flux_Mass] = Estimator_intEdge(face_nodes, vertice,BDbox1,BDbox2,local_R_HHO_coef1,local_R_HHO_coef2,coef1,coef2,local_edge_index1,local_edge_index2,sigma, n_F,Po ,RHHO_ind,HHO_elem_ind,HHO_face_ind,Polydegree,@(x)a(x));
    
    int_eta_edge_conforming(t) = intEdge_residual_conforming;
    
    int_eta_edge_nonconforming(t) = intEdge_residual_nonconforming;
    
    int_edge_equilbrated_flux(t) = int_edge_flux_Mass;
end


sum_normal_flux_residual = sqrt(sum(int_eta_edge_conforming - int_eta_edge_nonconforming));

sum_tangential_flux_residual_inter = sqrt(sum(int_eta_edge_nonconforming));


%Part 3 from the interface  on jump of normal/tangential flux  (L_2 norm)


bd_eta_edge = NaN(size(bdEdge,1),1); 

parfor t =1:size(bdEdge,1)
    
     elem_bdface =bd_edge2elem(t,:); 
     
    % local_R_HHO_coef = R_HHO(:, elem_bdface(1)) ;
     
    Face_index = Elem{elem_bdface(1),3};
            
    Global_basis_index = findGlobalindex(elem_bdface,Face_index,dim_elem,dim_face,dim_total_elem);
    
    coef = U(Global_basis_index ); % c is coefficeint
  
     
     BDbox = Elem{elem_bdface,2}; 
         
     tri = elem_tri(Elem{elem_bdface(1),1},:);
     
     vertice = Node(tri(:),:); 
    
     face_nodes = Node(bdEdge(t,:),:); n_F = bdnorvec(t,:);
     
     bdEdge_residual  = Estimator_bdEdge(face_nodes, vertice, BDbox,coef,n_F,Po ,HHO_elem_ind,@(x)grad_u(x),Polydegree, @(x)a(x));
                                            
     bd_eta_edge(t) =  bdEdge_residual;
end

sum_tangential_flux_residual_bd = sqrt(sum(bd_eta_edge));

%%%%%%%%

sum_tangential_flux_residual = sqrt(sum_tangential_flux_residual_inter^2+sum_tangential_flux_residual_bd^2);




%% Case Conforming Error estimator on each cell with normal flux jump

total_estimator_C = Assembling_error_est(elem_err_est,int_eta_edge_conforming,bd_eta_edge,int_edge2elem,bd_edge2elem);

[element_interface_estimator1,element_interface_interface1] = Assembilng_interfacewise_residual(int_eta_edge_conforming,elem_err_est,int_edge2elem);

total_estimator_C = sqrt(total_estimator_C.^2 + Stabilisation_err_vec);


%% Error estimator on each cell case 2 with normal flux jump

total_estimator_N = Assembling_error_est(elem_err_est,int_eta_edge_nonconforming,bd_eta_edge,int_edge2elem,bd_edge2elem);

[element_interface_estimator2,element_interface_interface2] = Assembilng_interfacewise_residual(int_eta_edge_nonconforming,elem_err_est,int_edge2elem);

total_estimator_N = sqrt(total_estimator_N.^2 + Stabilisation_err_vec.*(R_Polydegree+1));




disp('RHHO H1 error is');

R_H1_err

disp('HHO H1 error is');

H1_err

disp('HHO energy error is');

Energy_err


disp('HHO energy estimator conforming is');

total_eta_C = norm(total_estimator_C,2)


disp('HHO energy estimator nonconforming is');

total_eta_N = norm(total_estimator_N,2)



dim_R_HHO  = size(RHHO_ind,1)*NT;


%disp('global mass conservation');

total_mass_conservation = norm(int_edge_equilbrated_flux,2);

%total_mass_conservation



savefile = ['Error Mesh level ' num2str(Level) ' for HHO(P' num2str(Polynomial_order) ') basis.mat'];


save(savefile, 'Stabilisation_err','R_L2_err','R_H1_err','L2_err','H1_err','Energy_err','total_estimator_C','element_interface_estimator1','element_interface_interface1','total_estimator_N','element_interface_estimator2','element_interface_interface2','sum_normal_flux_residual', 'sum_tangential_flux_residual', 'sum_elem_residual','total_mass_conservation','dim_FEM','dim_R_HHO','dim_linear_system','Polydegree','dim_FEM','Polydegree','Condition_NO','-v7.3');



savefile = [ 'Mesh level ' num2str(Level) ' triangle Elements HHO(P' num2str(Polynomial_order) ').mat'];

save(savefile, 'Elem','Node','elem_tri','NT','bdEdge','bd_edge2elem','intEdge','int_edge2elem','bdnorvec','intnorvec','-v7.3');




end