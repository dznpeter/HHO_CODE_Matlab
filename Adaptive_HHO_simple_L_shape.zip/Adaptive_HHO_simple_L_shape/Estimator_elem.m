function [elem_residual,oscillation]= Estimator_elem(submesh,BDbox, local_R_HHO_coe, h_k,Polydegree ,Po,RHHO_ind,  f, a)

NT = size(submesh,3);


R_Polydegree = Polydegree+1;

dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 


% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);


[Qpoints_elem,weights_elem]=quad_poly_background(submesh,NT,Po); % get the quadrature points on polygon


%% computing the error

     
    % data for quadrature
    
     f_val = f(Qpoints_elem);    a_val_cell = a(Qpoints_elem);
         

% Computing the error for the projection of the u and R(u_h)
             
    % construct the matrix for all the local basis function

    
    P_Laplace = zeros(size(Qpoints_elem,1) ,dim_elem_R );
      
    
    
    for i =1:dim_elem_R 
        
        P_Laplace(:,i)= Laplacian_leg(Qpoints_elem,m,h,RHHO_ind(i,:));
               
    end
  
     
    % Recovered HHO solution
  
    Laplacian_u_R_HHO_val = P_Laplace*local_R_HHO_coe;   % Laplacian R_HHO solution;
    


M = zeros(dim_elem_R,dim_elem_R); 

F = zeros(dim_elem_R,1); 

for i = 1:dim_elem_R
   
    %%symetric term
    
    for j=i:dim_elem_R
    
        % first term { \Delat(u)  \Delta(v)} is symetric
            
        
        U = tensor_leg(Qpoints_elem,m,h,RHHO_ind(i,:));
        
        V = tensor_leg(Qpoints_elem,m,h,RHHO_ind(j,:));        
        
        M(i,j) = dot(U.*V,weights_elem);
        
    end
    
    F(i)= dot(f_val.*tensor_leg(Qpoints_elem,m,h,RHHO_ind(i,:)),weights_elem);
end
    
M_inv = inv(M);   
 
 Proj_F =  M_inv*F;
 
 
   P = zeros(size(Qpoints_elem,1) ,dim_elem_R );
      
    
    
    for i =1:dim_elem_R 
        
        P(:,i)= tensor_leg(Qpoints_elem,m,h,RHHO_ind(i,:));
               
    end  
    
 f_val_proj =  P*Proj_F;
    
      % L_2 norm error  int_\kappa (f + a_val \Delta R u_HHO)^2 dx
    
     t1 = (a_val_cell).^(-1).*(f_val_proj + a_val_cell.*Laplacian_u_R_HHO_val ).^2.*(h_k/R_Polydegree )^2;
        
     elem_residual = dot((t1),weights_elem);
     
     % oscillation 
     
     t2 = (a_val_cell).^(-1).*(f_val_proj - f_val).^2.*(h_k/R_Polydegree )^2;
     

oscillation = dot((t2),weights_elem);
     

end


