%%Initialize the Polymesh generator to construct the information about the
%%underlying FEM space and the geometry of the computational domain.

clear all; 

%% Generate the square domain [0,1]^2 with polygonal elements.

%[Node,Element,Supp,Load,P]= PolyMesher(@MbbDomain,4096*4,100);

%% Generating the square domain [0,1]^2 with ranctangel elements.

  dx =1/128; [X,Y] = meshgrid(0+dx/2:dx:1,0+dx/2:dx:1);
  
  P = [X(:) Y(:)];
  
  [Node,Element,Supp,Load,P]= PolyMesher(@MbbDomain,25,0,P);
 

%% Generate bounding box for each polygonal element

% move to the correct place.

n = 8;   Node = round(10^n.*Node)/10^n;

%  and  finding all the edges. Label element to edges 

N = size(Node,1); NT = size(Element,1); 

Elem = cell(NT,3);

totalEdge = NaN(1,2);  elemperedge = NaN(NT,1);

for i =1: NT
    
    % calculate all the bounding box
    
    Elem{i,1}= Element{i}';
   
    
    bdbox_x = sort(Node(Elem{i,1},1));
    
    bdbox_y = sort(Node(Elem{i,1},2));
    
    Elem{i,2} = [bdbox_x([1,end]) ,  bdbox_y([1,end])]; %bounding box is [x_min y_min
                                                       %                 x_max y_max]  
    
    totalEdge = [totalEdge; [Elem{i,1}, [Elem{i,1}(2:end); Elem{i,1}(1) ] ] ] ;                                                       
                    
    % label edges per element
    
    elemperedge(i) = size(Elem{i,1},1);
end

elemtotaledge = cumsum(elemperedge);

totalEdge(1,:)=[];

clear Element;


%% Classify all the edges

% totalEdge is all the edges from summation of each element
% edge is the all the edges from triagulation 
% bdEdge is the boundary edge and intEdge is the interior edge

totalEdge = sort(totalEdge, 2);

[i , j ,s ] = find(sparse(totalEdge(:,2),totalEdge(:,1),1));

edge = [j,i]; bdEdge = [j(s==1), i(s==1)]; intEdge = [j(s==2), i(s==2)];

%% The relation between edge to element and

% internal edge is shared by 2 elements and boundary edge is only used by 1
% edge

int_edge2elem = NaN(size(intEdge,1),2); bd_edge2elem = NaN(size(bdEdge,1),1);

parfor i = 1: size(intEdge,1)
   
    edge2elem = elem_share_edge(intEdge(i,:),totalEdge,elemtotaledge);
    
    int_edge2elem(i,:) =   edge2elem';
    
end

parfor i = 1: size(bdEdge,1)
   
    edge2elem = elem_share_edge(bdEdge(i,:),totalEdge,elemtotaledge);
    
    bd_edge2elem(i) =   edge2elem;
    
end


%% Plot for bdedge


% figure; hold on;
% 
% for i = 1 : size(bdEdge,1) 
%     
%    
%    
%   t=Node(bdEdge(i,:),:);
%    
%   plot(t(:,1), t(:,2),'o-','LineWidth',1,'MarkerSize',5)
%        
% end



%% Outward Normal vectors for all boundary edges

% For bdedge, only one normal vector
% For internal edge there two normnal vector, but we only use one.

% tangert vector of the edge%%%%%%

 bdtan_vec = Node(bdEdge(:,1),:) - Node(bdEdge(:,2),:);
 
inttan_vec = Node(intEdge(:,1),:) - Node(intEdge(:,2),:);
 
  % normal vector of the edge%%%%%%
 bdnorvec = [bdtan_vec(:,2)./sqrt(bdtan_vec(:,1).^2 +bdtan_vec(:,2).^2) , -bdtan_vec(:,1)./sqrt(bdtan_vec(:,1).^2 +bdtan_vec(:,2).^2)];

intnorvec = [inttan_vec(:,2)./sqrt(inttan_vec(:,1).^2 +inttan_vec(:,2).^2) , -inttan_vec(:,1)./sqrt(inttan_vec(:,1).^2 +inttan_vec(:,2).^2)];
 
% outward normal vector of the edge%%%%%%

  bdoutward = Node(bdEdge(:,1),:)-P(bd_edge2elem(:),:);
  
  intoutward = Node(intEdge(:,1),:)-P(int_edge2elem(:,1),:); % the first element
 
  
 
 bdindex =  max(sum(bdnorvec.*bdoutward,2),0);
 
 intindex =  max(sum(intnorvec.*intoutward,2),0);
 
 [i ,j ,s] = find(bdindex==0);   [m ,n ,k] = find(intindex==0);
 
 bdnorvec(i,:) = - bdnorvec(i,:);
  
 intnorvec(m,:) = - intnorvec(m,:);

 
%% find each element contains which edge
% the global index of edge is based as inter_edge, BD_edge
  
parfor i = 1: NT
    
 index_int1 = find(int_edge2elem(:,1)==i);
 
 index_int2 = find(int_edge2elem(:,2)==i);
 
 index_bd =  find(bd_edge2elem(:)==i);
 
    
    Elem{i,3}= [index_int1; index_int2; index_bd+size(intEdge,1)];
       
end


Full_edge = [intEdge;bdEdge];



%savefile = [ num2str(NT) ' polygonal Elements.mat'];

savefile = [ num2str(NT) ' rectangle Elements.mat'];
save(savefile, 'Elem','Node','N','NT','bdEdge','bd_edge2elem','intEdge','int_edge2elem','bdnorvec','intnorvec','Full_edge','-v7.3');

%%%%%%%%%%%%%%%%%% The intialization of Mesh is finished %%%%%%%%%%%%%%%%%%%%%

