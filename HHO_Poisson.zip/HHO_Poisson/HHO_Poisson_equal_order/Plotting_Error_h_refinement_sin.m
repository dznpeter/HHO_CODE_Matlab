%close all;
%% different elements we use different order of basis

NO_Elements = [16,64,256,1024,4096];


%color = {'b','r','g','k','y'};

Marker = {'s','p','^','o','*','>'};

L2=figure;

slope_Poly = NaN(1,5);

order= 2;  

Mesh_type = 'polygonal';  % rectangle, polygonal

Norm_type = 'R_H1';  %'R_L2', 'R_H1' , 'L2'  ,'Sta'

for k = 0:order


%% plotting errors for the L2 norm for p refinement

%%P basis


Polynomial_degree = k;   

NO_elem = NO_Elements;   

err_P = NaN(length(NO_elem),1); dof_P = NaN(length(NO_elem),1);


for i=1 :length(NO_elem)
       
load(['Error ' num2str(NO_elem(i)) ' ' Mesh_type ' Elements P'  num2str(Polynomial_degree) ' basis.mat'])

switch  Norm_type
    
    case 'R_L2' 

err_P(i,1)=R_L2_err;    

    case 'R_H1'
        
err_P(i,1)=R_H1_err; 


    case 'L2' 

err_P(i,1)=L2_err; 
 

 case 'Sta' 

err_P(i,1)=Stabilisation_err;
       
end

dof_P(i) = dim_FEM;
end

%slope for poly

logerr_P1 = abs(log(err_P(:,1))); 

slope_P1 = abs((logerr_P1(2:end)-logerr_P1(1:end-1))./(log(dof_P(2:end).^(1./2))-log(dof_P(1:end-1).^(1./2))));


%slope_Poly(k) = max(mean(slope_P1(end-1:end)), max(slope_P1));


slope_Poly(k+1) = mean(slope_P1(end-1));

%slope_Poly(k+1) = max(slope_P1);


switch Mesh_type 
    
    case 'rectangle'

loglog(dof_P.^(1./2),err_P(:,1),['r-' num2str(Marker{k+1})],'LineWidth',2,'MarkerSize',10);

    case 'polygonal'
        
loglog(dof_P.^(1./2),err_P(:,1),['k:' num2str(Marker{k+1})],'LineWidth',2,'MarkerSize',10);
        
end
hold on;

end


switch Mesh_type 
    
    case 'rectangle'

legend(['HHO rect P0 slope ' num2str(slope_Poly(1))]...
      ,['HHO rect P1 slope ' num2str(slope_Poly(2))]...
      ,['HHO rect P2 slope ' num2str(slope_Poly(3))]...
      ,['HHO rect P3 slope ' num2str(slope_Poly(4))]...
      ,['HHO rect P4 slope ' num2str(slope_Poly(5))]...
      ,'Location','SouthWest')
  
    case 'polygonal'
        
legend(['HHO poly P0 slope ' num2str(slope_Poly(1))]...
      ,['HHO poly P1 slope ' num2str(slope_Poly(2))]...
      ,['HHO poly P2 slope ' num2str(slope_Poly(3))]...
      ,['HHO poly P3 slope ' num2str(slope_Poly(4))]...
      ,['HHO poly P4 slope ' num2str(slope_Poly(5))]...
      ,'Location','SouthWest')       
end


xlabel('${\rm DoFs}^{\frac{1}{2}}$','FontSize',20,'Interpreter','latex');

switch  Norm_type
    
    case 'R_L2' 

ylabel('$\|u-R(u_h)\|_{L_2(\Omega)}$','FontSize',20,'Interpreter','latex');


    case 'R_H1'

ylabel('$\|\nabla_h (u-R(u_h))\|_{L_2(\Omega)}$','FontSize',20,'Interpreter','latex');

 
 case 'L2' 

ylabel('$\|u-u_h\|_{L_2(\Omega)}$','FontSize',20,'Interpreter','latex');


case 'Sta' 

ylabel('$S(\hat{u}_h,\hat{u}_h)$','FontSize',20,'Interpreter','latex');

       
end


set(gca,'FontSize',20)



