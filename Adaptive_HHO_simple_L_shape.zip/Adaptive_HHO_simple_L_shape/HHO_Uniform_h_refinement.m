%addpath(genpath('ifem'))


%% Parameters

maxN = 3e4;  minN = 1e2;  maxIt = 6; 

%estimator_type = 'nonconforming'; % nonconforming, conforming

Polynomial_order = 0; Static_Condensation = 'on'; % on, off 

% cell based coarsening or interface based coarsening

%%  Generate an initial mesh


[Node,elem_tri] =squaremesh([-1,1,-1,1],0.5);

[Node,elem_tri] = delmesh(Node,elem_tri,'x>0 & y<0');

                                                                                                                
%%  Adaptive Finite Element Method

% *SOLVE* -> *ESTIMATE* -> *MARK* -> *REFINE/Coarsening*


for k = 1:maxIt

    %% initialization processing Data

    [Elem,elem_tri,Node,NT,bdEdge,bd_edge2elem,intEdge,int_edge2elem,bdnorvec,intnorvec,Full_edge,maximum_No_edge_elem] = Processing_Mesh(Node,elem_tri);


%% Calculate

 [total_estimator_C,element_interface_estimator1,element_interface_interface1,total_estimator_N,element_interface_estimator2,element_interface_interface2,Elem,elem_tri,Node]...
            = HHO_Elliptic_Solver(Elem,elem_tri,Node,bdEdge,bd_edge2elem,bdnorvec,intEdge,int_edge2elem,intnorvec,Full_edge,k,Polynomial_order,maximum_No_edge_elem,Static_Condensation);


total_estimator = min([total_estimator_N, total_estimator_C],[],2);

       
    
    % Step 4: Uniform mesh REFINE
        
  
   [Node,elem_tri] = uniformrefine(Node,elem_tri);
    
  
      
   if size(Elem,1) > maxN %|| size(elem,1) < minN
      
       break;
       
   end

end
