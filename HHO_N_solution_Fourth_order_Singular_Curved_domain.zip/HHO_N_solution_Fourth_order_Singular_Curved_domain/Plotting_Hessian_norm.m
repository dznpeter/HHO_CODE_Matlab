function Hessian_u_R_HHO_norm = Plotting_Hessian_norm(elem_nodes,BDbox,Po, coef,local_Reconstruction, RHHO_ind)
     
%% First compute the local Reconstruction R_HHO

ind = size(coef,1); % remove the rededuncy 

R_HHO_nc = local_Reconstruction(:,1:ind)*coef;




dim_elem_R = size(RHHO_ind,1); % Dimention for reconstruction HHO basis on each element 



% information about the bounding box

h = (BDbox(2,:)-BDbox(1,:))./2;  

m = 0.5.*sum(BDbox);


R_HHO_miss = coef(1);

%% R_HHO solution finally find.....

local_R_HHO =[R_HHO_miss ;R_HHO_nc];


%% computing the error



  [Qpoints_elem,weights_elem]=quad_poly_special(elem_nodes,Po); % get the quadrature points on polygon


%Computing the error for the projection of the u and u_h

% the mass matrix on the element basis T and T between dim_elem_inter * dim_elem_R


         
    
    % construct the matrix for all the local basis function

    
    
   Pxx = zeros(size(Qpoints_elem,1) ,dim_elem_R );
    
    Pxy = zeros(size(Qpoints_elem,1) ,dim_elem_R );
    
    Pyx = zeros(size(Qpoints_elem,1) ,dim_elem_R );
    
    Pyy = zeros(size(Qpoints_elem,1) ,dim_elem_R );
   
   
   
   
    
    
    for i =1:dim_elem_R 
                
        t =  Hessian_leg(Qpoints_elem,m,h,RHHO_ind(i,:));
        
        Pxx(:,i) = t(:,1); Pxy(:,i) = t(:,2); Pyx(:,i) = t(:,3); Pyy(:,i) = t(:,4); 
    end
  
      % Recovered HHO solution
     
    Hessian_u_R_HHO = [Pxx*local_R_HHO, Pyx*local_R_HHO, Pxy*local_R_HHO , Pyy*local_R_HHO];   % gradient of R_HHO
    
   
        
     t2 = sum((Hessian_u_R_HHO).^2,2);
          
      Hessian_u_R_HHO_norm =  sqrt(dot((t2),weights_elem));
     
     
end


