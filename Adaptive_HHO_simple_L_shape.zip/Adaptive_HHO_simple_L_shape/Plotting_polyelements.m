function  Plotting_polyelements(Elem,node_tri,elem_tri)


tri = elem_tri(Elem,:);

[~,bdEdge] = findboundary(tri);


edge = bdEdge;


for t = 1:size(edge,1) 

 t1 = [node_tri(edge(t,1),:); node_tri(edge(t,2),:)];

plot(t1(:,1), t1(:,2),'k-','LineWidth',1,'MarkerSize',5)
 
%xlim([0 ,1]); ylim([0 ,1]);

end




end