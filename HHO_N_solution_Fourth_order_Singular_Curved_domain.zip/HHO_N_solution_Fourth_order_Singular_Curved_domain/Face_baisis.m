function val = Face_baisis(x,local_edges_nodes,Po,order)

% on each individual face we put the othronormal basis

[~,ref_Qpoints] = quad_GL(Po);

%change the quadrature nodes from reference domain to physical domain.


mid= sum(local_edges_nodes)./2;   tanvec = 0.5* (local_edges_nodes(2,:)-local_edges_nodes(1,:));

C = kron(mid,ones(size(ref_Qpoints,1),1));

P_Qpoints = kron(ref_Qpoints,tanvec) + C;



    
L = norm(local_edges_nodes(2,:)-local_edges_nodes(1,:),2)*0.5;


val=shift_leg_derivative(ref_Qpoints,0,1,order(1),0)./L^(0.0);

end
